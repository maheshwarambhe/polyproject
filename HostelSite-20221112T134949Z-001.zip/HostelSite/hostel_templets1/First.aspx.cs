﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
public partial class Default10 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        PdfPTable pdfTable = new PdfPTable(GridView1 .HeaderRow .Cells .Count );
        foreach (TableCell headerCell in GridView1.HeaderRow.Cells)
        {
            Font font = new Font();
           font.Color = new BaseColor(GridView1 .HeaderStyle .ForeColor );

            PdfPCell pdfcell = new PdfPCell(new Phrase (headerCell .Text ,font ));
            pdfcell.BackgroundColor = new BaseColor(GridView1.HeaderStyle.BackColor);
            pdfTable.AddCell(pdfcell );
          
        }
        foreach (GridViewRow gridviewRow in GridView1.Rows)
        {
 
            foreach (TableCell tableCell in gridviewRow .Cells  )
            {
               Font font = new Font();
                font.Color = new BaseColor(GridView1 .RowStyle .ForeColor );

                PdfPCell pdfcell = new PdfPCell(new Phrase (tableCell .Text ));
               pdfcell.BackgroundColor = new BaseColor(GridView1 .RowStyle  .BackColor );
                pdfTable.AddCell(pdfcell );


            }
        }
        Document pdfdocument = new Document(PageSize.A4  ,10f,10f,100f,10f);
        PdfWriter.GetInstance(pdfdocument ,Response .OutputStream );
        pdfdocument.Open();
        pdfdocument.Add(pdfTable );
        pdfdocument.Close();
        Response.ContentType = "application/pdf";
        Response.AppendHeader("content-disposition","attachment; filename = List.pdf");
        Response.Write(pdfdocument );
        Response.Flush();
        Response.End();
    }
}