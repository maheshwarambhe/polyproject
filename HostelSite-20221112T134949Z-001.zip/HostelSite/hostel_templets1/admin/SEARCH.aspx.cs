﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Default4 : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {


        host2databaseDataContext us = new host2databaseDataContext();
        var result = (from x in us.stud_infos
                      where x.admitionNo.Equals(TextBox1.Text) 
                      select x).FirstOrDefault();
        if (result != null)
        {
            string adm_nu, fname, catgry, yrr, addres, contt, emaill;
            decimal ssc, hsc, fy, sy;
            string strConnect = "Data Source=ACER-PC;Initial Catalog=hostbase;Persist Security Info=True;User ID=sa;Password=sa";
            SqlConnection Conn = new SqlConnection(strConnect);
            string Command = "Select * from host_stud_info where admitionNo ='" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(Command, Conn);
            Conn.Open();
            SqlDataReader Fr = cmd.ExecuteReader();
            while (Fr.Read())
            {
                adm_nu = Fr.GetString(0);
                fname = Fr.GetString(1);
                catgry = Fr.GetString(2);
                ssc = Fr.GetDecimal(3);
                yrr = Fr.GetString(4);

                hsc = Fr.GetDecimal(5);
                fy = Fr.GetDecimal(6);
                sy = Fr.GetDecimal(7);


                addres = Fr.GetString(8);
                contt = Fr.GetString(9);
                emaill = Fr.GetString(10);

                TextBox2.Text = fname;
                TextBox3.Text = addres;
                TextBox4.Text = contt;
                TextBox5.Text = yrr;
                TextBox6.Text = ssc.ToString();
                TextBox7.Text = catgry;
                TextBox8.Text = hsc.ToString();
                TextBox9.Text = fy.ToString();
                TextBox10.Text = sy.ToString();
                TextBox11.Text = emaill;


            }


        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Student is Not Exits or Wrong Admition Number";
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
}
    
  