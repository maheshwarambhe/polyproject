﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        string cat = Categary.SelectedItem.Text;
        string yar = Year1.SelectedItem.Text;

        if (cat == "Select_Category")
        {
            Label1.Visible = true;
            Label1.Text = "Select categary first";
        }
        else
        {
            if (yar == "Select_Year")
            {
                Label1.Visible = true;
                Label1.Text = "Select Year first";
            }
            else
            {

                try
                {
                    host2databaseDataContext pdc = new host2databaseDataContext();
                    stud_info al = new stud_info();
                    al.admitionNo = TextBox1.Text;
                    al.Full_name = Convert.ToString(TextBox2.Text);
                    al.Category = Categary.SelectedItem.Text;
                    al.SSCmarks = Convert.ToDecimal(TextBox4.Text);
                    al.Year = Year1.SelectedItem.Text;
                    pdc.stud_infos.InsertOnSubmit(al);
                    pdc.SubmitChanges();
                    Label1.Visible = true;
                    Label1.Text = "Student Added Successfully";
                }
                catch
                {
                    Label1.Visible = true;
                    Label1.Text = "Student  added";
                }
            }
        }
    }
}
   
