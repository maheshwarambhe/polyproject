﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Default4 : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        Label1.Visible = false;
        host2databaseDataContext us = new host2databaseDataContext();
        var result = (from x in us.stud_infos
                      where x.admitionNo.Equals(TextBox1.Text) &
                      x.Apply.Equals('y')
                      select x).FirstOrDefault();
        if (result != null)
        {
            string adm_nu, fname, catgry, yrr, addres, contt, emaill;
            decimal ssc, hsc, fy, sy;
            string strConnect = "Data Source=ACER-PC;Initial Catalog=hostbase;Persist Security Info=True;User ID=sa;Password=sa";
            SqlConnection Conn = new SqlConnection(strConnect);
            string Command = "Select * from stud_info where admitionNo ='" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(Command, Conn);
            Conn.Open();
            SqlDataReader Fr = cmd.ExecuteReader();
            while (Fr.Read())
            {
                adm_nu  = Fr.GetString(0);
                fname  = Fr.GetString(1);
                catgry = Fr.GetString(2);
                ssc = Fr.GetDecimal(3);
                yrr = Fr.GetString(4);
                
                hsc = Fr.GetDecimal(5);
                fy = Fr.GetDecimal(6);
                sy = Fr.GetDecimal(7);
             

               addres = Fr.GetString(8);
               contt = Fr.GetString(9);
               emaill = Fr.GetString(10);
               
                TextBox2.Text = fname;
                TextBox3.Text = addres;
                TextBox4.Text = contt;
                TextBox5.Text = yrr;
                TextBox6.Text = ssc.ToString();
                TextBox7.Text = catgry;
                TextBox8.Text = hsc.ToString();
                TextBox9.Text = fy.ToString();
                TextBox10.Text = sy.ToString();
                TextBox11.Text = emaill;


            }

            Button2.Enabled = true;
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "already Admited or not Applied Student";
        }

    }
    
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int empty = 1;
        host2databaseDataContext us = new host2databaseDataContext();
        if (TextBox5.Text == "First     ")
        {
            if (TextBox7.Text == "OPEN      ")
            {
                var result = (from x in us.seats 
                              where x.Year .Equals(TextBox5.Text) &
                              x.oppen .Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "SC        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.sc.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "OBC       ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.obc .Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "ST        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.st.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }

            if (TextBox7.Text == "NT        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.nt.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "SBC       ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.oppen.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
        }
        if (TextBox5.Text == "Second    ")
        {
            if (TextBox7.Text == "OPEN      ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.oppen.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "SC        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.sc.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "OBC       ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.obc.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "ST        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.st.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }

            if (TextBox7.Text == "NT        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.nt.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "SBC       ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.oppen.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
        }
        if (TextBox5.Text == "Third     ")
        {
            if (TextBox7.Text == "OPEN      ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.oppen.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "SC        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.sc.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "OBC       ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.obc.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "ST        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.st.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }

            if (TextBox7.Text == "NT        ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.nt.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
            if (TextBox7.Text == "SBC       ")
            {
                var result = (from x in us.seats
                              where x.Year.Equals(TextBox5.Text) &
                              x.oppen.Equals(0)
                              select x).FirstOrDefault();
                if (result != null)
                { empty = 0; }
            }
        }

        if (empty == 0)
        {
            Response .Redirect ("~/admin/admitionFail.aspx");
        }
        else
        {
          
            // STARING OF CODE TO INSERT /ADMITION
            host2databaseDataContext ms = new host2databaseDataContext();
            host_stud_info tb = new host_stud_info();
            tb.admitionNo = TextBox1.Text;
            tb.Full_name = TextBox2.Text;
            tb.Category = TextBox7.Text;
            tb.SSCmarks = Convert.ToDecimal(TextBox6.Text);
            tb.Year = TextBox5.Text;
            tb.HSCmarks = Convert.ToDecimal(TextBox8.Text);
            tb.First_Year = Convert.ToDecimal(TextBox9.Text);
            tb.Second_Year = Convert.ToDecimal(TextBox10.Text);
            tb.PermanantAddrs = TextBox3.Text;
            tb.Contact = TextBox4.Text;
            tb.Email = TextBox11.Text;

            try
            {
                ms.host_stud_infos.InsertOnSubmit(tb);
                ms.SubmitChanges();
                //start DRECRENENT CODE

                var query = from ord in ms.seats
                            where ord.Year == TextBox5.Text
                            select ord;

                // Execute the query, and change the column values 
                // you want to change. 
                foreach (seat ord in query)
                {
                    if (TextBox7.Text == "OPEN      ")
                        ord.oppen = ord.oppen - 1;

                    if (TextBox7.Text == "OBC       ")
                        ord.obc = ord.obc - 1;

                    if (TextBox7.Text == "SC        ")
                        ord.sc = ord.sc - 1;

                    if (TextBox7.Text == "NT        ")
                        ord.nt = ord.nt - 1;

                    if (TextBox7.Text == "ST        ")
                        ord.st = ord.st - 1;

                    if (TextBox7.Text == "SBC       ")
                        ord.sbc = ord.sbc - 1;


                    // Insert any additional changes to column values.
                }

                // Submit the changes to the database. 

                ms.SubmitChanges();


                //end DECREMENT CODE
                Response.Redirect("~/admin/admition success.aspx");

            }
            catch
            {
                Label1.Visible = true;
                Label1.Text = "Admition is Alredy Confirmed..";
            }

            // ENDING OF CODE TO INSET/ ADMITION
        }
    }
}