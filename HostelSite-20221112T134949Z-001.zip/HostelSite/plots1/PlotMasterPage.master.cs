﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PlotMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        plot2databaseDataContext dc = new plot2databaseDataContext();
        feed_backinfo fd = new feed_backinfo();
        fd.Fullname = TextBox1.Text;
        fd.contact = TextBox2.Text;
        fd.email = TextBox3.Text;
        fd.message = Convert.ToString(TextBox4 .Text );
        dc.feed_backinfos .InsertOnSubmit(fd);
        dc.SubmitChanges();
        Label1.Visible = true;
    }
}
