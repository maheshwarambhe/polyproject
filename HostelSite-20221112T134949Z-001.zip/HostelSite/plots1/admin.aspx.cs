﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        
        plot2databaseDataContext   dc = new plot2databaseDataContext  ();
        var result = (from x in dc.admin_infos 
                      where x.username.Equals(TextBox5.Text) &
                      x.password.Equals(TextBox6.Text)
                      select x).FirstOrDefault();
        if (result != null)
            Response.Redirect("~/admin/adminhome.aspx");
        else
        {
            Label1 .Visible =true;
            Label1 .Text ="Incorrect Username or Password";
        }
    }
    }
