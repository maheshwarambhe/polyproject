﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class customer_master_page_Default : System.Web.UI.Page
{
    string ids;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = Request.QueryString["id"];
        DataTable dt= new DataTable();
        String strConnString = System.Configuration.ConfigurationManager.
            ConnectionStrings["plotConnectionString"].ConnectionString;
        string strQuery = "select contactno,rate,address,imagepath from flatdatabase Where emailaddress = '"+Label1 .Text +"  '  ";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(strConnString);

        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
        }
        //grid 1
        DataTable dt1 = new DataTable();
      //  String strConnString = System.Configuration.ConfigurationManager.
      //      ConnectionStrings["plotConnectionString"].ConnectionString;
        string strQuery1 = "select contactno,rate,address,imagepath from plotdatabase Where emailaddress = '" + Label1.Text + "  '  ";
        SqlCommand cmd1 = new SqlCommand(strQuery1);
   //     SqlConnection con = new SqlConnection(strConnString);

        SqlDataAdapter sda1 = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda1.SelectCommand = cmd;
            sda1.Fill(dt1);
            GridView2.DataSource = dt1;
            GridView2.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
        }
        // rent
        DataTable dt2 = new DataTable();
        //  String strConnString = System.Configuration.ConfigurationManager.
        //      ConnectionStrings["plotConnectionString"].ConnectionString;
        string strQuery2 = "select contactno,rate,address,imagepath from rentdatabase Where emailaddress = '" + Label1.Text + "  '  ";
        SqlCommand cmd2 = new SqlCommand(strQuery2);
        // SqlConnection con = new SqlConnection(strConnString);

        SqlDataAdapter sda2 = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda2.SelectCommand = cmd;
            sda2.Fill(dt2);
            GridView3.DataSource = dt2;
            GridView3.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
        }


      
    }
   
}