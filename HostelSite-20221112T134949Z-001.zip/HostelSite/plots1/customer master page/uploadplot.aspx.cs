﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class customer_master_page_Default2 : System.Web.UI.Page
{
    string emplot;
    protected void Page_Load(object sender, EventArgs e)
    {
       Label1 .Text  = Request.QueryString["id"];
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        plot2databaseDataContext dc = new plot2databaseDataContext();
        plotdatabase ft = new plotdatabase();
        string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
        FileUpload1.PostedFile.SaveAs(Server.MapPath("~/images/") + fileName);
        ft.emailaddress = Label1 .Text ;
        string em = Label1 .Text ;
        ft.contactno = TextBox5.Text;
        ft.imagename = fileName;
        string iipath = "~/images/" + fileName;
        ft.imagepath = iipath;
        ft.address = Convert.ToString(TextBox4.Text);
        ft.rate = Convert.ToDecimal(TextBox3.Text);
        dc.plotdatabases.InsertOnSubmit(ft);
        dc.SubmitChanges();
        Response.Redirect("~/customer master page/cust_home.aspx?id=" + em  );
    }
}