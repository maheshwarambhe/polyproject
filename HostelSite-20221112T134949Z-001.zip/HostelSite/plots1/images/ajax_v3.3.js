var rootdomain="http://"+window.location.hostname

function ajaxinclude(url) {
var page_request = false
if (window.XMLHttpRequest) // if Mozilla, Safari etc
page_request = new XMLHttpRequest()
else if (window.ActiveXObject){ // if IE
try {
page_request = new ActiveXObject("Msxml2.XMLHTTP")
} 
catch (e){
try{
page_request = new ActiveXObject("Microsoft.XMLHTTP")
}
catch (e){}
}
}
else
return false
page_request.open('GET', url, false) //get page synchronously 
page_request.send(null)
writecontent(page_request)
}

function writecontent(page_request){
if (window.location.href.indexOf("http")==-1 || page_request.status==200)
document.write(page_request.responseText)
}

function getExpiredStatus(return_status) {
var page_request = false
if (window.XMLHttpRequest) // if Mozilla, Safari etc
page_request = new XMLHttpRequest()
else if (window.ActiveXObject){ // if IE
try {
page_request = new ActiveXObject("Msxml2.XMLHTTP")
} 
catch (e){
try{
page_request = new ActiveXObject("Microsoft.XMLHTTP")
}
catch (e){}
}
}
else
return false
var randomnumber= Math.floor(Math.random()*99999);
var url = rootdomain+'/do/getMicrositeExpiredStatus?q='+randomnumber;
page_request.open('GET', url, false) //get page synchronously 
page_request.send(null)
if(return_status){
	return page_request.responseText;
}
show_hideForm(page_request)
}

function show_hideForm(page_request){
if (window.location.href.indexOf("http")==-1 || page_request.status==200){
	if(page_request.responseText == '1'){
		//do nothing
	}
	else{
		if(document.getElementById('form_wp') != undefined){
			var form_wp = document.getElementById('form_wp');
            for ( var i = 0; i < form_wp.length; i++) {
            	document.getElementById('form_wp').style.display='none';
			}	
		}
		if(document.getElementById('form') != undefined){
			var form_normal = document.getElementById('form');
            for ( var i = 0; i < form_normal.length; i++) {
            	document.getElementById('form').style.display='none';
			}	
		}
		if(document.getElementById('search_form') != undefined){
			document.getElementById('search_form').style.display='block';
		}
		
		if(document.getElementsByClassName('formh1') != undefined){
	         var form_normal = document.getElementsByClassName('formh1');
	         for ( var i = 0; i < form_normal.length; i++) {
	                 form_normal[i].innerHTML = "<div class='f16'><img style='float:left;padding-right:5px;' src = '/images/alert_new.gif' />This project is currently not active on 99acres.<div><div class='clr'></div>";
	         }        
	     }
		
	     if(document.getElementsByClassName('hformh1') != undefined){
	             var form_normal = document.getElementsByClassName('Hformh1');
	             for ( var i = 0; i < form_normal.length; i++) {
	                     form_normal[i].innerHTML = "<div class='f16'><img style='float:left;padding-right:5px;' src = '/images/alert_new.gif' />This project is currently not active on 99acres.<div><div class='clr'></div>";
	             }        
	     }
     
	}
}
}
