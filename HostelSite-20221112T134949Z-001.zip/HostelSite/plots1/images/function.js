function _ifr_size(evt,ifr) {
	if(ifr.contentWindow.document.body.innerHTML!="")
	{
		
        ifr.height=ifr.contentWindow.document.body.scrollHeight+50;
		ifr.contentWindow.scrollTo(0,ifr.height);
		
		if(typeof ifr.contentWindow.lazyload == 'function'){
        ifr.contentWindow.lazyload();
}

		
		}
}
function hideContainer(id)
{
	document.getElementById(id).style.display="none";
}
function showHideSearchForm()
{
	if(document.getElementById('form_wp') != undefined){
		var form_wp = document.getElementById('form_wp');
		for ( var i = 0; i < form_wp.length; i++) {
			document.getElementById('form_wp').style.display='none';
		}	
	}
	if(document.getElementById('form') != undefined){
		var form_normal = document.getElementById('form');
		for ( var i = 0; i < form_normal.length; i++) {
			document.getElementById('form').style.display='none';
		}	
	}
	if(document.getElementById('search_form') != undefined){
		document.getElementById('search_form').style.display='block';
	}
	
	if(document.getElementsByClassName('formC') != undefined){
		var form_normal = document.getElementsByClassName('formC');
		for ( var i = 0; i < form_normal.length; i++) {
			form_normal[i].innerHTML = "<div class='expiredMssg'><img style='float:left;padding-right:5px;' src = 'http://www.99acres.com/images/alert_new.gif' />This project is currently not active on 99acres.<div><div class='clr'></div>";
		}	
	}
	if(document.getElementsByClassName('HformC') != undefined){
		var form_normal = document.getElementsByClassName('HformC');
		for ( var i = 0; i < form_normal.length; i++) {
			form_normal[i].innerHTML = "<div class='expiredMssg'><img style='float:left;padding-right:5px;' src = 'http://www.99acres.com/images/alert_new.gif' />This project is currently not active on 99acres.<div><div class='clr'></div>";
		}	
	}
	document.body.className = "homeWithSearch";
}
function getsrcMobile(){
	var url = window.location.href;
	var arr = url.split("?");
	if(arr.length>1) {
		arr = arr[1].split("&");
		for(var i=0;i<arr.length;i++) {
			if(arr[i].indexOf("from_src=")==0) {
				farr = arr[i].split("=");
				return farr[1];
			}
		}
	}
	else{
		var arr = url.split("&");
		if(arr.length>1) {
			for(var i=0;i<arr.length;i++) {
				if(arr[i].indexOf("from_src=")==0) {
					farr = arr[i].split("=");
					return farr[1];
				}
			}
		}
	}
	return false;
}
function openCTViewProjMobile(evt,btn,phone){

	var src = getsrcMobile();
	if(src!==false)
	{
		try {
		$.post("/do/99mobile/quickSearch99Mobile/doTracking",
		{
			curAction:'MHTML5_NPCALL',
			curActionId:src,
			actionSource:'MHTML5_NPCONTACT_ADVT|1| '+phone
		},
		function(data,status){
			
		});
		}
		catch(ex){}
	}
	return false;
}
function SetCookie(cookieName,cookieValue,nDays,path) {
	var today = new Date();
	var expire = new Date();
	if (nDays==null || nDays==0) nDays=1;
	expire.setTime(today.getTime() + 3600000*24*nDays);
	document.cookie = cookieName+"="+escape(cookieValue)+ ";expires="+expire.toGMTString()+";path="+path;
}
function ReadCookie(cookieName) {
	var theCookie=" "+document.cookie;
	var ind=theCookie.indexOf(" "+cookieName+"=");
	if (ind==-1) ind=theCookie.indexOf(";"+cookieName+"=");
	if (ind==-1 || cookieName=="") return "";
	var ind1=theCookie.indexOf(";",ind+1);
	if (ind1==-1) ind1=theCookie.length; 
	return unescape(theCookie.substring(ind+cookieName.length+2,ind1));
}
function deleteCookie(cookieName)
{
   SetCookie(cookieName,'0','-1')
}
