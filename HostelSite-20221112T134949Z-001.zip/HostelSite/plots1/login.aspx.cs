﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string username = TextBox5.Text;
       plot2databaseDataContext  us = new plot2databaseDataContext ();
        var result = (from x in us.registration_infos
                      where x.emailid .Equals(TextBox5.Text) &
                      x.password.Equals(TextBox6.Text)
                      select x).FirstOrDefault();
        if (result != null)
        Response.Redirect("~/customer master page/cust_home.aspx?id=" + username);
          else
           {
               Label2.Visible = true;
               Label2.Text = "Username Or password is Incorrect .";
           } 
    }
}