﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {


        try
        {
            plot2databaseDataContext dc = new plot2databaseDataContext();
            registration_info re = new registration_info();
            re.firstname = TextBox7.Text;
            re.middlename = TextBox8.Text;
            re.lastname = TextBox9.Text;
            re.address = TextBox10.Text;
            re.emailid = TextBox11.Text;
            re.phoneno = TextBox12.Text;
            re.password = TextBox13.Text;
            dc.registration_infos.InsertOnSubmit(re);
            dc.SubmitChanges();
            Response.Redirect("~/login.aspx");

        }
            catch 
        {
            Label1.Visible = true;
            Label1.Text = "Email ID exsist";
        }
        
        }
    protected void TextBox8_TextChanged(object sender, EventArgs e)
    {

    }
}
