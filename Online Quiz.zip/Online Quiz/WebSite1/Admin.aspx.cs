﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class Admin : System.Web.UI.Page
{
    public static SqlConnection con = new SqlConnection("Data Source=MICROBYTE;Initial Catalog=Quiz;User ID=sa;Password=sa123");
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        string query = "select * from Adm where username ='"+txtuser.Text+"' and password ='"+txtpassword.Text+"'";
        SqlCommand cmd = new SqlCommand(query, con);
        SqlDataAdapter ds = new SqlDataAdapter(cmd);
        ds.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Session["username"] = txtuser.Text;
            Response.Redirect("~/Update.aspx");
            txtuser.Text = string.Empty;
            txtpassword.Text = string.Empty;
            Label1.Visible = false;
        }
        else
        {
            Label1.Text = "Login Fail";
            Label1.Visible = true;
        }
    }
    protected void btnuserlogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Login.aspx");
    }
}