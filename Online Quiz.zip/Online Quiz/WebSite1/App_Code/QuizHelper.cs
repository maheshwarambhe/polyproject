﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;


/// <summary>
/// Summary description for QuizHelper
/// </summary>
 public class QuizHelper
{
    public static SqlConnection con = new SqlConnection("Data Source=MICROBYTE;Initial Catalog=Quiz;User ID=sa;Password=sa123");

	public QuizHelper()
	{
		 
	}

   static public DataTable GetDataTable(string Query)
    { 
        DataTable dt =new DataTable();
        SqlCommand cmd = new SqlCommand(Query,con);
        SqlDataAdapter ds = new SqlDataAdapter(cmd);
        ds.Fill(dt);
        return dt;
    }
}