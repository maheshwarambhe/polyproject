﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["studentId"] != null)
            CalculateMarks(Request.QueryString["studentId"].ToString());
        else
            Response.Redirect("~/Login.aspx");
    }
    protected void btnend_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Login.aspx");
    }
    private void CalculateMarks(string StudentId)
    {
        string query1 = "Select QuestionId,AnswerId from tblExam where StudentId= '" +StudentId + "'";
        string query2 = "Select QuestionId,AnswerId from tblQuestionMaster ";
        string query3 = "select E.QuestionId as [Question No.],[Result]= case Q.AnswerId - E.AnswerId when '0' then 'Correct' when Q.AnswerId then 'skip' else 'Wrong' end from tblExam E inner join tblQuestionMaster Q on E.QuestionId=Q.QuestionId where StudentId='" + StudentId + "'";
        DataTable dtStudent = QuizHelper.GetDataTable(query1);
        DataTable dtQuestion = QuizHelper.GetDataTable(query2);
        DataTable dtGrid = QuizHelper.GetDataTable(query3);

        int marks = 0;
        int skip = 0;

        for (int i = 0; i < dtStudent.Rows.Count; i++)
        {
            if (Convert.ToInt32(dtStudent.Rows[i][1].ToString()) == Convert.ToInt32(dtQuestion.Rows[i][1].ToString()))
            {
                marks = marks + 1;
            }
            if (Convert.ToInt32(dtStudent.Rows[i][1].ToString()) == 0)
            {
                skip = skip + 1;
            }

        }

        txtmarks.Text = (marks*2).ToString();
        txtskip.Text = skip.ToString();
        txtattempt.Text=(dtStudent.Rows.Count-skip).ToString();
        GridView1.DataSource = dtGrid;
        GridView1.DataBind();
    }



    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        LinkButton1.Visible = false;
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        LinkButton1.Visible = true;
     }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
