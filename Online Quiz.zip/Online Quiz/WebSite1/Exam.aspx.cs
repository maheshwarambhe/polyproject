﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Exam : System.Web.UI.Page
{
     public static SqlConnection con = new SqlConnection( "Data Source=MICROBYTE;Initial Catalog=Quiz;User ID=sa;Password=sa123");
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
      {
          if (Session["StudentModel"] != null)
          {
              StudentModel studentModel = new StudentModel();
              studentModel = Session["StudentModel"] as StudentModel;

              lblName.Text = studentModel.StudentName;
              
              ViewState["StudentId"] = studentModel.StudentId;

              this.LoadFirstQuestion();
              if (!SM1.IsInAsyncPostBack)

                  Session["timeout"] = DateTime.Now.AddMinutes(10).ToString();
          }
          else
          {
              Response.Redirect("~/Login.aspx");
          }
        }
       

    }

    protected void Submit_Click(object sender, EventArgs e)
    {
        
        int questionId = Convert.ToInt32(lblQuetionNo.Text);

        string query = "insert into tblExam (QuestionId,AnswerId,StudentId,IsSkip) values ('" +Convert.ToInt32(lblQuetionNo.Text) + "','" + Convert.ToInt32(rbtnOption.SelectedValue) + "','"+ Convert.ToInt32(ViewState["StudentId"].ToString()) +"','false')";
        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        if ((questionId + 1) <= 30 )
        {
            LoadNextQuestion(questionId + 1);
        }
        else
        {
            string StudentId = ViewState["StudentId"].ToString();
            Response.Redirect("~/Calculation.aspx?studentId=" + StudentId);
        }

    }

    private void LoadFirstQuestion()
    {
        lblcat.Text = "General Knwoledge";
        string query = "Select QuestionId, CategoryId,Question,Option1, Option2 ,Option3 ,Option4 from tblQuestionMaster Where QuestionId ='1'";
        DataTable dtQue = QuizHelper.GetDataTable(query);       
        lblQuetionNo.Text = dtQue.Rows[0][0].ToString();
        lblQuection.Text = dtQue.Rows[0][2].ToString();
        rbtnOption.Items.Add(new ListItem(dtQue.Rows[0][3].ToString(), "1"));
        rbtnOption.Items.Add(new ListItem(dtQue.Rows[0][4].ToString(), "2"));
        rbtnOption.Items.Add(new ListItem(dtQue.Rows[0][5].ToString(), "3"));
        rbtnOption.Items.Add(new ListItem(dtQue.Rows[0][6].ToString(), "4"));
      
    }
    
    private void LoadNextQuestion(int QuestionId)
    {

        string query = "Select QuestionId, CategoryId,Question,Option1, Option2 ,Option3 ,Option4 from tblQuestionMaster Where QuestionId ='"+ QuestionId+"'";
        DataTable dtQue = QuizHelper.GetDataTable(query);
        lblQuetionNo.Text = dtQue.Rows[0][0].ToString();
        lblQuection.Text = dtQue.Rows[0][2].ToString();
        rbtnOption.Items.Clear();
        rbtnOption.Items.Add(new ListItem(dtQue.Rows[0][3].ToString(), "1"));
        rbtnOption.Items.Add(new ListItem(dtQue.Rows[0][4].ToString(), "2"));
        rbtnOption.Items.Add(new ListItem(dtQue.Rows[0][5].ToString(), "3"));
        rbtnOption.Items.Add(new ListItem(dtQue.Rows[0][6].ToString(), "4"));
        if (QuestionId <= 10)
        {
            lblcat.Text = "General Knwoledge";
        }
        else if (QuestionId <= 20)
        {
            lblcat.Text = "Mathematical";
        }
        else
        {
            lblcat.Text = "Sports";
        }
    }

    protected void btnskip_Click(object sender, EventArgs e)
    {
        int questionId = Convert.ToInt32(lblQuetionNo.Text);

        string query = "insert into tblExam (QuestionId,AnswerId,StudentId,IsSkip) values ('" + Convert.ToInt32(lblQuetionNo.Text) + "','0','" + Convert.ToInt32(ViewState["StudentId"].ToString()) + "','true')";
        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        if ((questionId + 1) <= 30)
        {
            LoadNextQuestion(questionId + 1);
        }
        else
        {
            string StudentId = ViewState["StudentId"].ToString();
            Response.Redirect("~/Calculation.aspx?studentId="+ StudentId);
        }
        
       
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Login.aspx");
    }

    protected void timer1_tick(object sender, EventArgs e)
    {
        if (Session["timeout"] != null)
        {

            if (0 > DateTime.Compare(DateTime.Now, DateTime.Parse(Session["timeout"].ToString())))
            {
                lblTimer.Text = string.Format("Time Left: 00:{0}:{1}", ((Int32)DateTime.Parse(Session["timeout"].ToString()).Subtract(DateTime.Now).TotalMinutes).ToString(), ((Int32)DateTime.Parse(Session["timeout"].ToString()).Subtract(DateTime.Now).Seconds).ToString());
            }
            else
            {
                Timer1.Enabled = true;
                string StudentId = ViewState["StudentId"].ToString();
                Response.Redirect("~/Calculation.aspx?studentId=" + StudentId);

            }
        }
    }
}