﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default : System.Web.UI.Page
{
    public static SqlConnection con = new SqlConnection( "Data Source=MICROBYTE;Initial Catalog=Quiz;User ID=sa;Password=sa123");
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnStartExam_Click(object sender, EventArgs e)
    {
        StudentModel studentModel = new StudentModel();
       
        studentModel.StudentName = txtname.Text;  

        SqlParameter[] Parameter = new SqlParameter[]
        {
            new SqlParameter("@Name", txtname.Text),
            new SqlParameter("@Email", txtemail.Text),
            new SqlParameter("@ReturnVal",SqlDbType.Int)
        };

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert_Student";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        foreach (SqlParameter sparameter in Parameter)
        {
            cmd.Parameters.Add(sparameter);
        }
        cmd.Parameters["@ReturnVal"].Direction = ParameterDirection.Output;
        cmd.Parameters["@Name"].Direction = ParameterDirection.Input;
        cmd.Parameters["@Email"].Direction = ParameterDirection.Input;


        if (con.State != ConnectionState.Open)            
        con.Open();
        

        cmd.ExecuteNonQuery();
        int StudentId = Convert.ToInt32(cmd.Parameters["@ReturnVal"].Value);

        con.Close();
        Session["name"] = txtname.Text;
        studentModel.StudentId = StudentId;
        Session["StudentModel"] = studentModel;
        Response.Redirect("~/Exam.aspx");   
    }
}