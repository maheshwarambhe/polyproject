﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Update : System.Web.UI.Page
{
    public static SqlConnection con = new SqlConnection("Data Source=MICROBYTE;Initial Catalog=Quiz;User ID=sa;Password=sa123");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Response.Redirect("~/Admin.aspx");
        }
    }

    protected void drpdwnquestion_questionIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = QuizHelper.GetDataTable("select Question,QuestionId from tblQuestionMaster where QuestionId='" + drpdwnquestion.SelectedValue + "' ");
        txtoldquestion.Text =dt.Rows[0][0].ToString();

    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        ClearData();
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string query = "Update tblQuestionMaster set Question= '" + txtnewquestion.Text + "' ,Option1= '" + txtoption1.Text + "',Option2 ='" + txtoption2.Text + "',Option3 = '" + txtoption3.Text + "',Option4 ='" + txtoption4.Text + "',AnswerId='" + drpdnanswer.SelectedValue + "' Where QuestionId='" + drpdwnquestion.SelectedValue + "'";
        SqlCommand cmd = new SqlCommand(query,con);
        if (con.State != ConnectionState.Open)
            con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        ClearData();
    }

    private void ClearData()
    {
        drpdwnquestion.SelectedIndex = -1;
        txtoldquestion.Text = string.Empty;
        txtnewquestion.Text = string.Empty;
        txtoption1.Text = string.Empty;
        txtoption2.Text = string.Empty;
        txtoption3.Text = string.Empty;
        txtoption4.Text = string.Empty;
        drpdnanswer.SelectedIndex = -1;
    }
    protected void btnuserlogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Login.aspx");
    }
}