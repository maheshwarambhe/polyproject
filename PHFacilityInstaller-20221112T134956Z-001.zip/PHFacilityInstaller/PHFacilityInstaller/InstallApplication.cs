﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Management.Automation.Runspaces;
using System.Net;
using System.Reflection;
using System.ServiceProcess;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.Web.Administration;
using Microsoft.Win32;

namespace PHFacilityInstaller
{
    public partial class InstallApplication
    {
        public static string applicationName = "PHFacility";
        public static string applicationPool = "PHFacility_AppPool";
        public static string companyName = "Delmon Solutions";
        public static string databaseUserName = "PHFacilityUser";
        public static string databasePassword = "PHFacilityUser";

        ServerManager serverMgr = new ServerManager();
        string sourceDirectory = "";
        string Connection1 = "";
        string WebConfig = "";
        string TargetDirectory = "";
        string updateSqlScript = "";

        public InstallApplication(string DirectoryPath, string Con1, string config, string TargetDir, string updateDBScript)
        {           
            sourceDirectory = DirectoryPath;
            Connection1 = Con1;
            WebConfig = config;
            TargetDirectory = TargetDir;
            updateSqlScript = updateDBScript;
        }

        public void LoadData()
        {
            int[] osInfo = new int[2];
            try
            {
                //First check the OS version
                int osVersion = CheckOSInformation();

                if (osVersion < 6)
                {
                    MessageBox.Show("Please install OS version 6 or greater to run this application", "Operating system version", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);                    
                    System.Environment.Exit(0);
                    return;
                }

                //Check the IIS version 
                CheckIISVersion();

                //Check the status of IIS service whether it is running or stopped
                CheckIISStatus();

                string databaseName = applicationName;
                string authenticationType = "SQL Server Authentication";
                string serverNameNew = @".\SQLEXPRESS";
                string userName = databaseUserName;
                string password = databasePassword;
                string buttonText = "Connect";

                ExecuteCodeForInstallation(databaseName, authenticationType, serverNameNew, userName, password, buttonText);
            }
            catch
            {
                MessageBox.Show("No server Found.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteCodeForInstallation(string databaseName, string authenticationType,string serverMachineName, string userName, string password, string operationName)
        {
            try
            {
                //Check the sql server existence
                string instanceName = GetNameOfFirstAvailableSQLServerInstance();
                string serverNameNew = @".\SQLEXPRESS";

                if (!string.IsNullOrEmpty(instanceName))
                {                   
                    serverNameNew = instanceName;                                    
                }

                string newDir1 = TargetDirectory;
                newDir1 = newDir1.Substring(0, newDir1.Length - 1);

                if (operationName == "Connect")
                {
                    //Reset IIS 
                    ExecuteCommandAsAdmin();

                    if (!string.IsNullOrEmpty(serverMachineName))
                    {
                        //Set authentication mode to Mixed mode insql server 2008
                        SetMixedAuthenticationModeForSQLServer(serverNameNew);

                        //Restart the service of the sql server for applying the Mixed authentication mode
                        RestartSQLServerService();
                        
                        CreateUser(serverNameNew.Trim());

                        //string serverName = txtServerName.Text;
                        string serverName = @".\SQLEXPRESS";

                        serverName = serverNameNew;

                        if (authenticationType == "SQL Server Authentication")
                        {
                            if (!string.IsNullOrEmpty(userName))
                            {
                                if (!string.IsNullOrEmpty(password))
                                {
                                    Server srv;
                                    ServerConnection conn;
                                    string sqlSErverInstance = string.Empty;
                                    conn = new ServerConnection(serverName, userName, password);

                                    try
                                    {
                                        srv = new Server(conn);
                                        operationName = "Create Database";
                                    }
                                    catch
                                    {
                                        MessageBox.Show("Error to connect server.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        return;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Please enter password.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(password))
                                {
                                    MessageBox.Show("Please enter user name and password.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }
                                else
                                {
                                    MessageBox.Show("Please enter user name.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }
                            }
                        }
                        else
                        {
                            Server srv;
                            ServerConnection conn;
                            string sqlSErverInstance = string.Empty;

                            conn = new ServerConnection(serverName);
                            try
                            {
                                srv = new Server(conn);
                                MessageBox.Show("Connection created successfully.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                operationName = "Create Database";
                            }
                            catch
                            {
                                MessageBox.Show("Error to connect server.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter server name.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    operationName = "Create Database";
                    ExecuteCodeForInstallation(databaseName, authenticationType, serverMachineName, userName, password, operationName);
                }
                else
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(databaseName))
                        {
                            if (!string.IsNullOrEmpty(serverMachineName))
                            {                               
                                string serverName = string.Empty;                              
                                string datatbaseName = string.Empty;
                                string connectionString = string.Empty;

                                if (!string.IsNullOrEmpty(serverNameNew))
                                {
                                    serverName = serverNameNew;
                                }

                                if (Convert.ToString(authenticationType) == "SQL Server Authentication")
                                {
                                    if (!string.IsNullOrEmpty(userName))
                                    {
                                        if (!string.IsNullOrEmpty(password))
                                        {
                                            try
                                            {
                                                datatbaseName = databaseName;
                                                connectionString = "Data source=" + serverName + "; Initial Catalog=" + datatbaseName + "; User Id=" + userName + ";Password=" + password + "";
                                               
                                                string text = System.IO.Path.GetTempPath();

                                                TextWriter tw = new StreamWriter(text + "\\ConnectionString.txt");
                                                tw.WriteLine(connectionString);
                                                tw.Close();

                                                TextWriter tw1 = new StreamWriter(text + "\\ServerName.txt");
                                                tw1.WriteLine(serverName);
                                                tw1.Close();

                                                TextWriter tw2 = new StreamWriter(text + "\\DatabaseName.txt");
                                                tw2.WriteLine(datatbaseName);
                                                tw2.Close();

                                                TextWriter tw3 = new StreamWriter(text + "\\UserName.txt");
                                                tw3.WriteLine(userName);
                                                tw3.Close();

                                                TextWriter tw4 = new StreamWriter(text + "\\Password.txt");
                                                tw4.WriteLine(password);
                                                tw4.Close();

                                                TextWriter tw5 = new StreamWriter(text + "\\Authentication.txt");
                                                tw5.WriteLine(authenticationType);
                                                tw5.Close();

                                                CreateDatabase(sourceDirectory, Connection1, WebConfig, TargetDirectory);
                                            }
                                            catch (Exception ex)
                                            {
                                                MessageBox.Show("Create database error while reading ConnectionString.txt file Error :" + ex.ToString(), applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Please enter password.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        if (string.IsNullOrEmpty(password))
                                        {
                                            MessageBox.Show("Please enter user name and password.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            return;
                                        }
                                        else
                                        {
                                            MessageBox.Show("Please enter user name.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            return;
                                        }
                                    }
                                }
                                else
                                {
                                    try
                                    {
                                        datatbaseName = databaseName;
                                        connectionString = "Data source=" + serverName + "; Initial Catalog=" + datatbaseName + "; Integrated Security=true";

                                        string text = System.IO.Path.GetTempPath();

                                        TextWriter tw = new StreamWriter(text + "\\ConnectionString.txt");
                                        tw.WriteLine(connectionString);
                                        tw.Close();
                                        TextWriter tw1 = new StreamWriter(text + "\\ServerName.txt");
                                        tw1.WriteLine(serverName);
                                        tw1.Close();

                                        TextWriter tw2 = new StreamWriter(text + "\\DatabaseName.txt");
                                        tw2.WriteLine(datatbaseName);
                                        tw2.Close();
                                        userName = "Integrated Security=true";
                                        TextWriter tw3 = new StreamWriter(text + "\\UserName.txt");
                                        tw3.WriteLine(userName);
                                        tw3.Close();

                                        TextWriter tw5 = new StreamWriter(text + "\\Authentication.txt");
                                        tw5.WriteLine(authenticationType);
                                        tw5.Close();

                                        CreateDatabase(sourceDirectory, Connection1, WebConfig, TargetDirectory);

                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Create database error while reading ConnectionString.txt file in Windows Authentication mode Error : " + ex.ToString(), applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }

                            }
                            else
                            {
                                MessageBox.Show("Please enter server name.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter database name.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Create database error : " + ex.ToString(), applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch
            {
            }
        }

        void ChangeConfigParameters(string connctionstring)
        {
            try
            {
                string OldConnstring = @"Data Source=serverName;Initial Catalog=" + applicationName + ";Integrated Security=true;";
                string ConfigPath = TargetDirectory + "\\Publish\\Web.Config";

                if (File.Exists(ConfigPath))
                {
                    string Content = File.ReadAllText(ConfigPath);
                    Content = Content.Replace(OldConnstring, connctionstring);

                    TextWriter tw2 = new StreamWriter(ConfigPath);
                    tw2.WriteLine(Content);
                    tw2.Close();
                }
            }
            catch
            {
                MessageBox.Show("Error to write config file parameters:", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private static void DeleteApp()
        {
            using (ServerManager mgr = new ServerManager())
            {
                if (mgr.Sites["Default Web Site"].Applications["/" + applicationName + ""] != null)
                {
                    Microsoft.Web.Administration.Application app = mgr.Sites["Default Web Site"].Applications["/" + applicationName + ""];
                    mgr.Sites["Default Web Site"].Applications.Remove(app);
                    mgr.CommitChanges();
                }
                else
                {
                }

                ApplicationPool myApp;
                if (mgr.ApplicationPools[applicationPool] != null)
                {
                    myApp = mgr.ApplicationPools[applicationPool];
                }
                else
                {
                    myApp = mgr.ApplicationPools.Add(applicationPool);
                }

                ApplicationPoolCollection appColl = mgr.ApplicationPools;
                appColl.Remove(myApp);
                mgr.CommitChanges();
            }
        }

        private static int CreateApp(string path)
        {
            int msg = 0;

            try
            {
                using (ServerManager mgr = new ServerManager())
                {
                    if (mgr.Sites["Default Web Site"].Applications["/" + applicationName + ""] != null)
                    {
                    }
                    else
                    {
                        mgr.Sites["Default Web Site"].Applications.Add("/" + applicationName + "", path);
                        mgr.CommitChanges();
                    }


                    Microsoft.Web.Administration.Application app = mgr.Sites["Default Web Site"].Applications["/" + applicationName + ""];

                    ApplicationPool myApp;
                    if (mgr.ApplicationPools[applicationPool] != null)
                    {
                        myApp = mgr.ApplicationPools[applicationPool];
                    }
                    else
                    {
                        myApp = mgr.ApplicationPools.Add(applicationPool);
                    }

                    myApp.AutoStart = true;
                    myApp.ManagedPipelineMode = ManagedPipelineMode.Integrated;
                    myApp.ManagedRuntimeVersion = "v4.0";
                    myApp.Enable32BitAppOnWin64 = true;
                    myApp.ProcessModel.IdentityType = ProcessModelIdentityType.NetworkService;
                    // myApp.Recycle();
                    app.ApplicationPoolName = myApp.Name;

                    mgr.CommitChanges();
                    msg = 1;
                }
            }
            catch
            {
                msg = 0;
            }
            return msg;
        }

        /// <summary>
        /// This method is used for check the database name is exist or not.
        /// </summary>
        /// <param name="tmpConn">Connection</param>
        /// <param name="databaseName">Name Of Database</param>
        /// <param name="ServerName">Name Of Server</param>
        /// <returns>Returns the status</returns>
        private static bool CheckDatabaseExists(SqlConnection tmpConn, string databaseName, string ServerName)
        {
            string sqlCreateDBQuery;
            bool result = false;
            databaseName = applicationName;

            try
            {                
                tmpConn = new SqlConnection("Data Source =" + ServerName + "; Initial Catalog = master; Integrated Security = true;");

                sqlCreateDBQuery = string.Format("SELECT database_id FROM sys.databases WHERE Name = '{0}'", databaseName);

                using (tmpConn)
                {
                    using (SqlCommand sqlCmd = new SqlCommand(sqlCreateDBQuery, tmpConn))
                    {
                        tmpConn.Open();
                        int databaseID = (int)sqlCmd.ExecuteScalar();
                        tmpConn.Close();
                        result = (databaseID > 0);
                    }
                }
            }
            catch (Exception ex)
            {
                string err = ex.ToString(); //Not Used
                result = false;
            }
            return result;
        }

        void CreateDatabase(string sourceDirectory, string Connection1, string WebConfig, string TargetDirectory)
        {
            try
            {
                TextReader trConnection = new StreamReader(System.IO.Path.GetTempPath() + "\\ConnectionString.txt");
                TextReader trServerName = new StreamReader(System.IO.Path.GetTempPath() + "\\ServerName.txt");
                TextReader trDatabaseName = new StreamReader(System.IO.Path.GetTempPath() + "\\DatabaseName.txt");
                TextReader trAuthentication = new StreamReader(System.IO.Path.GetTempPath() + "\\Authentication.txt");

                string userName = "";
                string password = "";
                string Authentication = trAuthentication.ReadLine();

                if (Authentication == "SQL Server Authentication")
                {
                    TextReader trUserName = new StreamReader(System.IO.Path.GetTempPath() + "\\UserName.txt");
                    TextReader trPassword = new StreamReader(System.IO.Path.GetTempPath() + "\\Password.txt");
                    userName = trUserName.ReadLine();
                    password = trPassword.ReadLine();
                }
                else
                {
                    TextReader trUserName = new StreamReader(System.IO.Path.GetTempPath() + "\\UserName.txt");
                    userName = trUserName.ReadLine();
                }

                //Check the sql server existence
                string instanceName = GetNameOfFirstAvailableSQLServerInstance();
                string serverNameNew = @".\SQLEXPRESS";

                if (!string.IsNullOrEmpty(instanceName))
                {                   
                    serverNameNew = instanceName;                    
                }

                SqlConnection tmpConn = new SqlConnection();
                string Databasename = trDatabaseName.ReadLine();
                string ServerName = serverNameNew;
                string Connectionstring = trConnection.ReadLine().Trim();

                bool val = CheckDatabaseExists(tmpConn, Databasename, ServerName);

                //val = false;
                if (val == true)
                {
                    //Create backup of already present database
                    int i = CreateBackupOfDatabase(serverNameNew);

                    //Function to execute the database update script
                    ExecuteDBUpdateScript(ServerName, updateSqlScript);

                    string link = System.Windows.Forms.Application.StartupPath;
                    string Pass = string.Empty;

                    if (Authentication == "SQL Server Authentication")
                    {
                        Pass = "User Id=" + userName + "; Password=" + password + "";
                    }
                    else
                    {
                        Pass = userName;
                    }

                    string onlypath = link;
                    string sBody = "";

                    try
                    {
                        sBody = Connection1;

                        sBody = sBody.Replace("<ServerName>", ServerName);
                        //sBody = sBody.Replace("<User Id>", Pass);
                        sBody = sBody.Replace("<Password>", Pass);
                        sBody = sBody.Replace("<Databasename>", Databasename);                        
                    }
                    catch (Exception ex)
                    {
                        System.Windows.Forms.MessageBox.Show("Error to Write Text File: " + ex.ToString() + "");
                        return;
                    }

                    //Code for Application pool
                    string newDir = TargetDirectory;
                    newDir = newDir.Substring(0, newDir.Length - 1);
                    CreateNewWebsiteInIIS(newDir + @"Publish\");
                    SystemParameters.IsSuccess = true;

                    try
                    {
                        ChangeConfigParameters(Connectionstring);
                    }
                    catch (Exception ex)
                    {
                        System.Windows.Forms.MessageBox.Show("Error to Write Text File Error : " + ex.ToString());
                        return;
                    }
                    SystemParameters.IsSuccess = true;                    
                    return;
                }
                else
                {
                    string str;
                    SqlConnection myConn = new SqlConnection("Server=" + ServerName + ";Integrated security=SSPI;database=master");

                    str = "CREATE DATABASE " + Databasename + "";

                    SqlCommand myCommand = new SqlCommand(str, myConn);

                    try
                    {
                        myConn.Open();
                        myCommand.ExecuteNonQuery();

                        string script = sourceDirectory;

                        string sqlConnectionString = Connectionstring;

                        SqlConnection conn = new SqlConnection(sqlConnectionString);
                        Server server1 = new Server(new ServerConnection(conn));
                        IEnumerable<string> commandStrings = Regex.Split(script, @"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);

                        conn.Open();

                        try
                        {
                            foreach (string commandString in commandStrings)
                            {
                                if (commandString.Trim() != "")
                                {
                                    new SqlCommand(commandString, conn).ExecuteNonQuery();
                                }
                            }
                        }
                        catch
                        {
                        }

                        //MessageBox.Show("database script successfully executed.", "MetasysOpti", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        string link = System.Windows.Forms.Application.StartupPath;
                        string Pass = string.Empty;

                        if (Authentication == "SQL Server Authentication")
                        {
                            Pass = "User Id=" + userName + "; Password=" + password + "";
                        }
                        else
                        {
                            Pass = userName;
                        }

                        string onlypath = link;
                        string sBody = "";

                        try
                        {
                            sBody = Connection1;

                            sBody = sBody.Replace("<ServerName>", ServerName);
                            sBody = sBody.Replace("<Password>", Pass);
                            sBody = sBody.Replace("<Databasename>", Databasename);

                            //MessageBox.Show("Connection1.txt file write successfully.", "MetasysOpti", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error to Write Text File: " + ex.ToString() + "");
                            return;
                        }

                        try
                        {
                            ChangeConfigParameters(Connectionstring);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error to Write Text File Error : " + ex.ToString());
                            return;
                        }

                        //Code for Application pool
                        string newDir = TargetDirectory;
                        newDir = newDir.Substring(0, newDir.Length - 1);
                        CreateNewWebsiteInIIS(newDir + @"Publish\");
                        SystemParameters.IsSuccess = true;

                        conn.Close();
                        return;
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show("Error to create database, When does not exist. Error : " + ex.ToString(), applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        System.Environment.Exit(0);
                        return;
                    }
                    finally
                    {
                        if (myConn.State == ConnectionState.Open)
                        {
                            myConn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to create database. Error : " + ex.ToString(), applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                SystemParameters.IsSuccess = false;
                System.Environment.Exit(0);
                return;
            }
        }

        /// <summary>
        /// Function to create login user with password in sql server
        /// </summary>
        /// <param name="ServerName">string ServerName</param>
        void CreateUser(string ServerName)
        {
            try
            {
                string sqlCreateDBQuery;
                SqlConnection tmpConn;

                //Check whether the user is exists or not
                bool isExists = CheckLoginUserExistence();

                if (!isExists)
                {
                    tmpConn = new SqlConnection("server=" + ServerName + ";Trusted_Connection=yes");

                    sqlCreateDBQuery = string.Format("use master CREATE LOGIN [" + databaseUserName + "] WITH PASSWORD='" + databasePassword + "', CHECK_POLICY=OFF;");
                    sqlCreateDBQuery += "exec sp_addsrvrolemember '" + databaseUserName + "', 'bulkadmin';";
                    sqlCreateDBQuery += "exec sp_addsrvrolemember '" + databaseUserName + "', 'dbcreator';";
                    sqlCreateDBQuery += "exec sp_addsrvrolemember '" + databaseUserName + "', 'securityadmin';";
                    sqlCreateDBQuery += "exec sp_addsrvrolemember '" + databaseUserName + "', 'sysadmin';";

                    using (tmpConn)
                    {
                        try
                        {
                            string Query = "use master exec sp_droplogin N'" + databaseUserName + "'";

                            using (SqlCommand sqlCmd = new SqlCommand(Query, tmpConn))
                            {
                                if (tmpConn.State == ConnectionState.Closed)
                                {
                                    tmpConn.Open();
                                }

                                sqlCmd.ExecuteNonQuery();
                                tmpConn.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            //MessageBox.Show("Error while creating user : " + ex.ToString(), "MetasysOpti", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            tmpConn.Close();
                        }

                        using (SqlCommand sqlCmd = new SqlCommand(sqlCreateDBQuery, tmpConn))
                        {
                            tmpConn.Open();
                            sqlCmd.ExecuteNonQuery();
                            tmpConn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                return;
            }
        }

        /// <summary>
        /// Function to check the IIS version for local machine
        /// </summary>
        public void CheckIISVersion()
        {
            int iisVersion = 0;
            try
            {
                using (RegistryKey iisKey = Registry.LocalMachine.OpenSubKey(@"Software\Microsoft\InetStp", false))
                {
                    if (iisKey != null)
                    {
                        int majorVersion = (int)iisKey.GetValue("MajorVersion", -1);
                        int minorVersion = (int)iisKey.GetValue("MinorVersion", -1);
                        //if (majorVersion != -1 && minorVersion != -1)
                        if (majorVersion != -1 && majorVersion > 6)
                        {
                            iisVersion = majorVersion;
                            //MessageBox.Show("Installed IIS version :" + Convert.ToString(iisVersion), "IIS Version Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Please install IIS version 7 or greater in your system", "IIS Version Information", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
                            //System.Windows.Forms.Application.Exit();
                            System.Environment.Exit(0);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("IIS is not installed on this machine. Please install it first to run this application.", "IIS Installation", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
                        //System.Windows.Forms.Application.Exit();
                        System.Environment.Exit(0);
                        return;
                    }
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Function to check wether the IIS is running or not on local machine
        /// </summary>
        public void CheckIISStatus()
        {
            try
            {
                ServiceController sc = new ServiceController("World Wide Web Publishing Service");
                if ((sc.Status.Equals(ServiceControllerStatus.Stopped) || sc.Status.Equals(ServiceControllerStatus.StopPending)))
                {
                    MessageBox.Show("IIS is not running", "IIS Status", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
                    //sc.Start();
                    //System.Windows.Forms.Application.Exit();
                    System.Environment.Exit(0);
                    return;
                }
                else
                {
                    //MessageBox.Show("IIS is running", "IIS Status", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);           
                    //sc.Stop();
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Function to check the information of operating system
        /// </summary>
        /// <returns>Integer</returns>
        public int CheckOSInformation()
        {
            System.OperatingSystem osInfo = null;
            try
            {
                osInfo = System.Environment.OSVersion;
            }
            catch
            {
            }
            return osInfo.Version.Major;
        }

        /// <summary>
        /// Function to get the first available sql server instance
        /// </summary>
        /// <returns>string</returns>
        public string GetNameOfFirstAvailableSQLServerInstance()
        {
            string instanceName = string.Empty;
            try
            {
                // Only search local instances - pass true to EnumAvailableSqlServers
                DataTable dataTable = SmoApplication.EnumAvailableSqlServers(true);
                DataRow firstRow = dataTable.Rows[0];
                instanceName = Convert.ToString(firstRow["Name"]);
                //MessageBox.Show(instanceName, "SQL Server Instance Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //New condition added (8-Oct-14)
                //START
                if (instanceName.Contains(@"\") && !instanceName.Contains("SQLEXPRESS"))
                {
                    string[] array = instanceName.Split('\\');
                    instanceName = array[0];
                    instanceName = array[0] + @"\SQLEXPRESS";
                    //MessageBox.Show("Instance name : " + instanceName);
                }
                //END

                if (!instanceName.Contains("SQLEXPRESS"))
                {
                    instanceName = instanceName + @"\SQLEXPRESS";
                }

                //MessageBox.Show("Final Instance name : " + instanceName);
            }
            catch
            {
            }
            return instanceName;
        }

        /// <summary>
        /// Function to update connection string in the web.config file
        /// </summary>
        /// <param name="configPath">string configPath</param>
        /// <param name="serverName">string serverName</param>
        private void UpdateConnectionString(string configPath, string serverName)
        {
            try
            {
                XmlDocument xmlDocument = new XmlDocument();
                xmlDocument.Load(configPath);
                XmlNode parentNode = xmlDocument.DocumentElement;
                if (parentNode.Name == "connectionStrings")
                {
                    foreach (XmlNode childNode in parentNode.ChildNodes)
                    {
                        if (childNode.Name == "add" && childNode.Attributes["name"].Value == "constr")
                        {
                            string sqlConnectionString = childNode.Attributes["connectionString"].Value;
                            SqlConnectionStringBuilder sqlBuilder = new SqlConnectionStringBuilder(sqlConnectionString);
                            sqlBuilder.DataSource = serverName;
                            sqlBuilder.InitialCatalog = applicationName;
                            //sqlBuilder.IntegratedSecurity = true;
                            sqlBuilder.UserID = databaseUserName;
                            sqlBuilder.Password = databasePassword;

                            //Change any other attributes using the sqlBuilder object
                            childNode.Attributes["connectionString"].Value = sqlBuilder.ConnectionString;
                        }
                    }
                }
                xmlDocument.Save(configPath);
            }
            catch
            {
            }
        }

        /// <summary>
        /// Function to create new website in IIS
        /// </summary>
        public void CreateNewWebsiteInIIS(string path)
        {
            try
            {
                string strWebsitename = applicationName;
                string strApplicationPool = applicationPool;

                string hostName = Dns.GetHostName();
                string myIP = Convert.ToString(Dns.GetHostByName(hostName).AddressList[0]);


                //Use this line to create site with localhost configuration
                  string ip = "*";
                  int port = 1007;
                  string hostNameStr = "localhost";
                  string bindinginfo = string.Format(@"{0}:{1}:{2}", ip, port, hostNameStr);

                //check if website name already exists in IIS
                Boolean bWebsite = IsWebsiteExists(strWebsitename);

                if (!bWebsite)
                {
                    //Site mySite = serverMgr.Sites.Add(strWebsitename.ToString(), "http", bindinginfo, path);

                    //For localhost setting
                    //START                   
                    //Site mySite = serverMgr.Sites.Add(strWebsitename.ToString(), "C:\\inetpub\\wwwroot\\MetasysOpti", port);
                    Site mySite = serverMgr.Sites.Add(strWebsitename.ToString(), "http", bindinginfo, path);
                    
                    //Site mySite = serverMgr.Sites.Add(strWebsitename.ToString(), path, port);
                    //mySite.Bindings.Add(string.Format(@"{0}:{1}:{2}", ip, port, hostNameStr), "http");                    
                                       
                    //END

                    mySite.ApplicationDefaults.ApplicationPoolName = strApplicationPool;
                    mySite.TraceFailedRequestsLogging.Enabled = true;
                    mySite.TraceFailedRequestsLogging.Directory = "C:\\inetpub\\customfolder\\site";
                    serverMgr.CommitChanges();

                    ApplicationPool myApp;
                    if (serverMgr.ApplicationPools[applicationPool] != null)
                    {
                        myApp = serverMgr.ApplicationPools[applicationPool];
                    }
                    else
                    {
                        myApp = serverMgr.ApplicationPools.Add(applicationPool);
                    }

                    myApp.AutoStart = true;
                    myApp.ManagedPipelineMode = ManagedPipelineMode.Integrated;
                    myApp.ManagedRuntimeVersion = "v4.0";
                    myApp.Enable32BitAppOnWin64 = true;
                    //Commented to test the code for ZIP file creation and updation in database
                    //As this setting works well with the installer I have not removed it and used it for generating installer for site
                    //myApp.ProcessModel.IdentityType = ProcessModelIdentityType.NetworkService;
                    myApp.ProcessModel.IdentityType = ProcessModelIdentityType.LocalSystem;
                    // myApp.Recycle();                   
                    serverMgr.CommitChanges();

                    //CHange url for shortcut icon
                    CreateShortcutIconOnDesktop();
                    // MessageBox.Show("New website  " + strWebsitename + " added sucessfully", "Site Creation", MessageBoxButtons.OK, MessageBoxIcon.Information);                    
                }
                else
                {
                    MessageBox.Show("The website name " + strWebsitename + " is already exists in IIS.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Function to check whether site name is already exists in IIS or not 
        /// </summary>
        /// <param name="strWebsitename">string strWebsitename</param>
        /// <returns>bool</returns>
        public bool IsWebsiteExists(string strWebsitename)
        {
            Boolean flagset = false;
            try
            {
                SiteCollection sitecollection = serverMgr.Sites;
                foreach (Site site in sitecollection)
                {
                    if (site.Name == strWebsitename.ToString())
                    {
                        flagset = true;
                        break;
                    }
                    else
                    {
                        flagset = false;
                    }
                }
            }
            catch
            {
            }
            return flagset;
        }

        /// <summary>
        /// Function to check the existence of user in server
        /// </summary>
        /// <returns>bool</returns>
        public bool CheckLoginUserExistence()
        {
            bool isExists = false;
            SqlConnection tmpConn = null;
            string sqlCreateDBQuery;
            try
            {
                string serverName = GetNameOfFirstAvailableSQLServerInstance();
                tmpConn = new SqlConnection("server=" + serverName + ";Trusted_Connection=yes");
                sqlCreateDBQuery = string.Format("SELECT name FROM master.sys.server_principals WHERE name = '" + databaseUserName + "'");

                using (tmpConn)
                {
                    try
                    {
                        using (SqlCommand sqlCmd = new SqlCommand(sqlCreateDBQuery, tmpConn))
                        {
                            if (tmpConn.State == ConnectionState.Closed)
                            {
                                tmpConn.Open();
                            }

                            DataTable dtUser = new DataTable();
                            SqlDataAdapter a = new SqlDataAdapter(sqlCmd);

                            a.Fill(dtUser);

                            if (dtUser != null && dtUser.Rows.Count > 0)
                            {
                                isExists = true;
                                // MessageBox.Show("User already exists", "User Detail", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        tmpConn.Close();
                    }
                }
            }
            catch
            {
            }
            return isExists;
        }

        /// <summary>
        /// Function to create backup of database while installing the application and if the database exists prior to installtion
        /// </summary>
        /// <param name="serverName">string serverName</param>
        /// <returns>Integer</returns>
        public int CreateBackupOfDatabase(string serverName)
        {
            #region Commented Code

            int returnVal = 0;
            /*
            try
            {
                string connStr = "Data Source=" + serverName + ";Initial Catalog=MetasysOpti; User Id=MetasysOptiUser; Password=MetasysOptiUser;";                

                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string sqlStmt = String.Format("ALTER LOGIN [MetasysOptiUser] WITH DEFAULT_DATABASE = master; BACKUP DATABASE MetasysOpti TO DISK='{0}'", @"C:\\Program Files");

                    using (SqlCommand bu2 = new SqlCommand(sqlStmt, conn))
                    {
                        conn.Open();
                        bu2.ExecuteNonQuery();
                        conn.Close();
                        returnVal = 1;
                        MessageBox.Show("Backup of database 'MetasysOpti' generated successfully");
                    }
                }
            }
            catch(Exception ex)
            {
                returnVal = 0;
                MessageBox.Show("Error occured in generating backup for database 'MetasysOpti'." + ex.Message);
                System.Windows.Forms.Application.Exit();                
            }
         * */
            #endregion Commented Code

            try
            {
                const string path = @"C:\DBBackups\";

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                Random rnd = new Random();
                int number = rnd.Next(1, 5000);

                SqlCommand cmd = new SqlCommand();
                SqlConnection conn = new SqlConnection("Data Source=" + serverName + "; Initial Catalog=" + applicationName + "; User Id=" + databaseUserName + "; Password = " + databasePassword + ";");
                cmd.CommandText = String.Format("BACKUP DATABASE " + applicationName + " TO DISK='{0}'", path + applicationName + Convert.ToString(number) + ".BAK");
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                returnVal = 1;
                //MessageBox.Show("Bakup of database MetasysOpti created successfully", "Server", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception x)
            {
                MessageBox.Show("ERROR: An error ocurred while backing up dataBase" + x, "Server Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }
            return returnVal;
        }

        /// <summary>
        /// Function to restore the database ( Pass the path to the back up directory and the name of the .bak file to restore.)
        /// </summary>
        /// <param name="filePath">string filePath</param>
        /// <param name="fileName">string fileName</param>
        /// <param name="serverName">string serverName</param>
        /// <returns>bool</returns>        
        public bool RestoreDB(string filePath, string fileName, string serverName)
        {
            filePath = @"C:\DBBackups\";
            fileName = applicationName + ".BAK";

            bool restoreComplete = false;
            SqlConnection conn = new SqlConnection("Data Source=" + serverName + "; Initial Catalog = " + applicationName + "; User Id = " + databaseUserName + "; Password = " + databasePassword + ";");
            conn.Open();
            System.Data.SqlClient.SqlCommand sqlDBrestoreCommand = new System.Data.SqlClient.SqlCommand();
            sqlDBrestoreCommand.Connection = conn;

            try
            {
                sqlDBrestoreCommand.CommandText = "Use Master";
                sqlDBrestoreCommand.ExecuteNonQuery();
                sqlDBrestoreCommand.CommandText = "ALTER DATABASE " + applicationName + " SET SINGLE_USER WITH ROLLBACK IMMEDIATE;";
                sqlDBrestoreCommand.ExecuteNonQuery();
                sqlDBrestoreCommand.CommandText = "RESTORE DATABASE " + applicationName + " FROM DISK = '" + filePath + fileName + "';";
                sqlDBrestoreCommand.ExecuteNonQuery();
                sqlDBrestoreCommand.CommandText = "Use Master";
                sqlDBrestoreCommand.ExecuteNonQuery();
                sqlDBrestoreCommand.CommandText = "ALTER DATABASE " + applicationName + " SET MULTI_USER;";
                sqlDBrestoreCommand.ExecuteNonQuery();
                restoreComplete = true;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error occurred while restoring the database. " + Convert.ToString(ex.Message));
            }
            finally
            {
                conn.Close();
            }
            return restoreComplete;
        }

        /// <summary>
        /// Function to delete the database backup from the system
        /// </summary>
        public void DeleteDatabaseFromSystem()
        {
            try
            {
                string serverName = string.Empty;
                if (Environment.Is64BitOperatingSystem)
                {
                    RegistryKey rk64 = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\" + companyName + @"\" + applicationName + @"\ODS");
                    if (rk64 != null)
                    {
                        serverName = (string)rk64.GetValue("DBServer");
                    }
                }
                else
                {
                    RegistryKey rk32 = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\" + companyName + @"\" + applicationName + @"\ODS");
                    if (rk32 != null)
                    {
                        serverName = (string)rk32.GetValue("DBServer");
                    }
                }

                string srvrName = string.Empty;
                if (string.IsNullOrEmpty(serverName))
                {
                    srvrName = GetNameOfFirstAvailableSQLServerInstance();
                    if (string.IsNullOrEmpty(srvrName))
                    {
                        srvrName = @".\SQLEXPRESS";
                    }
                }

                serverName = srvrName;

                string connectionString = "Data Source=" + serverName + ";Initial Catalog=" + applicationName + ";User Id=" + databaseUserName + "; Password=" + databasePassword + ";";

                SqlConnection tmpConn;
                //tmpConn = new SqlConnection("server=" + serverName + ";Trusted_Connection=yes");
                tmpConn = new SqlConnection("Data Source=" + serverName + "; Initial Catalog = master; Integrated Security = true;");
                using (tmpConn)
                {
                    try
                    {
                        string Query = "";
                        Query += "USE master; ALTER DATABASE " + applicationName + " SET SINGLE_USER WITH ROLLBACK IMMEDIATE; ";
                        Query += "DROP DATABASE " + applicationName + ";";

                        using (SqlCommand sqlCmd = new SqlCommand(Query, tmpConn))
                        {
                            tmpConn.Open();
                            sqlCmd.ExecuteNonQuery();
                            tmpConn.Close();
                            MessageBox.Show("Database deleted successfully");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occurred while deleting the database. " + Convert.ToString(ex.Message));
                    }
                    finally
                    {
                        tmpConn.Close();
                    }
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Function to drop user from database
        /// </summary>
        /// <param name="serverName">string serverName</param>
        void DropUser(string serverName)
        {
            try
            {
                SqlConnection tmpConn;
                tmpConn = new SqlConnection("server=" + serverName + ";Trusted_Connection=yes");
                using (tmpConn)
                {
                    try
                    {
                        string query = "Use Master exec sp_droplogin N'" + databaseUserName + "'";

                        using (SqlCommand sqlCmd = new SqlCommand(query, tmpConn))
                        {
                            tmpConn.Open();
                            sqlCmd.ExecuteNonQuery();
                            tmpConn.Close();
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        tmpConn.Close();
                    }
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Function to set mixed authentication mode for sql server 2008
        /// </summary>
        /// <param name="dataSource">string dataSource</param>
        /// <returns>bool</returns>
        public bool SetServerProperties(string dataSource)
        {
            return false;
            /*
            #region standardize Connection String
            string tempCatalog = "master";
            string temp = @"Data Source=" + dataSource + ";Initial Catalog=" + tempCatalog + ";Integrated Security=True;MultipleActiveResultSets=True";
            #endregion

            SqlConnection sqlconnection = new SqlConnection(temp);
            SqlCommand cmd = new SqlCommand("select @@ServerName", sqlconnection);
            sqlconnection.Open();
            string serverName = "";
            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                    serverName = dr[0].ToString();
            }
            catch
            {
                MessageBox.Show("Failed to Set SQL Server Properties for remote connections.");
            }

            Server srv = new Server(serverName);
            srv.ConnectionContext.Connect();
            srv.Settings.LoginMode = "Mixed";
                //ServerLoginMode.Mixed;

            ManagedComputer mc = new ManagedComputer();

            try
            {
                Service Mysvc = mc.Services["MSSQL$" + serverName.Split('\\')[1]];

                if (Mysvc.ServiceState == ServiceState.Running)
                {
                    Mysvc.Stop();
                    Mysvc.Alter();

                    while (!(string.Format("{0}", Mysvc.ServiceState) == "Stopped"))
                    {
                        Mysvc.Refresh();
                    }
                }

                ServerProtocol srvprcl = mc.ServerInstances[0].ServerProtocols[2];
                srvprcl.IsEnabled = true;
                srvprcl.Alter();


                Mysvc.Start();
                Mysvc.Alter();

                while (!(string.Format("{0}", Mysvc.ServiceState) == "Running"))
                {
                    Mysvc.Refresh();
                }
                return true;
            }
            catch
            {
                MessageBox.Show("TCP/IP connectin could not be enabled.");
                return false;
            }           */
        }

        /// <summary>
        /// Funtion to set the mixed authentication mode for sql server
        /// </summary>
        public void SetMixedAuthenticationModeForSQLServer(string serverName)
        {
            try
            {
                SqlConnection tmpConn;
                //tmpConn = new SqlConnection("server=" + serverName + ";Trusted_Connection=yes");
                tmpConn = new SqlConnection("Data Source=" + serverName + "; Initial Catalog = master; Integrated Security=true;");
                using (tmpConn)
                {
                    try
                    {
                        string query = @"EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2";
                        using (SqlCommand sqlCmd = new SqlCommand(query, tmpConn))
                        {
                            tmpConn.Open();
                            sqlCmd.ExecuteNonQuery();
                            tmpConn.Close();
                            // MessageBox.Show("SQL server authentication mode updated to mixed mode");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occured in updating the sql server authentication mode " + ex.Message);
                    }
                    finally
                    {
                        tmpConn.Close();
                    }
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Function to write the registry key value for sql server 2008 express edition
        /// </summary>        
        public void WriteRegistryKey()
        {
            try
            {
                RegistryKey regKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\MSSQLServer\\MSSQLServer", true);
                MessageBox.Show(regKey.Name);
                if (regKey != null)
                {
                    regKey.SetValue("LoginMode", "2", RegistryValueKind.DWord);
                    regKey.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occured while updating the SQL server authentication mode" + Convert.ToString(ex.Message), "Information", MessageBoxButtons.OK);
            }
        }

        /// <summary>
        /// Function to restart the service of the sql server 2008 express
        /// </summary>
        public void RestartSQLServerService()
        {
            try
            {
                ServiceController sc = new ServiceController("MSSQL$SQLEXPRESS");
                if (sc != null)
                {
                    //MessageBox.Show(Convert.ToString(sc.Status));
                    if (sc.Status.Equals(ServiceControllerStatus.Running))
                    {
                        //MessageBox.Show("SQL server service will be restarted...", "Service restart", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        sc.Refresh();
                        sc.Stop();
                        System.Threading.Thread.Sleep(12 * 1000);
                        //MessageBox.Show(Convert.ToString(sc.Status));
                        System.Threading.Thread.Sleep(15 * 1000);
                        sc.Start();
                        //MessageBox.Show(Convert.ToString(sc.Status));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occured in restarting the sql server service. " + ex.Message);
            }
        }

        /// <summary>
        /// Function to execute the command from C# code
        /// </summary>        
        public void ExecuteCommandAsAdmin()
        {
            try
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                startInfo.RedirectStandardError = true;
                startInfo.RedirectStandardOutput = true;
                startInfo.UseShellExecute = false;
                startInfo.CreateNoWindow = true;
                startInfo.FileName = "cmd.exe";
                startInfo.Arguments = "/user:Administrator cmd /K " + @"C:\Windows\Microsoft.NET\Framework\v4.0.30319\aspnet_regiis.exe -i ";
                process.StartInfo = startInfo;
                process.Start();
                System.Threading.Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
            }
        }

        /// <summary>`
        /// Function to create the shortcut on desktop with customized link
        /// </summary>
        public void CreateShortcutIconOnDesktop()
        {
            try
            {
                #region commented code
                //string hostName = Dns.GetHostName();
                //string myIP = Convert.ToString(Dns.GetHostByName(hostName).AddressList[0]);
                //string bindinginfo = myIP + ":80:";
                ////using (StreamWriter sw = new StreamWriter(TargetDirectory + "\\MetasysOpti.url"))
                //using (StreamWriter sw = new StreamWriter("C:\\Users\\Public\\Desktop\\MetasysOpti.url")) {                    

                //    string url = @"http://" + bindinginfo + "//Default.aspx";
                //    sw.WriteLine("[InternetShortcut]");
                //    sw.WriteLine("URL=" + url);
                //    sw.WriteLine("IDList=");
                //    sw.WriteLine("HotKey=0");
                //    sw.WriteLine("[{000214A0-0000-0000-C000-000000000046}]");
                //    sw.WriteLine("Prop3=19,2");
                //    sw.Flush();
                //    sw.Close();
                //}
                #endregion

                string hostName = Dns.GetHostName();
                string myIP = Convert.ToString(Dns.GetHostByName(hostName).AddressList[0]);
                //string bindinginfo = myIP + ":80";
                string bindinginfo = "localhost:1007";

                string deskDir = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

                //MessageBox.Show("Aplication startup path : " + System.Windows.Forms.Application.StartupPath, "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
                //MessageBox.Show("Aplication executable path : " + System.Windows.Forms.Application.ExecutablePath, "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);

                //MessageBox.Show("Aplication executing assembly path : " + System.Reflection.Assembly.GetExecutingAssembly().CodeBase, "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
                string fullPathWithExe = System.Reflection.Assembly.GetExecutingAssembly().CodeBase; // Output : C:\Program Files\Johnson Controls\MetasysOpti\MetasysOptiInstaller.exe
                string mainFolderPath = fullPathWithExe.Substring(0, fullPathWithExe.LastIndexOf('/'));
                //MessageBox.Show("Final path : " + mainFolderPath, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
                string iconPath = mainFolderPath.Substring(8, mainFolderPath.Length - 8) + "/App.ico";
                //iconPath = iconPath.Replace('/', '\\');
                //MessageBox.Show("Icon path : " + iconPath, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);

                using (StreamWriter writer = new StreamWriter(deskDir + "\\" + "" + applicationName + ".url"))
                {
                    writer.WriteLine("[InternetShortcut]");
                    writer.WriteLine("URL=" + "http://" + bindinginfo + "/Default.aspx");
                    writer.WriteLine("IconIndex=0");
                    writer.WriteLine("IconFile=" + iconPath);
                    writer.Flush();
                    writer.Close();
                }

                //Create shortcut in startup folder in all programs
                //string startUpDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
                //using (StreamWriter writer = new StreamWriter(startUpDirectory + "\\" + "MetasysOpti.url"))
                //{
                //    writer.WriteLine("[InternetShortcut]");
                //    writer.WriteLine("URL=" + "http://" + bindinginfo + "/Default.aspx");
                //    writer.WriteLine("IconIndex=0");
                //    writer.WriteLine("IconFile=" + iconPath);
                //    writer.Flush();
                //    writer.Close();
                //}

                //Create shortcut in All programs folder
                string allProgDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Programs);
                using (StreamWriter writer = new StreamWriter(allProgDirectory + "\\" + "" + applicationName + ".url"))
                {
                    writer.WriteLine("[InternetShortcut]");
                    writer.WriteLine("URL=" + "http://" + bindinginfo + "/Default.aspx");
                    writer.WriteLine("IconIndex=0");
                    writer.WriteLine("IconFile=" + iconPath);
                    writer.Flush();
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
            }
        }

        /// <summary>
        /// Function to execute update script in db
        /// </summary>
        /// <param name="scriptFilePath">string scriptFilePath</param>
        public void ExecuteDBUpdateScript(string serverName, string scriptFile)
        {
            try
            {
                SqlConnection myConn = new SqlConnection("Data source =" + serverName + "; Initial Catalog = " + applicationName + "; User Id = " + databaseUserName + "; Password=" + databasePassword + ";");
                Server server1 = new Server(new ServerConnection(myConn));
                IEnumerable<string> commandStrings = Regex.Split(scriptFile, @"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                myConn.Open();

                foreach (string commandString in commandStrings)
                {
                    if (commandString.Trim() != "")
                    {
                        new SqlCommand(commandString, myConn).ExecuteNonQuery();
                    }
                }

                myConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public void ExecutePowerShellScript(string scriptText)
        {
            string results = string.Empty;
            try
            {
                // create Powershell runspace
                Runspace runspace = RunspaceFactory.CreateRunspace();

                // open it
                runspace.Open();

                // create a pipeline and feed it the script text
                Pipeline pipeline = runspace.CreatePipeline();
                //pipeline.Commands.AddScript(scriptText);
                pipeline.Commands.AddScript("$t=new-object PowerShellExecutionSample.TestObject;" + "$t.Name='create from inside PowerShell script'; $t;" + "$message==[PowerShellExecutionSample.TestStaticClass]::TestStaticMethod();$messafe");

                // add an extra command to transform the script
                // output objects into nicely formatted strings

                // remove this line to get the actual objects
                // that the script returns. For example, the script

                // "Get-Process" returns a collection
                // of System.Diagnostics.Process instances.

                pipeline.Commands.Add("Out-String");

                // execute the script

                // Collection<psobject /> results = pipeline.Invoke();

                pipeline.Invoke();

                // close the runspace

                runspace.Close();

                // convert the script result into a single string

                //StringBuilder stringBuilder = new StringBuilder();
                //foreach (PSObject obj in results)
                //{
                //    stringBuilder.AppendLine(obj.ToString());
                //}

                //MessageBox.Show(stringBuilder.ToString());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private string GetFileContent(string Name)
        {
            try
            {
                try
                {
                    Assembly Asm = Assembly.GetExecutingAssembly();

                    using (Stream strm = @Assembly.GetExecutingAssembly().GetManifestResourceStream("PHFacilityInstaller." + Name))
                    {
                        StreamReader reader = new StreamReader(strm);
                        return reader.ReadToEnd();// Use strm here.  
                    }
                }
                catch
                {
                    MessageBox.Show("Error reading from Assembly" + Name);
                    return null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to Read Text File: " + ex.ToString() + "");
                return null;
            }
        }
    }
}
