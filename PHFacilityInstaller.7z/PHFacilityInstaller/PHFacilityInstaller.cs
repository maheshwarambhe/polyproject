﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.Data.SqlClient;
using System.IO;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Reflection;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Windows.Forms;
using Microsoft.Web.Administration;
using Microsoft.Win32;

namespace PHFacilityInstaller
{
    static class ComACLRights
    {
        public const int COM_RIGHTS_EXECUTE = 1;
        public const int COM_RIGHTS_EXECUTE_LOCAL = 2;
        public const int COM_RIGHTS_EXECUTE_REMOTE = 4;
        public const int COM_RIGHTS_ACTIVATE_LOCAL = 8;
        public const int COM_RIGHTS_ACTIVATE_REMOTE = 16;
    }   

    [RunInstaller(true)]
    public partial class PHFacilityInstaller : System.Configuration.Install.Installer
    {
        public static string applicationName = "PHFacility";
        public static string applicationPool = "PHFacility_AppPool";
        public static string companyName = "Delmon Solutions";
        public static string databaseUserName = "PHFacilityUser";
        public static string databasePassword = "PHFacilityUser";

        public PHFacilityInstaller()
        {
            InitializeComponent();
        }

        private static void DeleteApp()
        {
            try
            {
                using (ServerManager mgr = new ServerManager())
                {
                    if (mgr.Sites[applicationName] != null)
                    {
                        Site s1 = mgr.Sites[applicationName]; // you can pass the site name or the site ID
                        mgr.Sites.Remove(s1);
                        mgr.CommitChanges();
                    }

                    //Remove application pool for the site
                    ApplicationPool myApp;

                    if (mgr.ApplicationPools[applicationPool] != null)
                    {
                        myApp = mgr.ApplicationPools[applicationPool];
                        ApplicationPoolCollection appColl = mgr.ApplicationPools;
                        appColl.Remove(myApp);
                        mgr.CommitChanges();
                    }
                }
            }
            catch
            {

            }
        }

        protected override void OnBeforeInstall(IDictionary savedState)
        {
            try
            {
                base.OnBeforeInstall(savedState);
            }
            catch
            {

            }
        }

        public override void Rollback(IDictionary savedState)
        {
            try
            {
                base.Rollback(savedState);
            }
            catch
            {
            }
        }

        void DeleteDatabaseBackup()
        {
            try
            {
                string serverName = string.Empty;

                if (Environment.Is64BitOperatingSystem)
                {
                    RegistryKey rk64 = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\" + companyName + @"\" + applicationName + @"\ODS");
                    serverName = (string)rk64.GetValue("DBServer");
                }
                else
                {
                    RegistryKey rk32 = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\" + companyName + @"\" + applicationName + @"\ODS");
                    serverName = (string)rk32.GetValue("DBServer");
                }

                string connectionString = "Data Source=" + serverName + "; Initial Catalog=" + applicationName + ";User Id=" + databaseUserName + "; Password=" + databasePassword + ";";

                SqlConnection tmpConn;
                tmpConn = new SqlConnection("server=" + serverName + ";Trusted_Connection=yes");

                using (tmpConn)
                {
                    try
                    {
                        string Query = "";
                        Query += "Use master ";
                        Query += "drop DATABASE " + applicationName + "";

                        using (SqlCommand sqlCmd = new SqlCommand(Query, tmpConn))
                        {
                            tmpConn.Open();
                            sqlCmd.ExecuteNonQuery();
                            tmpConn.Close();
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        tmpConn.Close();
                    }
                }
            }
            catch
            {
            }
        }

        void DropUser(string serverName)
        {
            try
            {
                SqlConnection tmpConn;
                tmpConn = new SqlConnection("server=" + serverName + ";Trusted_Connection=yes");
                using (tmpConn)
                {
                    try
                    {
                        string query = "Use Master exec sp_droplogin N'" + databaseUserName + "'";

                        using (SqlCommand sqlCmd = new SqlCommand(query, tmpConn))
                        {
                            tmpConn.Open();
                            sqlCmd.ExecuteNonQuery();
                            tmpConn.Close();
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        tmpConn.Close();
                    }
                }
            }
            catch
            {
            }
        }

        public override void Commit(IDictionary savedState)
        {
            try
            {
                base.Commit(savedState);
            }
            catch
            {
            }
        }

        protected override void OnAfterInstall(System.Collections.IDictionary savedState)
        {
            try
            {
                if (Environment.Is64BitOperatingSystem)
                {
                    writeRegKey64("Installed", "1");

                    try
                    {
                        //Permission to this folder is applied to make the excel sheet generation and also for some other reason
                        if (!Directory.Exists(@"C:\Windows\SysWOW64\config\systemprofile\Desktop"))
                        {
                            //For 64-bit operating system
                            Directory.CreateDirectory(@"C:\Windows\SysWOW64\config\systemprofile\Desktop");
                        }

                        //For 32-bit operating system
                        SetPermission(@"C:\Windows\SysWOW64\config\systemprofile\Desktop");

                        //For aplying the permission to web site created through installer
                        string publishPath = @"C:\Program Files (x86)\" + companyName + @"\" + applicationName + @"\Publish";

                        if (Directory.Exists(publishPath))
                        {
                            SetPermission(publishPath);
                        }
                    }
                    catch
                    {
                    }
                }
                else
                {
                    writeRegKey("Installed", "1");

                    try
                    {
                        if (!Directory.Exists(@"C:\Windows\System32\config\systemprofile\Desktop"))
                        {
                            Directory.CreateDirectory(@"C:\Windows\System32\config\systemprofile\Desktop");
                        }
                    }
                    catch
                    {
                    }

                    try
                    {
                        SetPermission(@"C:\Windows\System32\config\systemprofile\Desktop");
                    }
                    catch
                    {
                    }
                }

                base.OnAfterInstall(savedState);
            }
            catch
            {
            }
        }

        public void deleteRegKey64(string keyName)
        {
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Wow6432Node\\" + companyName + "\\" + applicationName + "", true))
            {
                if (key != null)
                {
                    key.DeleteValue(keyName);
                }
            }

            using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Wow6432Node\\Wow6432Node\\" + companyName + "\\" + applicationName + "", true))
            {
                if (key != null)
                {
                    key.DeleteValue(keyName);
                }
            }

            using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\" + companyName + "", true))
            {
                if (key != null)
                {
                    key.DeleteSubKeyTree(applicationName);
                }
            }
        }

        public void deleteRegKey(string keyName)
        {
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\" + companyName + "\\" + applicationName + "", true))
            {
                if (key != null)
                {
                    key.DeleteValue(keyName);
                }
            }

            using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Wow6432Node\\" + companyName + "\\" + applicationName + "", true))
            {
                if (key != null)
                {
                    key.DeleteValue(keyName);
                }
            }

            using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Wow6432Node\\Wow6432Node\\" + companyName + "\\" + applicationName + "", true))
            {
                if (key != null)
                {
                    key.DeleteValue(keyName);
                }
            }

            using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\" + companyName + "", true))
            {
                if (key != null)
                {
                    key.DeleteSubKeyTree(applicationName);
                }
            }
        }

        public void writeRegKey64(string keyName, string keyValue)
        {
            RegistryKey regKeyWrite = Registry.LocalMachine;
            regKeyWrite = regKeyWrite.CreateSubKey("SOFTWARE\\Wow6432Node\\" + companyName + "\\" + applicationName + "");
            regKeyWrite.SetValue(keyName, keyValue);
            regKeyWrite.Close();
        }

        public Object readRegKey64(string keyName)
        {
            RegistryKey regKeyRead = Registry.LocalMachine;
            regKeyRead = regKeyRead.OpenSubKey("SOFTWARE\\Wow6432Node\\" + companyName + "\\" + applicationName + "");

            if (regKeyRead == null)
            {
                return null;
            }

            Object regTry = regKeyRead.GetValue(keyName);
            regKeyRead.Close();
            return regTry;
        }

        public void writeRegKey(string keyName, string keyValue)
        {
            RegistryKey regKeyWrite = Registry.LocalMachine;
            regKeyWrite = regKeyWrite.CreateSubKey("SOFTWARE\\" + companyName + "\\" + applicationName + "");
            regKeyWrite.SetValue(keyName, keyValue);
            regKeyWrite.Close();
        }

        public Object readRegKey(string keyName)
        {
            RegistryKey regKeyRead = Registry.LocalMachine;
            regKeyRead = regKeyRead.OpenSubKey("SOFTWARE\\" + companyName + "\\" + applicationName + "");

            if (regKeyRead == null)
            {
                return null;
            }

            Object regTry = regKeyRead.GetValue(keyName);
            regKeyRead.Close();
            return regTry;
        }

        public override void Install(System.Collections.IDictionary stateSaver)
        {

            string script = GetFileContent("Script.sql");
            // MessageBox.Show(script);
            string Connection1 = GetFileContent("Connection1.txt");
            // MessageBox.Show(Connection1);
            string webconfig = GetFileContent("Web.config");
            // MessageBox.Show(webconfig);
            string TargetDirectory = this.Context.Parameters["TargetDir"];
            //MessageBox.Show(TargetDirectory);
            string updateSqlScript = GetFileContent("UpdateScript.sql");

            if (string.IsNullOrEmpty(TargetDirectory))
            {
                if (Environment.Is64BitOperatingSystem)
                {
                    TargetDirectory = @"C:\Program Files (x86)\" + companyName + @"\" + applicationName + @"\\";
                }
                else
                {
                    TargetDirectory = @"C:\Program Files\" + companyName + @"\" + applicationName + @"\\";
                }
            }
                      
            InstallApplication instApp = new InstallApplication(script, Connection1, webconfig, TargetDirectory, updateSqlScript);
            instApp.LoadData();

            if (SystemParameters.IsSuccess)
            {
                try
                {
                    Permissions(TargetDirectory);
                }
                catch
                {
                }

                base.Install(stateSaver);
            }
            else
            {
                throw new InstallException("There was an Error installing " + applicationName + ".");
            }
        }

        void Permissions(string TargetDirectory)
        {
            try
            {
                TargetDirectory = TargetDirectory.Remove(TargetDirectory.Length - 2);

                if (TargetDirectory != null)
                {
                    if (Environment.Is64BitOperatingSystem)
                    {
                        int res = SetPermission(TargetDirectory);
                    }
                    else
                    {
                        int res = SetPermission(TargetDirectory);
                    }
                }
                else
                {
                    if (Environment.Is64BitOperatingSystem)
                    {
                        int res = SetPermission(@"C:\Program Files (x86)\" + companyName + "");
                    }
                    else
                    {
                        int res = SetPermission(@"C:\Program Files\" + companyName + "");
                    }
                }
            }
            catch
            {
            }
        }

        protected override void OnBeforeRollback(IDictionary savedState)
        {
            try
            {
                base.OnBeforeRollback(savedState);
            }
            catch
            {
            }
        }

        protected override void OnAfterRollback(IDictionary savedState)
        {
            try
            {
                base.OnAfterRollback(savedState);
            }
            catch
            {
            }
        }

        public override void Uninstall(IDictionary savedState)
        {
            if (Environment.Is64BitOperatingSystem)
            {
                deleteRegKey64("Installed");
            }
            else
            {
                deleteRegKey("Installed");
            }

            try
            {
                DeleteApp();
                DeleteShortcutFromDesktop();
            }
            catch
            {
            }
            
            base.Uninstall(savedState);
        }

        protected override void OnAfterUninstall(IDictionary savedState)
        {
            try
            {
                base.OnAfterUninstall(savedState);
            }
            catch
            {
            }
        }

        private string GetFileContent(string Name)
        {
            try
            {
                try
                {
                    Assembly Asm = Assembly.GetExecutingAssembly();

                    using (Stream strm = @Assembly.GetExecutingAssembly().GetManifestResourceStream("PHFacilityInstaller." + Name))
                    {
                        StreamReader reader = new StreamReader(strm);
                        return reader.ReadToEnd();// Use strm here.  
                    }
                }
                catch
                {
                    MessageBox.Show("Error reading from Assembly" + Name);
                    return null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to Read Text File: " + ex.ToString() + "");
                return null;
            }
        }

        int SetPermission(string path)
        {
            int status;

            try
            {                
                DirectorySecurity sec = Directory.GetAccessControl(path);

                // Using this instead of the "Everyone" string means we work on non-English systems.
                SecurityIdentifier everyone = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
                sec.AddAccessRule(new FileSystemAccessRule(everyone, FileSystemRights.FullControl | FileSystemRights.Modify | FileSystemRights.Synchronize, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
                Directory.SetAccessControl(path, sec);

                DirectorySecurity sec1 = Directory.GetAccessControl(path);
                //Add 'Network service' user for permission and apply full access to the user
                SecurityIdentifier networkService = new SecurityIdentifier(WellKnownSidType.NetworkServiceSid, null);
                sec1.AddAccessRule(new FileSystemAccessRule(everyone, FileSystemRights.FullControl | FileSystemRights.Modify | FileSystemRights.Synchronize, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
                Directory.SetAccessControl(path, sec1);

                status = 1;
                return status;
            }
            catch
            {
                status = 0;
                return status;
            }
        }

        public void ExecutePowerShellScript(string scriptText)
        {
            MessageBox.Show("Power Shell");

            string results = string.Empty;

            try
            {
                // create Powershell runspace
                Runspace runspace = RunspaceFactory.CreateRunspace();

                // open it
                runspace.Open();

                PowerShell inst = PowerShell.Create();
                // create a pipeline and feed it the script text
                Pipeline pipeline = runspace.CreatePipeline();
              
                inst.AddScript("$t=new-object PowerShellExecutionSample.TestObject;" + "$t.Name='create from inside PowerShell script'; $t;");
                inst.Invoke();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Fundtion to set the permission to DCOM security
        /// </summary>
        public void SetPermissiontoDCOM()
        {
            try
            {
                var value = Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Ole", "DefaultAccessPermission", null);

                RawSecurityDescriptor sd;
                RawAcl acl;

                if (value == null)
                {
                    System.Console.WriteLine("Default Access Permission key has not been created yet");
                    sd = new RawSecurityDescriptor("");
                }
                else
                {
                    sd = new RawSecurityDescriptor(value as byte[], 0);
                }
                acl = sd.DiscretionaryAcl;
                bool found = false;
                foreach (CommonAce ca in acl)
                {
                    if (ca.SecurityIdentifier.IsWellKnown(WellKnownSidType.NetworkServiceSid))
                    {
                        //ensure local access is set
                        ca.AccessMask |= ComACLRights.COM_RIGHTS_EXECUTE | ComACLRights.COM_RIGHTS_EXECUTE_LOCAL | ComACLRights.COM_RIGHTS_ACTIVATE_LOCAL;    //set local access.  Always set execute
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    //Network Service was not found.  Add it to the ACL
                    SecurityIdentifier si = new SecurityIdentifier(
                        WellKnownSidType.NetworkServiceSid, null);
                    CommonAce ca = new CommonAce(
                        AceFlags.None,
                        AceQualifier.AccessAllowed,
                        ComACLRights.COM_RIGHTS_EXECUTE | ComACLRights.COM_RIGHTS_EXECUTE_LOCAL | ComACLRights.COM_RIGHTS_ACTIVATE_LOCAL,
                        si,
                        false,
                        null);
                    acl.InsertAce(acl.Count, ca);
                }
                //re-set the ACL
                sd.DiscretionaryAcl = acl;

                byte[] binaryform = new byte[sd.BinaryLength];
                sd.GetBinaryForm(binaryform, 0);
                Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Ole", "DefaultAccessPermission", binaryform, RegistryValueKind.Binary);
            }
            catch
            {
            }
        }

        /// <summary>
        /// Function to create the shortcut on desktop with customized link
        /// </summary> 
        public void DeleteShortcutFromDesktop()
        {
            try
            {
                //Remove desktop shortcut
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string shortcutPath = Path.Combine(desktopPath, "" + applicationName + ".url");

                if (System.IO.File.Exists(Path.Combine(desktopPath, "" + applicationName + ".url")))
                {
                    System.IO.File.Delete(Path.Combine(desktopPath, "" + applicationName + ".url"));
                }

                //Remove program folder shortcut
                string programDirPath = Environment.GetFolderPath(Environment.SpecialFolder.Programs);

                if (System.IO.File.Exists(Path.Combine(programDirPath, "" + applicationName + ".url")))
                {
                    System.IO.File.Delete(Path.Combine(programDirPath, "" + applicationName + ".url"));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
            }
        }
    }
}
