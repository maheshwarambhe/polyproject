﻿GO
/****** Object:  UserDefinedTableType [dbo].[ActionPlan]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[ActionPlan] AS TABLE(
	[CategoryTypeId] [int] NULL,
	[SubCategoryTypeId] [int] NULL,
	[Problem] [nvarchar](max) NULL,
	[Solution] [nvarchar](max) NULL,
	[PHCLevel] [nvarchar](max) NULL,
	[DistrictLevel] [nvarchar](max) NULL,
	[StateLevel] [nvarchar](max) NULL,
	[DueDate] [datetime] NULL,
	[ResponsiblePerson] [nvarchar](max) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[AnsewerType]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[AnsewerType] AS TABLE(
	[AnswerTypeId] [int] NULL,
	[AnswerType] [nvarchar](100) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[Answer]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[Answer] AS TABLE(
	[AnswerId] [int] NULL,
	[QuestionId] [int] NULL,
	[Answer] [nvarchar](200) NULL,
	[weightage] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[AnswerOption]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[AnswerOption] AS TABLE(
	[RowId] [int] NULL,
	[AnswerId] [int] NULL,
	[Answer] [nvarchar](200) NULL,
	[Weightege] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[CategoryType]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[CategoryType] AS TABLE(
	[CategoryTypeId] [int] NULL,
	[CategoryType] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL,
	[Prefix] [nvarchar](50) NULL,
	[Instructions] [nvarchar](max) NULL,
	[Indicators] [nvarchar](50) NULL,
	[DisplayName] [nvarchar](100) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[Centre]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[Centre] AS TABLE(
	[CentreId] [int] NULL,
	[TalukaId] [int] NULL,
	[CentreTypeId] [int] NULL,
	[Centre] [nvarchar](200) NULL,
	[Address] [nvarchar](max) NULL,
	[ContactPerson] [nvarchar](200) NULL,
	[ContactEmail] [nvarchar](200) NULL,
	[ContactNumber] [nvarchar](50) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[CentreType]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[CentreType] AS TABLE(
	[CentreTypeId] [int] NULL,
	[CentreType] [nvarchar](200) NULL,
	[Description] [nvarchar](300) NULL,
	[IndicatorsForOIResult] [nvarchar](100) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[DesignationMaster]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[DesignationMaster] AS TABLE(
	[DesignationId] [int] NULL,
	[Designation] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[District]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[District] AS TABLE(
	[DistrictId] [int] NULL,
	[DistrictName] [nvarchar](200) NULL,
	[Description] [nvarchar](300) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[DQAG]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[DQAG] AS TABLE(
	[UserId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[GAnswer]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[GAnswer] AS TABLE(
	[GiAnswerId] [int] NULL,
	[QuestionId] [int] NULL,
	[ScoreRange-10TO+10] [int] NULL,
	[DecreaseBy10PercentOrMore] [int] NULL,
	[IncreaseBy10PercentOrmore] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[GiAnswer]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[GiAnswer] AS TABLE(
	[QuestionId] [int] NULL,
	[ThreeMonthRecordA] [float] NULL,
	[ThreeMonthRecordB] [float] NULL,
	[Performance] [float] NULL,
	[Weightage] [float] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[Grade]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[Grade] AS TABLE(
	[GradeId] [int] NULL,
	[MinScore] [numeric](18, 2) NULL,
	[MaxScore] [numeric](18, 2) NULL,
	[Grade] [nvarchar](50) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[HrProfile]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[HrProfile] AS TABLE(
	[DesignationId] [int] NULL,
	[PostSanctionedNo] [int] NULL,
	[RegularNo] [int] NULL,
	[Contractual] [int] NULL,
	[Remark] [nvarchar](max) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[IndicatorMaster]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[IndicatorMaster] AS TABLE(
	[IndicatorId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SubCategoryTypeId] [int] NULL,
	[CentreTypeId] [int] NULL,
	[DisplayName] [nvarchar](max) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[ModifyModuleAccess]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[ModifyModuleAccess] AS TABLE(
	[RoleId] [int] NULL,
	[ModuleId] [int] NULL,
	[View] [bit] NULL,
	[Add] [bit] NULL,
	[Edit] [bit] NULL,
	[Delete] [bit] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[ModuleAccess]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[ModuleAccess] AS TABLE(
	[ModuleAccessId] [int] NULL,
	[RoleId] [int] NULL,
	[ModuleId] [int] NULL,
	[View] [bit] NULL,
	[Add] [bit] NULL,
	[Update] [bit] NULL,
	[Delete] [bit] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[ModuleMaster]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[ModuleMaster] AS TABLE(
	[ModuleId] [int] NULL,
	[ModuleName] [nvarchar](max) NULL,
	[ParentId] [int] NULL,
	[ModuleTypeId] [int] NULL,
	[ModuleIdentifyId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[Qualification]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[Qualification] AS TABLE(
	[QualificationId] [int] NULL,
	[Qualification] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[Question]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[Question] AS TABLE(
	[QuestionId] [int] NULL,
	[CenterTypeId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SubCategoryTyepId] [int] NULL,
	[Question] [nvarchar](max) NULL,
	[Status] [bit] NULL,
	[AnswerTyepId] [int] NULL,
	[IsDeletable] [bit] NULL,
	[IsGi] [bit] NULL,
	[ReviewRecordNo] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[RevievRecord]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[RevievRecord] AS TABLE(
	[ReviewRecordId] [int] NULL,
	[SurveyId] [int] NULL,
	[QuestionId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[LastThreeMonthPerformance] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[ReviewRecordAnswer]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[ReviewRecordAnswer] AS TABLE(
	[QuestionId] [int] NULL,
	[LastThreeMonthPerformance] [int] NULL,
	[Weightage] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[RoleMaster]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[RoleMaster] AS TABLE(
	[RoleId] [int] NULL,
	[RoleName] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[RoleRight]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[RoleRight] AS TABLE(
	[RoleId] [int] NULL,
	[ModuleId] [int] NULL,
	[View] [bit] NULL,
	[Add] [bit] NULL,
	[Update] [bit] NULL,
	[Delete] [bit] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[SkillTrainingDetail]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[SkillTrainingDetail] AS TABLE(
	[StaffName] [nvarchar](max) NULL,
	[DesignationId] [int] NULL,
	[QualificationId] [int] NULL,
	[Minilap] [nvarchar](50) NULL,
	[NSV] [nvarchar](50) NULL,
	[MTP] [nvarchar](50) NULL,
	[BEMOC] [nvarchar](50) NULL,
	[EMOC] [nvarchar](50) NULL,
	[STIRTI] [nvarchar](50) NULL,
	[IUD] [nvarchar](50) NULL,
	[LSAS] [nvarchar](50) NULL,
	[IMEP] [nvarchar](50) NULL,
	[CTC] [nvarchar](50) NULL,
	[NSSK] [nvarchar](50) NULL,
	[RI] [nvarchar](50) NULL,
	[FIMNCI] [nvarchar](50) NULL,
	[SBA] [nvarchar](50) NULL,
	[IYCF] [nvarchar](50) NULL,
	[Other] [nvarchar](50) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[SMSEmailPrivilege]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[SMSEmailPrivilege] AS TABLE(
	[SMSEmailPrivilegeId] [int] NULL,
	[Particular] [nvarchar](200) NULL,
	[SMS] [bit] NULL,
	[Email] [bit] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[StaffRespondent]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[StaffRespondent] AS TABLE(
	[UserName] [nvarchar](max) NULL,
	[DesignationId] [int] NULL,
	[QualificationId] [int] NULL,
	[MobNo] [nvarchar](50) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[SubCategoryType]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[SubCategoryType] AS TABLE(
	[SubCategoryTypeId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SubCategoryType] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
	[PreFix] [nvarchar](10) NULL,
	[Instructions] [nvarchar](max) NULL,
	[Indicators] [nvarchar](50) NULL,
	[DisplayName] [nvarchar](100) NULL,
	[IsOptional] [bit] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[SurveyAnswer]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[SurveyAnswer] AS TABLE(
	[QuestionId] [int] NULL,
	[AnswerId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[SurveyPeople]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[SurveyPeople] AS TABLE(
	[UserId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[SurveyPeopleFromServer]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[SurveyPeopleFromServer] AS TABLE(
	[SurveyPeopleId] [int] NULL,
	[SurveyScheduleId] [int] NULL,
	[UserId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[SurveySchedule]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[SurveySchedule] AS TABLE(
	[SurveyScheduleId] [int] NULL,
	[CentreId] [int] NULL,
	[SurveyDate] [datetime] NULL,
	[SurveyStartTime] [datetime] NULL,
	[SurveyEndTime] [datetime] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[Taluka]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[Taluka] AS TABLE(
	[TalukaId] [int] NULL,
	[DistrictId] [int] NULL,
	[TalukaName] [nvarchar](200) NULL,
	[Description] [nvarchar](300) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblGIResult]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[tblGIResult] AS TABLE(
	[GIResultId] [int] NULL,
	[QuestionId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SurveyId] [int] NULL,
	[ThreeMonthRecordA] [int] NULL,
	[ThreeMonthRecordB] [int] NULL,
	[Percentage] [float] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeActionPlan]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[tblTypeActionPlan] AS TABLE(
	[ActionPlanId] [int] NOT NULL,
	[SurveyId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SubCategoryTypeId] [int] NULL,
	[Problem] [nvarchar](max) NULL,
	[Solution] [nvarchar](max) NULL,
	[PHCLevel] [nvarchar](max) NULL,
	[DistrictLevel] [nvarchar](max) NULL,
	[StateLevel] [nvarchar](max) NULL,
	[DueDate] [datetime] NULL,
	[ResponsiblePerson] [nvarchar](max) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeDQAG]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[tblTypeDQAG] AS TABLE(
	[DQAGId] [int] NULL,
	[SurveyId] [int] NULL,
	[UserId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeGIResult]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[tblTypeGIResult] AS TABLE(
	[GIResultId] [int] NULL,
	[QuestionId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SurveyId] [int] NULL,
	[ThreeMonthRecordA] [int] NULL,
	[ThreeMonthRecordB] [int] NULL,
	[Percentage] [float] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeHRProfile]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[tblTypeHRProfile] AS TABLE(
	[HRProfileId] [int] NULL,
	[SurveyId] [int] NULL,
	[DesignationId] [int] NULL,
	[PostSanctionedNo] [int] NULL,
	[RegularNo] [int] NULL,
	[Contractual] [int] NULL,
	[Remark] [nvarchar](max) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeResult]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[tblTypeResult] AS TABLE(
	[ResultId] [int] NULL,
	[SurveyId] [int] NULL,
	[MaxScore] [int] NULL,
	[ScoreObtain] [int] NULL,
	[Percentage] [numeric](18, 2) NULL,
	[Grade] [nvarchar](50) NULL,
	[ResultMOICName] [nvarchar](200) NULL,
	[ResultQATeamLeaderId] [int] NULL,
	[GiMOICName] [nvarchar](200) NULL,
	[GiQATeamLeaderId] [int] NULL,
	[ActionPlanMOICName] [nvarchar](200) NULL,
	[ActionQATeamLeaderId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeRevievRecord]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[tblTypeRevievRecord] AS TABLE(
	[ReviewRecordId] [int] NULL,
	[SurveyId] [int] NULL,
	[QuestionId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[LastThreeMonthPerformance] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeSkillTrainingStatus]    Script Date: 1/14/2015 11:19:28 AM ******/
CREATE TYPE [dbo].[tblTypeSkillTrainingStatus] AS TABLE(
	[SkillTrainingStatusId] [int] NULL,
	[SurveyId] [int] NULL,
	[StaffName] [nvarchar](max) NULL,
	[DesignationId] [int] NULL,
	[QualificationId] [int] NULL,
	[Minilap] [nvarchar](50) NULL,
	[NSV] [nvarchar](50) NULL,
	[MTP] [nvarchar](50) NULL,
	[BEMOC] [nvarchar](50) NULL,
	[EMOC] [nvarchar](50) NULL,
	[STIRTI] [nvarchar](50) NULL,
	[IUD] [nvarchar](50) NULL,
	[LSAS] [nvarchar](50) NULL,
	[IMEP] [nvarchar](50) NULL,
	[CTC] [nvarchar](50) NULL,
	[NSSK] [nvarchar](50) NULL,
	[RI] [nvarchar](50) NULL,
	[FIMNCI] [nvarchar](50) NULL,
	[SBA] [nvarchar](50) NULL,
	[IYCF] [nvarchar](50) NULL,
	[Other] [nvarchar](50) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeStaffRespondent]    Script Date: 1/14/2015 11:19:29 AM ******/
CREATE TYPE [dbo].[tblTypeStaffRespondent] AS TABLE(
	[StaffRespondentId] [int] NULL,
	[SurveyId] [int] NULL,
	[UserName] [nvarchar](max) NULL,
	[DesignationId] [int] NULL,
	[QualificationId] [int] NULL,
	[MobNo] [nvarchar](50) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeSurvey]    Script Date: 1/14/2015 11:19:29 AM ******/
CREATE TYPE [dbo].[tblTypeSurvey] AS TABLE(
	[SurveyId] [int] NULL,
	[CentreId] [int] NULL,
	[NameofMO] [nvarchar](200) NULL,
	[MobNoofMO] [nvarchar](50) NULL,
	[Email] [nvarchar](50) NULL,
	[TelephoneNo] [nvarchar](50) NULL,
	[VisitDate] [datetime] NULL,
	[VisitRound] [nvarchar](50) NULL,
	[PreviousVisitDate] [datetime] NULL,
	[PreviousVisitScore] [numeric](18, 2) NULL,
	[SubCentresNo] [nvarchar](50) NULL,
	[PopulationCovered] [nvarchar](50) NULL,
	[IPHSStatus] [bit] NULL,
	[247Status] [bit] NULL,
	[DeliveryPoint] [bit] NULL,
	[Distance] [numeric](18, 2) NULL,
	[VisitStartTime] [datetime] NULL,
	[VisitEndTime] [datetime] NULL,
	[TotalTime] [nvarchar](50) NULL,
	[Status] [bit] NULL,
	[IsComplete] [bit] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[tblTypeSurveyAnswer]    Script Date: 1/14/2015 11:19:29 AM ******/
CREATE TYPE [dbo].[tblTypeSurveyAnswer] AS TABLE(
	[SurveyAnswerId] [int] NULL,
	[SurveyId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[QuestionId] [int] NULL,
	[AnswerId] [int] NULL,
	[weightage] [int] NULL,
	[IsGi] [bit] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[UserCentreMapping]    Script Date: 1/14/2015 11:19:29 AM ******/
CREATE TYPE [dbo].[UserCentreMapping] AS TABLE(
	[CentreId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[UserCentreMappingFromServer]    Script Date: 1/14/2015 11:19:29 AM ******/
CREATE TYPE [dbo].[UserCentreMappingFromServer] AS TABLE(
	[UserCentreMappingId] [int] NULL,
	[UserId] [int] NULL,
	[CentreId] [int] NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[UserMappedinCentre]    Script Date: 1/14/2015 11:19:29 AM ******/
CREATE TYPE [dbo].[UserMappedinCentre] AS TABLE(
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[ReportingManagerId] [int] NULL,
	[DesignationId] [int] NULL,
	[RoleId] [int] NULL,
	[UserName] [nvarchar](50) NULL,
	[Password] [nvarchar](50) NULL,
	[FirstName] [nvarchar](50) NULL,
	[MiddleName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL,
	[QualificationId] [int] NULL,
	[ContactNumber] [nvarchar](50) NULL,
	[ContactEmail] [nvarchar](200) NULL
)
GO
/****** Object:  UserDefinedTableType [dbo].[UserMaster]    Script Date: 1/14/2015 11:19:29 AM ******/
CREATE TYPE [dbo].[UserMaster] AS TABLE(
	[UserId] [int] NULL,
	[ReportingManagerId] [int] NULL,
	[DesignationId] [int] NULL,
	[RoleId] [int] NULL,
	[UserName] [nvarchar](50) NULL,
	[Password] [nvarchar](50) NULL,
	[FirstName] [nvarchar](50) NULL,
	[MiddleName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL,
	[QualificationId] [int] NULL,
	[ContactNumber] [nvarchar](50) NULL,
	[ContactEmail] [nvarchar](200) NULL
)
GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ActionPlanCategory_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Mahesh Warambhe
-- Create date: 02/11/2014
-- Description:	To get datatable of CategoryType dropdown
-- Example: csp_Get_ActionPlanCategory_Dropdown 12
-- =============================================
CREATE PROC [dbo].[csp_Get_ActionPlanCategory_Dropdown]
(
@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY

	    DECLARE @ActionPlan  TABLE (
		  ActionPlanId INT,
		  CategoryTypeId INT,
		  SubCategoryTypeId INT,
		  CategoryType NVARCHAR(100),
		  SubCategoryType NVARCHAR(100),
		 [Problem] NVARCHAR(100),
		 [Solution] NVARCHAR(100),
		 [PHCLevel] NVARCHAR(100),
		 [DueDate] NVARCHAR(100),
		 [DistrictLevel] NVARCHAR(100),
		 [StateLevel] NVARCHAR(100),
		 [ResponsiblePerson] NVARCHAR(100),
		 MOName	NVARCHAR(100),		
		 LeaderName NVARCHAR(100)
		)
		
			INSERT INTO @ActionPlan	
		(		  
		  CategoryTypeId,
		  SubCategoryTypeId,
		  CategoryType ,
		  SubCategoryType,
		  [Problem],
		 [Solution],
		 [PHCLevel],
		 [DueDate],
		 [DistrictLevel],
		 [StateLevel],
		 [ResponsiblePerson],
		 MOName,			
		 LeaderName,
		 ActionPlanId
		)	
		 EXEC csp_Get_SurveyActionPlan @SurveyId

	     SELECT   CategoryTypeId, CategoryType from @ActionPlan	WHERE CategoryTypeId = 1		  
		 UNION
		 SELECT   DISTINCT CategoryTypeId, CategoryType from @ActionPlan	WHERE CategoryTypeId > 6
			
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ActionPlanProgress]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	04/01/2015
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Get_ActionPlanProgress 21
-- ======================================================================

CREATE PROC [dbo].[csp_Get_ActionPlanProgress]
(
	@SurveyId INT=NULL
)
AS
BEGIN
	    SELECT
		AP.CategoryTypeId, 
		APP.[ActionPlanProgressId],
		APP.[ActionPlanId],
		CONVERT(NVARCHAR,APP.[ActionTakenDate],103) AS ActionTakenDate,
		APP.[ActualResponsiblePerson],
		APP.[ActionTaken],
		' General Facility Readiness' AS CategoryType,
		CT.DisplayName AS SubCategoryType,
		CentreType=(SELECT CentreType FROM 
					tblCentreType WHERE CentreTypeId IN ( SELECT CentreTypeId FROM tblCentre WHERE  CentreId 
					IN(SELECT CentreId FROM tblSurvey WHERE SurveyId = @SurveyId) ))
		FROM tblActionPlanProgress  APP
		inner join tblActionPlan AP on APP.ActionPlanId =AP.ActionPlanId
		inner join tblSurvey S ON APP.SurveyId = S.SurveyId
		inner join tblCategoryType CT ON AP.CategoryTypeId= CT.CategoryTypeId
		WHERE AP.CategoryTypeId BETWEEN 1 AND 6 AND APP.SurveyId =@SurveyId

		UNION

		SELECT 
		AP.CategoryTypeId, 
		APP.[ActionPlanProgressId],
		APP.[ActionPlanId],
		CONVERT(NVARCHAR,APP.[ActionTakenDate],103) AS ActionTakenDate,
		APP.[ActualResponsiblePerson],
		APP.[ActionTaken],
		CT.DisplayName AS  CategoryType,
		SC.DisplayName AS SubCategoryType,
		CentreType=(SELECT CentreType FROM 
					tblCentreType WHERE CentreTypeId IN ( SELECT CentreTypeId FROM tblCentre WHERE  CentreId 
					IN(SELECT CentreId FROM tblSurvey WHERE SurveyId = @SurveyId) ))
		FROM tblActionPlanProgress  APP
		inner join tblActionPlan AP on APP.ActionPlanId =AP.ActionPlanId
		inner join tblSurvey S ON APP.SurveyId = S.SurveyId
		inner join tblSubCategoryType SC ON SC.SubCategoryTypeId =AP.SubCategoryTypeId
		INNER JOIN tblCategoryType CT ON SC.CategoryTypeId =CT.CategoryTypeId
		WHERE AP.CategoryTypeId BETWEEN 7 AND 9 AND APP.SurveyId =@SurveyId

		ORDER BY ActionTakenDate DESC
END
		




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ActionPlanProgressReport]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	04/01/2015
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Get_ActionPlanProgressReport '2015-01-02 00:00:00.000'
-- ======================================================================

CREATE PROC [dbo].[csp_Get_ActionPlanProgressReport]
(
	@SurveyId int 
)
AS
BEGIN
	SELECT 
			S.VisitDate,
			APP.[ActionPlanId],
			APP.[ActionTakenDate],
			APP.[ActualResponsiblePerson],
			APP.[ActionTaken],
			' General Facility Readiness' AS CategoryType,
			CT.DisplayName AS SubCategoryType
			FROM tblActionPlanProgress  APP
			inner join tblActionPlan AP on APP.ActionPlanId =AP.ActionPlanId
			inner join tblSurvey S ON APP.SurveyId = S.SurveyId
			inner join tblCategoryType CT ON AP.CategoryTypeId= CT.CategoryTypeId
			WHERE AP.CategoryTypeId BETWEEN 1 AND 6 AND APP.SurveyId =@SurveyId

			UNION

			SELECT 
			S.VisitDate,
			APP.[ActionPlanId],
			APP.[ActionTakenDate],
			APP.[ActualResponsiblePerson],
			APP.[ActionTaken],
			CT.DisplayName AS  CategoryType,
			SC.DisplayName AS SubCategoryType
			FROM tblActionPlanProgress  APP
			inner join tblActionPlan AP on APP.ActionPlanId =AP.ActionPlanId
			inner join tblSurvey S ON APP.SurveyId = S.SurveyId
			inner join tblSubCategoryType SC ON SC.SubCategoryTypeId =AP.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON SC.CategoryTypeId =CT.CategoryTypeId
			WHERE AP.CategoryTypeId BETWEEN 7 AND 9 AND APP.SurveyId =@SurveyId

			ORDER BY APP.[ActionTakenDate] DESC
END
		




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ActionPlanReport]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Ajay Birari
-- Create date	:	31/07/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Get_ActionPlanReport 3
-- ======================================================================

CREATE PROC [dbo].[csp_Get_ActionPlanReport]
	(
		@SurveyId INT=NULL
	)
AS
		BEGIN
		    IF EXISTS(SELECT SurveyId FROM tblActionPlan WHERE SurveyId =@SurveyId)
				BEGIN
					Select					
					C.CategoryTypeId,
				    S.SubCategoryTypeId,
					' General Facility Readiness' AS CategoryType,
					C.DisplayName AS SubCategoryType,
					[Problem],
					[Solution],
					[PHCLevel],
					convert(nvarchar(10),DueDate,103) as DueDate,
					[DistrictLevel],
					[StateLevel],
					[ResponsiblePerson],
					MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
		            LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
					A.ActionPlanId,
					 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)		
					from tblActionPlan A
					INNER join tblCategoryType C on A.CategoryTypeId = C.CategoryTypeId
					INNER join tblSubCategoryType S ON A.SubCategoryTypeId = S.SubCategoryTypeId
					where C.CategoryTypeId < 7 AND SurveyId=@SurveyId

					union

					Select					
						C.CategoryTypeId,
						S.SubCategoryTypeId,
						CategoryType,
						s.DisplayName AS SubCategoryType,
						[Problem],
					[Solution],
					[PHCLevel],
					convert(nvarchar(10),DueDate,103) as DueDate,
					[DistrictLevel],
					[StateLevel],
					[ResponsiblePerson],
					MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
		         	LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
					A.ActionPlanId,
					 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)		
					from tblActionPlan A
					INNER join tblCategoryType C on A.CategoryTypeId = C.CategoryTypeId
					INNER join tblSubCategoryType S ON A.SubCategoryTypeId = S.SubCategoryTypeId
					WHERE C.CategoryTypeId >6 and SurveyId=@SurveyId

				END
			ELSE
				BEGIN

				Select
					C.CategoryTypeId,
					S.SubCategoryTypeId ,
					' General Facility Readiness' AS CategoryType,
					C.DisplayName AS SubCategoryType,
					[Problem],
					[Solution],
					[PHCLevel],
					convert(nvarchar(10),DueDate,103) as DueDate,
					[DistrictLevel],
					[StateLevel],
					[ResponsiblePerson] ,
					MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
			        LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId) ,
					A.ActionPlanId,
					 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)							
					from tblActionPlan A
					INNER join tblCategoryType C on A.CategoryTypeId = C.CategoryTypeId
					INNER join tblSubCategoryType S ON A.SubCategoryTypeId = S.SubCategoryTypeId
					where C.CategoryTypeId < 7 AND A.SurveyId IN   
					( SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
					(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate DESC)
   
					union

					Select				
						C.CategoryTypeId,
						S.SubCategoryTypeId,
						CategoryType,
						s.DisplayName AS SubCategoryType,
						[Problem],
					[Solution],
					[PHCLevel],
					convert(nvarchar(10),DueDate,103) as DueDate,
					[DistrictLevel],
					[StateLevel],
					[ResponsiblePerson],
					MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
			        LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
					A.ActionPlanId ,
					 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)		
					from tblActionPlan A
					INNER join tblCategoryType C on A.CategoryTypeId = C.CategoryTypeId
					INNER join tblSubCategoryType S ON A.SubCategoryTypeId = S.SubCategoryTypeId
					WHERE C.CategoryTypeId >6 	AND A.SurveyId IN   
					( SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
					(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate DESC)
   

				END
		END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ActionPlanSubCategory_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Mahesh Warambhe
-- Create date: 02/11/2014
-- Description:	To get datatable of CategoryType dropdown
-- Example: csp_Get_ActionPlanSubCategory_Dropdown 20 ,1
-- =============================================
CREATE PROC [dbo].[csp_Get_ActionPlanSubCategory_Dropdown]
(
@SurveyId INT,
@CategoryId INT
)
AS
BEGIN						
	BEGIN TRY

	    DECLARE @ActionPlan  TABLE
	  (
	      ActionPlanId INT,
		  CategoryTypeId INT,
		  SubCategoryTypeId INT,
		  CategoryType NVARCHAR(100),
		  SubCategoryType NVARCHAR(100),
		 [Problem] NVARCHAR(100),
		 [Solution] NVARCHAR(100),
		 [PHCLevel] NVARCHAR(100),
		 [DueDate] NVARCHAR(100),
		 [DistrictLevel] NVARCHAR(100),
		 [StateLevel] NVARCHAR(100),
		 [ResponsiblePerson] NVARCHAR(100),
		 MOName	NVARCHAR(100),		
		 LeaderName NVARCHAR(100)		
		)
		
		INSERT INTO @ActionPlan	
		(		  
		  CategoryTypeId,
		  SubCategoryTypeId,
		  CategoryType ,
		  SubCategoryType,
		  [Problem],
		 [Solution],
		 [PHCLevel],
		 [DueDate],
		 [DistrictLevel],
		 [StateLevel],
		 [ResponsiblePerson],
		 MOName,			
		 LeaderName,
		 ActionPlanId
		)	
		 EXEC csp_Get_SurveyActionPlan @SurveyId


		 IF( @CategoryId = 1)
		  BEGIN 

		     SELECT   AC.ActionPlanId,AC.SubCategoryType  from @ActionPlan AC			
		    	WHERE AC.CategoryTypeId < 7
		  END
		 ELSE
		  BEGIN


		   SELECT   AC.ActionPlanId,AC.SubCategoryType  from @ActionPlan AC			
			WHERE  AC.CategoryTypeId = @CategoryId
		
		  END
			
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ActionPlanSubcategoryWise]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author:	Mahesh Warambhe
-- Create date: 05/11/2014
-- Description:	To get datatable of Action Plan Sub category wise
-- Example: csp_Get_ActionPlanSubcategoruwise
-- =============================================
CREATE PROC [dbo].[csp_Get_ActionPlanSubcategoryWise]
(
@ActionPlanId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT
		A.Problem,
		A.Solution,
		A.PHCLevel,
		A.DistrictLevel,
		A.StateLevel,
		A.DueDate,
		A.ResponsiblePerson,
		A.ActionPlanId
		FROM tblActionPlan A WHERE ActionPlanId= @ActionPlanId 
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_AnswerOption]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 05/11/2014
-- Description:	To get datatable of Answer Option
-- Example: csp_Get_AnswerType_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_AnswerOption]
(
@QuestionId INT
)
AS
BEGIN						
	BEGIN TRy
		select Answer, weightage as Weightege,AnswerId from tblAnswer where QuestionId=@QuestionId 
		END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_AnswerType_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 02/11/2014
-- Description:	To get datatable of CenterType dropdown
-- Example: csp_Get_AnswerType_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_AnswerType_Dropdown]
AS
BEGIN						
	BEGIN TRY
		SELECT AnswerTypeId ,AnswerType FROM tblAnsewerType ORDER BY AnswerType
			END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CategoryType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author: Yograj Sulakhe
-- Create date: 29/11/2014
-- Description:	To get datatable of category
-- Example: csp_Get_CategoryType
-- =============================================
CREATE  PROC [dbo].[csp_Get_CategoryType]
AS
BEGIN						
	BEGIN TRY
		SELECT CategoryTypeId,CategoryType,Description FROM tblCategoryType ORDER BY CategoryTypeId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CategoryType_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 02/11/2014
-- Description:	To get datatable of CategoryType dropdown
-- Example: csp_Get_District_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_CategoryType_Dropdown]
AS
BEGIN						
	BEGIN TRY
		SELECT CategoryTypeId,CategoryType FROM tblCategoryType ORDER BY CategoryType
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CenterType_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 02/11/2014
-- Description:	To get datatable of CenterType dropdown
-- Example: csp_Get_CenterType_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_CenterType_Dropdown]
AS
BEGIN						
	BEGIN TRY
		SELECT CentreTypeId,CentreType FROM tblCentreType ORDER BY CentreType
			END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CenterTYpeId]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Yograj Sulakhe
-- Create date: 24/12/2014
-- Description:	To get datatable of Taulka
-- Example: csp_Get_CenterTYpeId
-- =============================================
CREATE PROC [dbo].[csp_Get_CenterTYpeId]
(
	@SurveyId INT
)
AS
BEGIN	
	SELECT C.CentreTypeId from tblSurvey S
	inner join tblCentre C on S.CentreId=C.CentreId
	where S.SurveyId=@SurveyId
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CenterTypepeLable]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 02/01/2015
-- Description:	To get datatable of CenterTypepeLable
-- Example: csp_Get_CenterTypepeLable 292
-- =============================================
CREATE PROC [dbo].[csp_Get_CenterTypepeLable]
(
	@CentreId INT
)
AS
BEGIN	
	SELECT StatusId = (SELECT CentreTypeId FROM tblCentreType WHERE CentreTypeId=(SELECT CentreTypeId FROM tblCentre WHERE							CentreId=@CentreId))
END

GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Centre]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Centre 
-- Example: csp_Get_Centre
-- =============================================
CREATE PROC [dbo].[csp_Get_Centre]
(
@roleId int =null,
@userId int =null
)
AS
BEGIN	
	IF(@roleId<>0)	
		BEGIN				
			BEGIN TRY
				SELECT 
					C.CentreId,
					D.DistrictId,
					T.TalukaId,
					C.CentreTypeId,
					D.DistrictName,
					T.TalukaName,
					CT.CentreType,
					Centre,
					Address,
					ContactPerson,
					ContactEmail,
					ContactNumber 
				FROM tblCentre C
				INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
				INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
				INNER JOIN tblCentreType CT ON CT.CentreTypeId = C.CentreTypeId
				WHERE CentreId IN (SELECT CentreId FROM tblUserCentreMapping WHERE UserId = @userId)
				ORDER BY CentreId DESC
			END TRY
			BEGIN CATCH	
			END CATCH
		END
	ELSE
		BEGIN
			BEGIN TRY
				SELECT 
					C.CentreId,
					D.DistrictId,
					T.TalukaId,
					C.CentreTypeId,
					D.DistrictName,
					T.TalukaName,
					CT.CentreType,
					Centre,
					Address,
					ContactPerson,
					ContactEmail,
					ContactNumber 
				FROM tblCentre C
				INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
				INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
				INNER JOIN tblCentreType CT ON CT.CentreTypeId = C.CentreTypeId
				ORDER BY CentreId DESC
			END TRY
			BEGIN CATCH	
			END CATCH
		END
		
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Centre_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:Parshwanath Chougule
-- Create date: 02/11/2014
-- Description:	To get datatable of Center dropdown
-- Example: csp_Get_Center_Dropdown '14'
-- =============================================
CREATE PROC [dbo].[csp_Get_Centre_Dropdown]
(
   @TalukaId INT,
   @RoleId int =null,
   @UserId int =null

)
AS
BEGIN	
	IF(@RoleId<>0)	
		BEGIN							
			BEGIN TRY
				SELECT  CentreId,Centre FROM tblCentre
				 WHERE TalukaId = @TalukaId 
				 AND  CentreId IN (SELECT CentreId FROM	
				tblUserCentreMapping WHERE UserId = @UserId ) ORDER BY Centre 
			END TRY
			BEGIN CATCH	
			END CATCH
		END
	ELSE
		BEGIN
			BEGIN TRY
				SELECT  CentreId,Centre FROM tblCentre WHERE TalukaId = @TalukaId  ORDER BY Centre 
					END TRY
			BEGIN CATCH	
			END CATCH
		END
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CentreComparisonReport]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Abhinandan Patil
-- Create date: 13/12/2014
-- Description:	To get datatable of District Level Summary
-- Example: csp_Get_CentreComparisonReport 1
-- =============================================
CREATE PROC [dbo].[csp_Get_CentreComparisonReport]
(
	@TalukaId INT
)
AS
BEGIN						
	BEGIN TRy

		SELECT X.Centre,LastSurvey,CurrentSurvey FROM (SELECT C.CentreId,Centre,'Grade ' + Grade + ' - ' + CONVERT(NVARCHAR,Percentage) + '% - ' + CONVERT(NVARCHAR,S.VisitDate,103) AS CurrentSurvey FROM tblResult R 
		INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
		INNER JOIN tblCentre C ON S.CentreId=C.CentreId
		INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
		INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId AND T.TalukaId=@TalukaId
		INNER JOIN
		(SELECT MAX(VisitDate) VisitDate,SI.CentreId FROM tblSurvey SI
		INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
		GROUP BY SI.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate) AS X

		LEFT JOIN

		(SELECT C.CentreId,Centre,'Grade ' + Grade + ' - ' + CONVERT(NVARCHAR,Percentage) + '% - ' + CONVERT(NVARCHAR,S.VisitDate,103) AS LastSurvey FROM tblResult R 
		INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
		INNER JOIN tblCentre C ON S.CentreId=C.CentreId
		INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
		INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId
		INNER JOIN
		(SELECT Max(VisitDate) VisitDate,C1.CentreId FROM tblSurvey SII INNER JOIN tblCentre C1 ON SII.CentreId=C1.CentreId WHERE VisitDate NOT IN (SELECT MAX(VisitDate) VisitDate FROM tblSurvey SI
		INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
		GROUP BY SI.CentreId) GROUP BY C1.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate) Y
		ON X.CentreId=Y.CentreId

	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CentreComparisonYtoYChart]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Abhinandan Patil
-- Create date: 12/12/2014
-- Description:	To get datatable of Centre ComparisonY to Y Chart
-- Example: csp_Get_CentreComparisonYtoYChart 1
-- =============================================    
CREATE PROC [dbo].[csp_Get_CentreComparisonYtoYChart] 
(
	@CentreId INT
)
	
AS            
BEGIN 
	BEGIN
				SELECT 
				CentreId,
				Centre,
				Percentage,
				Convert(nvarchar,VisitDate,103) AS VisitDate
				 FROM 
				(SELECT TOP(2)C.CentreId,C.Centre,R.Percentage,S.VisitDate  FROM tblResult R 
		INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
		INNER JOIN tblCentre C ON S.CentreId=C.CentreId
		INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
		INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId	
		WHERE S.CentreId=@CentreId ORDER BY S.VisitDate DESC) X ORDER BY X.VisitDate ASC

	END
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CentreDetail]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Centre 
-- Example: csp_Get_CentreDetail 4
-- =============================================
CREATE PROC [dbo].[csp_Get_CentreDetail]
(
@CentreId INT
)
AS
BEGIN						
	BEGIN TRY		
				
		SELECT 
		     NameofMO AS ContactPerson,
			 Email AS  ContactEmail,
			 MobNoofMO AS  ContactNumber,
			   PreviousVisitDate = (SELECT VisitDate FROM tblSurvey 
							WHERE SurveyId IN (SELECT TOP(1)SurveyId FROM tblSurvey 
							WHERE CentreId = @CentreId ORDER BY VisitDate DESC)),
			   PreviousVisitScore,
			   StatusId = (SELECT CentreTypeId FROM tblCentreType WHERE CentreTypeId=(SELECT CentreTypeId FROM tblCentre WHERE CentreId=@CentreId)),
			   TelephoneNo,
			   SubCentresNo,
			   PopulationCovered,
			   Distance,
			   VisitRound,
			   IPHSStatus,
			   [247Status] As Status247,
			   DeliveryPoint
			   FROM tblSurvey WHERE SurveyId IN (SELECT TOP(1)SurveyId FROM tblSurvey WHERE CentreId = @CentreId ORDER BY VisitDate DESC)
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CentreGradeProgressChart]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Abhinandan Patil
-- Create date: 11/12/2014
-- Description:	To get datatable of Centre grade progress chart
-- Example: csp_Get_CentreGradeProgressChart 1
-- =============================================
CREATE PROC [dbo].[csp_Get_CentreGradeProgressChart]
(
	@CentreId INT
)
AS
BEGIN						
	BEGIN TRY
	
		SELECT C.CentreId,C.Centre,R.Percentage,CONVERT(nvarchar,S.VisitDate,103) AS VisitDate FROM tblResult R 
		INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
		INNER JOIN tblCentre C ON S.CentreId=C.CentreId
		INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
		INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId	
		WHERE S.CentreId=@CentreId ORDER BY S.VisitDate

	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CentreLabelName]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Survey General Information 
-- Example: csp_Get_CentreLabelName 23
-- =============================================

CREATE PROC [dbo].[csp_Get_CentreLabelName]
(

	@SurveyId INT=NULL
)

AS
BEGIN	
	BEGIN TRY	
			SELECT CentreType FROm tblCentreType WHERE CentreTypeId IN(SELECT CentreTypeId FROM  tblCentre WHERE CentreId IN (SELECT CentreId FROM tblSurvey WHERE SurveyId = @SurveyId))
	END TRY
			BEGIN CATCH	
			END CATCH
		
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CentreLevelSummary]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Abhinandan Patil
-- Create date: 11/12/2014
-- Description:	To get datatable of District Level Summary
-- Example: csp_Get_CentreLevelSummary 1
-- =============================================
CREATE PROC [dbo].[csp_Get_CentreLevelSummary]
(
	@TalukaId INT
)
AS
BEGIN						
	BEGIN TRy

		SELECT CentreType,Centre,TT,CAST([A+] as NVARCHAR) [A+],CAST([A] as NVARCHAR) [A],CAST([B] as NVARCHAR) [B],CAST([C] as NVARCHAR) [C],CAST([D] as NVARCHAR) [D] FROM (SELECT * FROM 
		(
			SELECT Grade,CentreType,NULL AS Centre, NULL as TT FROM tblResult R 
			INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
			INNER JOIN tblCentre C ON S.CentreId=C.CentreId
			INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
			INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId	AND T.TalukaId=@TalukaId		
			INNER JOIN
			(SELECT MAX(VisitDate) VisitDate,SI.CentreId FROM tblSurvey SI
			INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
			GROUP BY SI.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate
		) AS Z
		PIVOT
		(
		Count(Grade)
		FOR Grade IN ([A+],[A],[B],[C],[D])
		) AS Z

		UNION ALL

		SELECT * FROM 
		(
			SELECT Grade,CentreType,Centre, 'Last Survey Date : ' + CONVERT(nvarchar,S.VisitDate,103) + ' Score : ' + CONVERT(nvarchar,Percentage) + '%' as TT FROM tblResult R 
			INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
			INNER JOIN tblCentre C ON S.CentreId=C.CentreId
			INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
			INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId	AND T.TalukaId=@TalukaId	
			INNER JOIN
			(SELECT MAX(VisitDate) VisitDate,SI.CentreId FROM tblSurvey SI
			INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
			GROUP BY SI.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate
		) AS Z
		PIVOT
		(
		Count(Grade)
		FOR Grade IN ([A+],[A],[B],[C],[D])
		) AS Z
		) AS S

		END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CentreSectionGradeProgressChart]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Mahesh Warmbe
-- Create date: 03/01/2015
-- Description:	To get datatable of Centre Section grade progress chart
-- Example: csp_Get_CentreSectionGradeProgressChart 1000
-- =============================================
CREATE PROC [dbo].[csp_Get_CentreSectionGradeProgressChart]
(
	@CentreId INT
)
AS
BEGIN						
	BEGIN TRY	
		SELECT 
			tblObtainedMarks.SurveyId,
			CAST((tblObtainedMarks.ObtainedMarks * 100)/(tblTotalWeight.TotalWeight*1.0) AS NUMERIC(18,2))AS Percentage,
			CT.Prefix,
			CONVERT(NVARCHAR,S.VisitDate,103) VisitDate
		FROM
		(SELECT SUM(weightage) AS ObtainedMarks, SurveyId,CategoryTypeId FROM tblSurveyAnswer
		WHERE SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC) AND CategoryTypeId < 9
		GROUP BY CategoryTypeId, SurveyId,CategoryTypeId) tblObtainedMarks

		INNER JOIN 

		(SELECT
			SUM(tblWeight.TotalWeight) AS TotalWeight,
			CategoryTypeId
		FROM(Select Max(A.weightage) AS TotalWeight,A.QuestionId, Q.CategoryTypeId from tblAnswer A
		INNER JOIN tblQuestion Q ON A.QuestionId=Q.QuestionId
		INNER JOIN tblSurveyAnswer SA ON Q.QuestionId=SA.QuestionId 
		WHERE SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC) AND Q.CategoryTypeId < 9
		GROUP BY A.QuestionId ,A.QuestionId, Q.CategoryTypeId ) tblWeight Group BY CategoryTypeId) tblTotalWeight ON tblObtainedMarks.CategoryTypeId=tblTotalWeight.CategoryTypeId
		INNER JOIN tblCategoryType CT ON tblTotalWeight.CategoryTypeId= CT.CategoryTypeId
		INNER JOIN tblSurvey S ON tblObtainedMarks.SurveyId=S.SurveyId
		ORDER BY VisitDate
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CentreType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Centre Type
-- Example: csp_Get_CentreType
-- =============================================
CREATE PROC [dbo].[csp_Get_CentreType]
AS
BEGIN						
	BEGIN TRY
		SELECT CentreTypeId,CentreType,Description FROM tblCentreType ORDER BY CentreTypeId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Child_Health_EmunisationProgressChart]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Mahesh Warmbe
-- Create date: 03/01/2015
-- Description:	To get datatable of Centre Section grade progress chart
-- Example: csp_Get_Child_Health_EmunisationProgressChart 6
-- =============================================
CREATE PROC [dbo].[csp_Get_Child_Health_EmunisationProgressChart]
(
	@CentreId INT   --1.PHC 2.RH 3.SC 4.SDH
)
AS
BEGIN	
	DECLARE @CentreType INT;
	SET @CentreType = (SELECT CentreTypeId FROM tblCentre WHERE CentreId=@CentreId);
	
	IF(@CentreId <>3)  -- RH
	BEGIN
			SELECT 	
			tblTotalScore.SurveyId,
			CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
			'ChildHealth' AS ChildHealth,
			CAST((tblObtainScore.Optained *100)/(tblTotalScore.TotalWeight * 1.0 ) AS NUMERIC(18,2)) AS Percentage 
			FROM
			(SELECT SUM(SA.weightage) AS Optained,SA.SurveyId FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId= Q.QuestionId
			WHERE SA.SurveyId IN((SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)) AND Q.SubCategoryTyepId IN(32,33)
			GROUP BY SA.SurveyId) tblObtainScore

			INNER JOIN 

			(SELECT SUM(tblMaxWeight.Weightage) AS TotalWeight,
			tblMaxWeight.SurveyId
			FROM
			(SELECT MAX(A.weightage) AS Weightage,A.QuestionId,SA.SurveyId FROM tblAnswer A
			INNER JOIN tblSurveyAnswer SA ON SA.QuestionId=A.QuestionId
			INNER JOIN tblQuestion Q ON SA.QuestionId= Q.QuestionId
			WHERE SA.SurveyId IN((SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)) AND Q.SubCategoryTyepId IN(32,33)
			GROUP BY A.QuestionId,SA.SurveyId) tblMaxWeight
			GROUP BY tblMaxWeight.SurveyId) tblTotalScore ON tblObtainScore.SurveyId=tblTotalScore.SurveyId
			INNER JOIN tblSurvey S ON tblTotalScore.SurveyId=S.SurveyId

			UNION

			SELECT 
			tblTotalScore.SurveyId,
			CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
			'Immunization' AS ChildHealth,
			CAST((tblObtainScore.Optained *100)/(tblTotalScore.TotalWeight * 1.0 ) AS NUMERIC(18,2)) AS Percentage 
			FROM
			(SELECT SUM(SA.weightage) AS Optained,SA.SurveyId FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId= Q.QuestionId
			WHERE SA.SurveyId IN(SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC) AND Q.SubCategoryTyepId IN(31,34,35)
			GROUP BY SA.SurveyId) tblObtainScore

			INNER JOIN 

			(SELECT SUM(tblMaxWeight.Weightage) AS TotalWeight,
			tblMaxWeight.SurveyId
			FROM
			(SELECT MAX(A.weightage) AS Weightage,A.QuestionId,SA.SurveyId FROM tblAnswer A
			INNER JOIN tblSurveyAnswer SA ON SA.QuestionId=A.QuestionId
			INNER JOIN tblQuestion Q ON SA.QuestionId= Q.QuestionId
			WHERE SA.SurveyId IN(SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC) AND Q.SubCategoryTyepId IN(31,34,35)
			GROUP BY A.QuestionId,SA.SurveyId) tblMaxWeight
			GROUP BY tblMaxWeight.SurveyId) tblTotalScore ON tblObtainScore.SurveyId=tblTotalScore.SurveyId
			INNER JOIN tblSurvey S ON tblTotalScore.SurveyId=S.SurveyId
	END
ELSE
	BEGIN

		SELECT
			SU.SurveyId,
			CONVERT(NVARCHAR,SU.VisitDate,103) AS VisitDate,
			'ChildHealth' AS ChildHealth,
			tblChildhealth.Percentage
			FROM 
			(SELECT 
			SA.SurveyId,
			CAST(SUM(SA.weightage * 1.0)* 100/
			(SELECT SUM(Weightage)  FROM 
			(SELECT MAX(weightage) AS Weightage,QuestionId FROM tblAnswer
			WHERE QuestionId BETWEEN 849 AND 856
			GROUP BY QuestionId) tblMaxTotal) AS NUMERIC(18,2)) AS Percentage
			FROM tblSurveyAnswer SA
			WHERE SA.QuestionId BETWEEN 849 AND 856 AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC) 
			GROUP BY SA.SurveyId) tblChildhealth
			INNER JOIN tblSurvey SU ON tblChildhealth.SurveyId=SU.SurveyId

			UNION

			SELECT
			SU.SurveyId,
			CONVERT(NVARCHAR,SU.VisitDate,103) AS VisitDate,
			'Immunization' AS ChildHealth,
			tblChildhealth.Percentage
			FROM 
			(SELECT 
			SA.SurveyId,
			CAST(SUM(SA.weightage * 1.0)* 100/
			(SELECT SUM(Weightage)  FROM 
			(SELECT MAX(weightage) AS Weightage,QuestionId FROM tblAnswer
			WHERE QuestionId IN (845,466,847,848,861,862,863,864,865,866,867,868,869,870,871,872) 
			GROUP BY QuestionId) tblMaxTotal) AS NUMERIC(18,2)) AS Percentage
			FROM tblSurveyAnswer SA
			WHERE  SA.QuestionId IN(845,466,847,848,861,862,863,864,865,866,867,868,869,870,871,872) AND SA.SurveyId IN(SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC) 
			GROUP BY SA.SurveyId) tblChildhealth
			INNER JOIN tblSurvey SU ON tblChildhealth.SurveyId=SU.SurveyId
	
	END
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Clinic_RNTCP_NVBDCP_ProgrssChart]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Mahesh Warambhe
-- Create date: 03/01/2015
-- Description:	To get datatable of  Clinic _RNTCP_ NVBDCP_Progrss Chart
-- Example: csp_Get_Clinic_RNTCP_NVBDCP_ProgrssChart 4
-- =============================================
CREATE PROC [dbo].[csp_Get_Clinic_RNTCP_NVBDCP_ProgrssChart]
(
	@CentreId INT   --1.PHC 2.RH 3.SC 4.SDH
)
AS
BEGIN	
	DECLARE @CentreTypeId INT;
	SET @CentreTypeId = (SELECT CentreTypeId FROM tblCentre WHERE CentreId=@CentreId);
	
	IF(@CentreTypeId = 1)  --PHC
	BEGIN
		SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId	IN(295,296)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ClinicalService' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(295,296) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(316)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'RNTCP' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(316) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(317)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'NVBDCP' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(317) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 
	END
    IF(@CentreTypeId = 2)  -- RH
	BEGIN
		SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(653,654)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ClinicalService' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(653,654) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(666)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'RNTCP' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(666) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(667)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'NVBDCP' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(667) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 
	END

	 IF(@CentreTypeId = 3)  -- SC
	BEGIN
		SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1224,1225)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ClinicalService' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1224,1225) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1245)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'RNTCP' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1245) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1246)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'NVBDCP' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1246) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 
	END

	IF(@CentreTypeId = 4 )  -- SDH
	BEGIN
		SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1185,1186)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ClinicalService' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1185,1186) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1216)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'RNTCP' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1216) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1217)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'NVBDCP' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1217) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 
	END
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_CommonMOQA]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Mahesh Warambhe
-- Create date: 01/12/2014
-- Description:	To get datatable of SurveyResult 
-- Example: csp_Get_CommonMOQA 22
-- =============================================
CREATE PROC [dbo].[csp_Get_CommonMOQA]
(
@Operation INT,
@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY		
	IF(@Operation =1) --1. Result 
		 BEGIN
		   IF EXISTS (SELECT SurveyId FROM tblResult WHERE SurveyId = @SurveyId And ResultQATeamLeaderId IS NOT NULL )
			BEGIN
					SELECT	
					ResultQATeamLeaderId,
					GiQATeamLeaderId,
					ActionQATeamLeaderId
					 FROM tblResult
				    WHERE SurveyId = @SurveyId
			END
		ELSE
			BEGIN
			SELECT	
					ResultQATeamLeaderId,
					GiQATeamLeaderId,
					ActionQATeamLeaderId
					 FROM tblResult
				WHERE SurveyId IN( SELECT Top(1)SurveyId FROM tblSurvey WHERE CentreId IN 
							(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER By             VisitDate DESC)
			END
         END
	IF(@Operation =2) --2. GiResult 
	    BEGIN
		IF EXISTS (SELECT SurveyId FROM tblResult WHERE SurveyId = @SurveyId And GiQATeamLeaderId IS NOT NULL )
			BEGIN
					SELECT	
					ResultQATeamLeaderId,
					GiQATeamLeaderId,
					ActionQATeamLeaderId
					 FROM tblResult
				    WHERE SurveyId = @SurveyId
			END
		ELSE
			BEGIN
			SELECT	
					ResultQATeamLeaderId,
					GiQATeamLeaderId,
					ActionQATeamLeaderId
					 FROM tblResult
				WHERE SurveyId IN( SELECT Top(1)SurveyId FROM tblSurvey WHERE CentreId IN 
							(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER By             VisitDate DESC)
			END
	END
	IF(@Operation =3) --3. ActionPlan
	    IF EXISTS (SELECT SurveyId FROM tblResult WHERE SurveyId = @SurveyId And ActionQATeamLeaderId IS NOT NULL )
			BEGIN
					SELECT	
					ResultQATeamLeaderId,
					GiQATeamLeaderId,
					ActionQATeamLeaderId
					FROM tblResult
				    WHERE SurveyId = @SurveyId
			END
		ELSE
			BEGIN
			SELECT	
					ResultQATeamLeaderId,
					GiQATeamLeaderId,
					ActionQATeamLeaderId
					FROM tblResult
				    WHERE SurveyId IN( SELECT Top(1)SurveyId FROM tblSurvey WHERE CentreId IN 
							(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER By             VisitDate DESC)
			END

	END TRY
	BEGIN CATCH	
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Get_DataFromServer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of User 
-- Example: csp_Get_DataFromServer 1
-- =============================================
CREATE PROC [dbo].[csp_Get_DataFromServer]
(
@CenterId INT

)
AS
BEGIN						
	BEGIN TRY
					
			SELECT UM.UserId,UM.ReportingManagerId,UM.DesignationId,UM.RoleId,UM.UserName,UM.Password,
			UM.FirstName,UM.MiddleName,UM.LastName,UM.QualificationId,UM.ContactNumber,UM.ContactEmail 
			FROM tblUserMaster UM 
			INNER JOIN  tblUserCentreMapping UC ON UM.UserId=UC.UserId 
			INNER JOIN  tblCentre C on UC.CentreId=C.CentreId
			INNER JOIN tblTaluka T on C.TalukaId=T.TalukaId
			INNER JOIN  tblDistrict D on T.DistrictId=D.DistrictId 
			WHERE  UC.CentreId=@CenterId  
			ORDER BY  UM.UserId 

			SELECT * FROM  tblAnsewerType 

			SELECT * FROM  tblAnswer 

			SELECT * FROM  tblCategoryType 

			SELECT * FROM  tblCentre  

			SELECT * FROM  tblCentreType 

			SELECT * FROM  tblDesignationMaster 

			SELECT * FROM  tblDistrict 

			SELECT * FROM  tblGiAnswer 

			SELECT * FROM  tblGrade 

			SELECT * FROM  tblIndicatorMaster 

			SELECT * FROM  tblQualification 

			SELECT * FROM  tblQuestion 

			SELECT * FROM  tblRoleMaster 

			SELECT * FROM  tblSubCategoryType 

			SELECT * FROM  tblSurveyPeople 

			SELECT * FROM  tblSurveySchedule 

			SELECT * FROM  tblTaluka

			SELECT * FROM  tblUserCentreMapping


 
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Designation]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 04/12/2014
-- Description:	To get datatable of Qualification
-- Example: csp_Get_Designation
-- =============================================
CREATE PROC [dbo].[csp_Get_Designation]
AS
BEGIN						
	BEGIN TRY
		SELECT DesignationId,Designation,Description FROM tblDesignationMaster
	END TRY
	BEGIN CATCH	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Designation_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Parshwanath Chougule
-- Create date: 01/12/2014
-- Description:	To get datatable of Designation dropdown
-- Example: csp_Get_Designation_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_Designation_Dropdown]
AS
BEGIN						
	BEGIN TRY
		SELECT DesignationId,Designation FROM tblDesignationMaster ORDER BY Designation
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_DictrictLevelChart]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Abhinandan Patil
-- Create date: 24/09/2014
-- Description:	To get datatable of Distrct Level chart
-- Example: csp_Get_DictrictLevelChart 1
-- =============================================    
CREATE PROC [dbo].[csp_Get_DictrictLevelChart] 
(
	@DistrictId NVARCHAR(MAX)
)
	
AS            
BEGIN 
	BEGIN
		Declare @CentreColumn NVARCHAR(MAX);
		DECLARE @sql NVARCHAR(MAX);

		CREATE TABLE #CentreTypeTable
		(
			CentreType NVARCHAR(MAX)
		)

		INSERT INTO #CentreTypeTable (CentreType)
		SELECT 
			DISTINCT '[' + CentreType + ']' 
		FROM tblCentreType

		SELECT @CentreColumn = COALESCE(@CentreColumn + ',', '') +
		CentreType
		FROM #CentreTypeTable

		DROP TABLE #CentreTypeTable

		SET @sql='
		SELECT * FROM (
			SELECT T.TalukaName,CT.CentreType,C.Centre FROM  tblSurvey S 
			INNER JOIN tblCentre C ON S.CentreId=C.CentreId
			INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
			INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId AND T.DistrictId='+ @DistrictId +'
			INNER JOIN
			(SELECT MAX(VisitDate) VisitDate,SI.CentreId FROM tblSurvey SI
			INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
			GROUP BY SI.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate
		) AS S 
		PIVOT
		(
			COUNT(Centre)
			FOR [CentreType] IN ('+@CentreColumn+')
		) AS p'

		Exec(@sql)

	END
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_District]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Yograj Sulakhe
-- Create date: 27/11/2014
-- Description:	To get datatable of District
-- Example: csp_Get_District
-- =============================================
CREATE PROC [dbo].[csp_Get_District]
(
	@roleId int =null,
	@userId int =null
)
AS
BEGIN	
	IF(@roleId<>0)	
		BEGIN							
			BEGIN TRY
				SELECT DistrictId,DistrictName,Description 
				FROM tblDistrict 
				WHERE 
				DistrictId IN (SELECT DistrictId FROM tblTaluka 
					 WHERE TalukaId IN (SELECT TalukaId FROM tblCentre 
						WHERE CentreId IN (SELECT CentreId FROM	tblUserCentreMapping WHERE UserId = @userId)))
				ORDER BY DistrictId DESC
			END TRY
			BEGIN CATCH	
			END CATCH
		END
	ELSE
		BEGIN							
				BEGIN TRY
					SELECT DistrictId,DistrictName,Description FROM tblDistrict ORDER BY DistrictId DESC
				END TRY
				BEGIN CATCH	
				END CATCH
		END
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_District_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 27/11/2014
-- Description:	To get datatable of District dropdown
-- Example: csp_Get_District_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_District_Dropdown]
(
	@roleId int =null,
   @userId int =null
)
AS
BEGIN	
	IF(@roleId<>0)	
		BEGIN		
			BEGIN TRY
				SELECT DistrictId,DistrictName FROM tblDistrict
				WHERE DistrictId 
				IN (SELECT DistrictId FROM tblTaluka  WHERE TalukaId 
				IN (SELECT TalukaId FROM tblCentre WHERE CentreId 
				IN (SELECT CentreId FROM tblUserCentreMapping WHERE UserId = @userId)))
				 ORDER BY DistrictName
			END TRY
			BEGIN CATCH	
			END CATCH
		END
	ELSE
		BEGIN		
			BEGIN TRY
		SELECT DistrictId,DistrictName FROM tblDistrict ORDER BY DistrictName
	END TRY
	BEGIN CATCH	
	END CATCH
		END
		
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_DistrictLevelSummary]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Abhinandan Patil
-- Create date: 11/12/2014
-- Description:	To get datatable of District Level Summary
-- Example: csp_Get_DistrictLevelSummary 1
-- =============================================
CREATE PROC [dbo].[csp_Get_DistrictLevelSummary]
(
	@DistrictId INT
)
AS
BEGIN						
	BEGIN TRy
		
		SELECT DistrictName,TalukaName,CentreType,CAST([A+] as NVARCHAR) [A+],CAST([A] as NVARCHAR) [A],CAST([B] as NVARCHAR) [B],CAST([C] as NVARCHAR) [C],CAST([D] as NVARCHAR) [D] FROM (SELECT * FROM 
		(
			SELECT DistrictName,Grade,NULL as TalukaName,NULL as CentreType FROM tblResult R 
			INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
			INNER JOIN tblCentre C ON S.CentreId=C.CentreId
			INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
			INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId
			INNER JOIN tblDistrict D ON T.DistrictId=D.DistrictId AND D.DistrictId=@DistrictId
			INNER JOIN
			(SELECT MAX(VisitDate) VisitDate,SI.CentreId FROM tblSurvey SI
			INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
			GROUP BY SI.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate
		) AS Z
		PIVOT
		(
		Count(Grade)
		FOR Grade IN ([A+],[A],[B],[C],[D])
		) AS Z

		UNION ALL

		SELECT * FROM 
		(
			SELECT NULL as DistrictName,Grade,TalukaName,NULL as CentreType FROM tblResult R 
			INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
			INNER JOIN tblCentre C ON S.CentreId=C.CentreId
			INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
			INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId
			INNER JOIN tblDistrict D ON T.DistrictId=D.DistrictId AND D.DistrictId=@DistrictId
			INNER JOIN
			(SELECT MAX(VisitDate) VisitDate,SI.CentreId FROM tblSurvey SI
			INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
			GROUP BY SI.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate
		) AS Z
		PIVOT
		(
		Count(Grade)
		FOR Grade IN ([A+],[A],[B],[C],[D])
		) AS Z

		UNION ALL

		SELECT * FROM 
		(
			SELECT NULL as DistrictName,Grade,TalukaName,CentreType FROM tblResult R 
			INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
			INNER JOIN tblCentre C ON S.CentreId=C.CentreId
			INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
			INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId
			INNER JOIN tblDistrict D ON T.DistrictId=D.DistrictId AND D.DistrictId=@DistrictId
			INNER JOIN
			(SELECT MAX(VisitDate) VisitDate,SI.CentreId FROM tblSurvey SI
			INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
			GROUP BY SI.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate
		) AS Z
		PIVOT
		(
		Count(Grade)
		FOR Grade IN ([A+],[A],[B],[C],[D])
		) AS Z) AS S

		SELECT DistrictName,TalukaName,CentreType,Centre,Grade,Percentage FROM tblResult R 
		INNER JOIN tblSurvey S ON R.SurveyId=S.SurveyId
		INNER JOIN tblCentre C ON S.CentreId=C.CentreId
		INNER JOIN tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId
		INNER JOIN tblTaluka T ON C.TalukaId=T.TalukaId
		INNER JOIN tblDistrict D ON T.DistrictId=D.DistrictId AND D.DistrictId=@DistrictId
		INNER JOIN
		(SELECT MAX(VisitDate) VisitDate,SI.CentreId FROM tblSurvey SI
		INNER JOIN tblCentre C ON C.CentreId=SI.SurveyId
		GROUP BY SI.CentreId) AS P ON S.CentreId=P.CentreId AND S.VisitDate=P.VisitDate

		END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_DQAGDetail]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 07/12/2014
-- Description:	To get datatable of DQA Detail
-- Example: csp_Get_DQADetail 0
-- =============================================
CREATE PROC [dbo].[csp_Get_DQAGDetail]
(
	@UserId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT 
			Q.QualificationId,D.DesignationId,U.ContactNumber,D.Designation,Q.Qualification from tblUserMaster U 
			INNER JOIN tblUserCentreMapping UC ON U.UserId = UC.UserId
			INNER JOIN tblSurvey S ON S.CentreId = UC.CentreId
			INNER JOIN tblQualification Q ON U.QualificationId = Q.QualificationId
			INNER JOIN tblDesignationMaster D ON U.DesignationId = D.DesignationId
			WHERE UC.UserId = @UserId
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_DQAGMembersSelfAssessmentDetail]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of DQAGMembersSelfAssessmentDetail 
-- Example: csp_Get_DQAGMembersSelfAssessmentDetail 1
-- =============================================
CREATE PROC [dbo].[csp_Get_DQAGMembersSelfAssessmentDetail]
(
	@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY
			IF EXISTS (SELECT SurveyId FROM tblStaffRespondent WHERE SurveyId = @SurveyId )
				BEGIN
					SELECT D.UserId,UM.FirstName+' '+UM.LastName AS PeopleName,DM.Designation,Q.Qualification,UM.ContactNumber FROM tblDQAG D
					INNER JOIN tblUserMaster UM ON D.UserId = UM.UserId
					INNER JOIN tblQualification Q ON UM.QualificationId = Q.QualificationId
					INNER JOIN tblDesignationMaster DM ON UM.DesignationId = DM.DesignationId 
					WHERE D.SurveyId = @SurveyId 
				END
			ELSE
				BEGIN
					SELECT D.UserId,UM.FirstName+' '+UM.LastName AS PeopleName,DM.Designation,Q.Qualification,UM.ContactNumber FROM tblDQAG D
					INNER JOIN tblUserMaster UM ON D.UserId = UM.UserId
					INNER JOIN tblQualification Q ON UM.QualificationId = Q.QualificationId
					INNER JOIN tblDesignationMaster DM ON UM.DesignationId = DM.DesignationId 
					WHERE D.SurveyId IN  
							( SELECT Top(1)SurveyId FROM tblSurvey WHERE CentreId IN 
							(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER By VisitDate DESC)
				END
	END TRY
	BEGIN CATCH	
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[csp_Get_DQAGMembersTeam]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 07/12/2014
-- Description:	To get datatable of question
-- Example: csp_Get_DQAGMembersTeam 
-- =============================================
CREATE PROC [dbo].[csp_Get_DQAGMembersTeam]
(
  @SurveyId INT
)
AS
BEGIN						
	BEGIN TRY
		select U.UserId,U.FirstName + ' ' + U.LastName AS PeopleName from tblUserMaster U 
			INNER JOIN tblUserCentreMapping UC ON U.UserId = UC.UserId
			INNER JOIN tblSurvey S ON S.CentreId = UC.CentreId
			WHERE S.SurveyId = @SurveyId
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_EmailSetting]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================

-- Author: Abhinandan Patil

-- Create date: 05/11/2014

-- Description:	To Get datatable of email setting

-- =============================================

CREATE PROC [dbo].[csp_Get_EmailSetting]

AS

BEGIN							

	

	BEGIN TRY

	

	SELECT EmailId,SMTPHost,SMTPUserName,SMTPPassword,SMTPPort,EnableSSL FROM tblEmailSetting

	END TRY

	

	BEGIN CATCH

	

	END CATCH

END



GO
/****** Object:  StoredProcedure [dbo].[csp_Get_GeneralInformation_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Mahesh Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Survey General Information 
-- Example: csp_Get_Survey_Report 1
-- =============================================

CREATE PROC [dbo].[csp_Get_GeneralInformation_Report]
(
	@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY

	--  Generel information
		SELECT
			D.DistrictName,			
			T.TalukaName,		
			S.NameofMO,
			S.MobNoofMO,
			S.Email,
			C.Centre,
			S.TelephoneNo,
			S.VisitDate,
			S.VisitRound,
			PreviousVisitScore = (SELECT Percentage FROM tblResult 
			WHERE SurveyId IN (SELECT TOP(1)SurveyId FROM tblSurvey 
			 WHERE SurveyId = @SurveyId order By SurveyId Desc)),				
			S.PreviousVisitDate,
			S.PreviousVisitScore,
			S.SubCentresNo,
			S.PopulationCovered,
		    IPHSStatus = CASE S.IPHSStatus WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END,
			FRUStatus = CASE S.[247Status] WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END,
			DeliveryPoint = CASE S.DeliveryPoint WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END,
			S.Distance,
			S.VisitStartTime,
			S.VisitEndTime,
			S.TotalTime,
			C.Address,
			CT.CentreType			
		FROM tblSurvey S
		INNER JOIN tblCentre C ON C.CentreId = S.CentreId
		INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
		INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
		INNER JOIN tblCentreType CT ON C.CentreTypeId = CT.CentreTypeId
		WHERE SurveyId= @SurveyId
		ORDER BY S.SurveyId DESC

	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_GiQuestion_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Mahesh Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Survey General Information 
-- Example: csp_Get_GiQuestion_Report 3
-- =============================================

CREATE PROC [dbo].[csp_Get_GiQuestion_Report]
(
	@SurveyId INT
)
AS
BEGIN						
		SELECT
		'Q'+ PreFix+' ' AS PreFix,
		Question,  
		ThreeMonthRecordA,
		ThreeMonthRecordB,
		ROUND(Percentage,0) AS Percentage,
		[ScoreRange-10TO+10] AS ScoreRange,
		DecreaseBy10PercentOrMore,
		IncreaseBy10PercentOrmore ,
		Score = (SELECT SUM(weightage)  FROM tblGiAnswer G
				INNER JOIN tblSurveyAnswer S ON G.QuestionId=S.QuestionId 
				WHERE SurveyId=@SurveyId)
		FROM tblGiAnswer A
		INNER JOIN tblGIResult R ON A.QuestionId=R.QuestionId
		INNER JOIN tblQuestion Q ON A.QuestionId=Q.QuestionId
		INNER JOIN tblSubCategoryType SC ON Q.SubCategoryTyepId=SC.SubCategoryTypeId 

		WHERE SurveyId=@SurveyId
END



GO
/****** Object:  StoredProcedure [dbo].[csp_Get_GiQuestion20To29_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Mahesh Warambhe
-- Create date: 29/11/2014
-- Description:	To get datatable of Survey General Information 
-- Example: csp_Get_GiQuestion20To29_Report 1
-- =============================================

CREATE PROC [dbo].[csp_Get_GiQuestion20To29_Report]
(
	@SurveyId INT
)
AS
BEGIN						
		SELECT 		
		'Q'+SC.PreFix+' '+ CASE ReviewRecordNo  WHEN '201' THEN '20A' ELSE CAST(ReviewRecordNo AS NVARCHAR) END AS PreFix ,		
		Question,
		LastThreeMonthPerformance,
		[ScoreRange-10TO+10] AS ScoreRange ,
		DecreaseBy10PercentOrMore,
		IncreaseBy10PercentOrmore,
		Score1 = (SELECT SUM(weightage)  FROM tblGiAnswer G
				INNER JOIN tblSurveyAnswer S ON G.QuestionId=S.QuestionId 
				WHERE SurveyId=@SurveyId),
		Score2 = (SELECT SUM(weightage) FROM tblSurveyAnswer S INNER JOIN  tblRevievRecord R ON S.QuestionId=R.QuestionId WHERE S.SurveyId = @SurveyId)
		FROM tblRevievRecord R
		INNER JOIN tblGiAnswer G ON R.QuestionId=G.QuestionId
		INNER JOIN tblQuestion Q ON R.QuestionId = Q.QuestionId
		INNER JOIN tblSubCategoryType SC ON Q.SubCategoryTyepId = SC.SubCategoryTypeId
		WHERE SurveyId= @SurveyId
		

END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_GiSurveyQuestion]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 05/11/2014
-- Description:	To get datatable of Answer Option
-- Example: csp_Get_GiSurveyQuestion  3,10
-- =============================================
CREATE PROC [dbo].[csp_Get_GiSurveyQuestion]

(

@SurveyId INT,

@CategoryTypeId INT

)
AS

BEGIN						

	BEGIN TRy

	IF EXISTS(SELECT SurveyAnswerId FROM tblSurveyAnswer WHERE SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId)

	BEGIN
	
	
    SELECT 'Q' + CT.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By GR.QuestionId)) QNo, GR.QuestionId,
	GR.QuestionId,
	Q.Question,
	ThreeMonthRecordA AS ThreeMonthRecordA,
	ThreeMonthRecordB AS ThreeMonthRecordB,
	Percentage 	AS Performance  
	FROM tblGIResult GR  
	INNER JOIN tblQuestion Q ON GR.QuestionId=Q.QuestionId 
	INNER JOIN tblCategoryType CT ON Q.CategoryTypeId=CT.CategoryTypeId
	WHERE  SurveyId=@SurveyId and GR.CategoryTypeId =@CategoryTypeId
	
 	
	END				

	ELSE

	BEGIN
     
   SELECT 'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By QuestionId)) QNo,
	QuestionId, 
	Question ,
	'' AS ThreeMonthRecordA , 
	'' AS ThreeMonthRecordB,
	'' AS Performance 
    FROM tblQuestion Q
    INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId
    INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId
	INNER JOIN tblCentre TC ON CT.CentreTypeId = TC.CentreTypeId
	INNER JOIN tblSurvey S ON TC.CentreId=S.CentreId 
    WHERE Q.CategoryTypeId= @CategoryTypeId AND Q.Status ='1' AND ReviewRecordNo ='1' AND S.SurveyId=@SurveyId
	
	END

	END TRY

	BEGIN CATCH	

	END CATCH

	END










GO
/****** Object:  StoredProcedure [dbo].[csp_Get_GISurveyResult]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Mahesh Warambhe
-- Create date: 01/12/2014
-- Description:	To get datatable of SurveyResult 
-- Example: csp_Get_GISurveyResult 2
-- =============================================
CREATE PROC [dbo].[csp_Get_GISurveyResult]
(
@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY
		If((Select C.CentreTypeId from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId where S.SurveyId = @SurveyId) = 3)
   BEGIN
    SELECT
			CategoryTypeId = '0',
			' General Facility Readiness' AS CategoryType, 
			C.DisplayName AS SubCategoryType,
			I.DisplayName AS Indicators,
			tb1.Maxpoint AS TotalPoints,
			tb2.Weightage AS ObtainedPoints,
		    CAST(CAST((tb2.Weightage * 100/ (tb1.Maxpoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage
			FROM 
			(Select SUM(A.MaxWeight)As MaxPoint,CategoryTypeId from (Select MAX(A.weightage)As MaxWeight,Q.QuestionId,Q.SubCategoryTyepId,Q.CategoryTypeId from tblAnswer A
				inner join tblQuestion Q on A.QuestionId = Q.QuestionId
				inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
				where Q.CategoryTypeId < 7 and Q.IsGi=1 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
				group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
			) A
				group by CategoryTypeId) tb1

			inner join  

			(SELECT SA.CategoryTypeId,SurveyId,SUM(weightage)AS Weightage 
			FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId=Q.QuestionId 
			WHERE SA.CategoryTypeId < 7  and Q.IsGi=1 AND SA.weightage IS NOT NULL
			GROUP BY SA.CategoryTypeId,SurveyId) tb2 on tb1.CategoryTypeId=tb2.CategoryTypeId
			inner join tblCategoryType C ON TB1.CategoryTypeId = C.CategoryTypeId
			INNER JOIN tblIndicatorMaster I ON TB1.CategoryTypeId=I.CategoryTypeId and I.CentreTypeId= (SELECT CentreTypeId FROM tblSurvey s INNER JOIN tblCentre c ON S.CentreId = C.CentreId WHERE SurveyId =@SurveyId)
			WHERE SurveyId= @SurveyId  


			UNION

			 SELECT
			CT.CategoryTypeId,
			CT.DisplayName AS CategoryType,
			SC.DisplayName AS SubCategoryType,
			I.DisplayName AS Indicators,
			TotalMaxPoint AS TotalPoints,
			Weightage AS ObtainedPoints,			
			 CAST(CAST((Weightage * 100/ (TotalMaxPoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage
			FROM (Select 
					SUM(A.MaxWeight)As TotalMaxPoint,
					CategoryTypeId,
					SubCategoryTyepId 
					from 
					(Select 
						MAX(A.weightage)As MaxWeight,
						Q.QuestionId,
						Q.SubCategoryTyepId,
						Q.CategoryTypeId 
						from tblAnswer A
						inner join tblQuestion Q on A.QuestionId = Q.QuestionId
						inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
						where Q.CategoryTypeId between 7 and 9 and Q.IsGi=1 And  SurveyId=@SurveyId AND SA.weightage IS NOT NULL
						group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
					) A
				group by SubCategoryTyepId,CategoryTypeId
				) tb1

			inner join 

			(SELECT SUM(SA.weightage) AS Weightage, Q.CategoryTypeId,q.SubCategoryTyepId,SurveyId FROM tblSurveyAnswer SA
			inner join (SELECT QuestionId,CategoryTypeId,SubCategoryTyepId FROM tblQuestion WHERE IsGi=1
						  ) Q on SA.QuestionId=Q.QuestionId
					WHERE Q.CategoryTypeId  between 7 AND 9  AND SA.weightage IS NOT NULL
			GROUP BY Q.SubCategoryTyepId,Q.CategoryTypeId,SurveyId) tb2 on tb1.SubCategoryTyepId =tb2.SubCategoryTyepId

			inner join tblSubCategoryType SC ON TB1.SubCategoryTyepId=SC.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON TB2.CategoryTypeId=CT.CategoryTypeId
			INNER JOIN tblIndicatorMaster I ON TB1.CategoryTypeId=I.CategoryTypeId AND SC.SubCategoryTypeId=I.SubCategoryTypeId and I.CentreTypeId= (sELECT CentreTypeId FROM tblSurvey s INNER JOIN tblCentre c ON S.CentreId = C.CentreId WHERE SurveyId =@SurveyId)
			WHERE SurveyId=@SurveyId


			UNION	

			   Select * from (
			   SELECT 
			    CategoryType1='10',
				'Output Indicators' AS SubCategoryType,
				 CategoryType = (SELECT DisplayName FROM tblCategoryType WHERE CategoryTypeId=10),
				 Indicators =(Select IndicatorsForOIResult From tblSurvey S
						inner join tblCentre C on S.CentreId=c.CentreId
						inner join tblCentreType CT on C.CentreTypeId=CT.CentreTypeId
						where SurveyId = @SurveyId),				
				SUM(T.MaxScore) as TotalPoints ,
				SUM(T.ObtainScore) as ObtainedPoints,
				CAST(CAST(SUM(T.ObtainScore * 1.0)*100/SUM(T.MaxScore)AS NUMERIC(18,2))AS NVARCHAR) +'%'  AS Percentage			
					fROM (SELECT SUM(weightage) AS ObtainScore,
					SUM(maxscore) AS MaxScore,
					CAST(CAST((SUM(weightage * 1.0)*100/SUM(maxscore)*1.0)AS NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA :' As CategoryType
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=10 )TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId 
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType

					UNION ALL
	
					select SUM(S.weightage) AS ObtainScore, SUM(IncreaseBy10PercentOrmore) + ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
						   INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
						   INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId  and S.CategoryTypeId=10 ) AS MaxScore ,
					CAST(CAST((SUM(S.weightage)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA : 'As CategoryType from tblGiAnswer G 
					INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
					INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
					WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 AND G.IncreaseBy10PercentOrmore>=0 and Q.IsGi=1
					) T group by T.CategoryType )OI WHERE OI.ObtainedPoints IS NOT NULL
			 
		ORDER BY CategoryType
   END
ELSE
   BEGIN
	 SELECT
			CategoryTypeId = '0',
			' General Facility Readiness' AS CategoryType, 
			C.DisplayName AS SubCategoryType,
			I.DisplayName AS Indicators,
			tb1.Maxpoint AS TotalPoints,
			tb2.Weightage AS ObtainedPoints,
		    CAST(CAST((tb2.Weightage * 100/ (tb1.Maxpoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage
			FROM 
			(Select SUM(A.MaxWeight)As MaxPoint,CategoryTypeId from (Select MAX(A.weightage)As MaxWeight,Q.QuestionId,Q.SubCategoryTyepId,Q.CategoryTypeId from tblAnswer A
				inner join tblQuestion Q on A.QuestionId = Q.QuestionId
				inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
				where Q.CategoryTypeId < 7 and Q.IsGi=1 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
				group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
			) A
				group by CategoryTypeId) tb1

			inner join  

			(SELECT SA.CategoryTypeId,SurveyId,SUM(weightage)AS Weightage 
			FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId=Q.QuestionId 
			WHERE SA.CategoryTypeId < 7  and Q.IsGi=1 AND SA.weightage IS NOT NULL
			GROUP BY SA.CategoryTypeId,SurveyId) tb2 on tb1.CategoryTypeId=tb2.CategoryTypeId
			inner join tblCategoryType C ON TB1.CategoryTypeId = C.CategoryTypeId
			INNER JOIN tblIndicatorMaster I ON TB1.CategoryTypeId=I.CategoryTypeId and I.CentreTypeId= (sELECT CentreTypeId FROM tblSurvey s INNER JOIN tblCentre c ON S.CentreId = C.CentreId WHERE SurveyId =@SurveyId)
			WHERE SurveyId= @SurveyId  


			UNION

			 SELECT
			CT.CategoryTypeId,
			CT.DisplayName AS CategoryType,
			SC.DisplayName AS SubCategoryType,
			I.DisplayName AS Indicators,
			TotalMaxPoint AS TotalPoints,
			Weightage AS ObtainedPoints,			
			 CAST(CAST((Weightage * 100/ (TotalMaxPoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage
			FROM (Select 
					SUM(A.MaxWeight)As TotalMaxPoint,
					CategoryTypeId,
					SubCategoryTyepId 
					from 
					(Select 
						MAX(A.weightage)As MaxWeight,
						Q.QuestionId,
						Q.SubCategoryTyepId,
						Q.CategoryTypeId 
						from tblAnswer A
						inner join tblQuestion Q on A.QuestionId = Q.QuestionId
						inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
						where Q.CategoryTypeId between 7 and 9 and Q.IsGi=1 And  SurveyId=@SurveyId AND SA.weightage IS NOT NULL
						group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
					) A
				group by SubCategoryTyepId,CategoryTypeId
				) tb1

			inner join 

			(SELECT SUM(SA.weightage) AS Weightage, Q.CategoryTypeId,q.SubCategoryTyepId,SurveyId FROM tblSurveyAnswer SA
			inner join (SELECT QuestionId,CategoryTypeId,SubCategoryTyepId FROM tblQuestion WHERE IsGi=1
						  ) Q on SA.QuestionId=Q.QuestionId
					WHERE Q.CategoryTypeId  between 7 AND 9  AND SA.weightage IS NOT NULL
			GROUP BY Q.SubCategoryTyepId,Q.CategoryTypeId,SurveyId) tb2 on tb1.SubCategoryTyepId =tb2.SubCategoryTyepId

			inner join tblSubCategoryType SC ON TB1.SubCategoryTyepId=SC.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON TB2.CategoryTypeId=CT.CategoryTypeId
			INNER JOIN tblIndicatorMaster I ON TB1.CategoryTypeId=I.CategoryTypeId AND SC.SubCategoryTypeId=I.SubCategoryTypeId and I.CentreTypeId= (sELECT CentreTypeId FROM tblSurvey s INNER JOIN tblCentre c ON S.CentreId = C.CentreId WHERE SurveyId =@SurveyId)
			WHERE SurveyId=@SurveyId


			UNION	

			Select * from (
			 select  
			 CategoryType1='10',
			 'Output Indicators' AS SubCategoryType,
			 CategoryType = (SELECT DisplayName FROM tblCategoryType WHERE CategoryTypeId=10),
			 Indicators =(Select IndicatorsForOIResult From tblSurvey S
						inner join tblCentre C on S.CentreId=c.CentreId
						inner join tblCentreType CT on C.CentreTypeId=CT.CentreTypeId
						where SurveyId = @SurveyId),
			 
			 SUM(IncreaseBy10PercentOrmore * 1.0)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G   INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=10 and Q.IsGi=1 ) AS TotalPoints ,
			 SUM(S.weightage) AS ObtainedPoints,		
			 CAST(CAST((SUM(S.weightage * 1.0)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS Percentage
			 from tblGiAnswer G 
			 INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
			 INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
			 WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 and  IncreaseBy10PercentOrmore>=0 aND Q.IsGi=1) OI WHERE OI.ObtainedPoints IS NOT NULL

			ORDER BY CategoryType
   END
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_GISurveyResult_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Mahesh Warambhe
-- Create date: 01/12/2014
-- Description:	To get datatable of SurveyResult 
-- Example: csp_Get_GISurveyResult_Report 2
-- =============================================
CREATE PROC [dbo].[csp_Get_GISurveyResult_Report]
(
@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY
		If((Select C.CentreTypeId from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId where S.SurveyId = @SurveyId) = 3)
   BEGIN
    SELECT
			CategoryTypeId = '0',
			' General Facility Readiness' AS CategoryType, 
			C.DisplayName AS SubCategoryType,
			I.DisplayName AS Indicators,
			tb1.Maxpoint AS TotalPoints,
			tb2.Weightage AS ObtainedPoints,
		    CAST(CAST((tb2.Weightage * 100/ (tb1.Maxpoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage,
			MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
			LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
					CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)		
			FROM 
			(Select SUM(A.MaxWeight)As MaxPoint,CategoryTypeId from (Select MAX(A.weightage)As MaxWeight,Q.QuestionId,Q.SubCategoryTyepId,Q.CategoryTypeId from tblAnswer A
				inner join tblQuestion Q on A.QuestionId = Q.QuestionId
				inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
				where Q.CategoryTypeId < 7 and Q.IsGi=1 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
				group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
			) A
				group by CategoryTypeId) tb1

			inner join  

			(SELECT SA.CategoryTypeId,SurveyId,SUM(weightage)AS Weightage 
			FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId=Q.QuestionId 
			WHERE SA.CategoryTypeId < 7  and Q.IsGi=1 AND SA.weightage IS NOT NULL
			GROUP BY SA.CategoryTypeId,SurveyId) tb2 on tb1.CategoryTypeId=tb2.CategoryTypeId
			inner join tblCategoryType C ON TB1.CategoryTypeId = C.CategoryTypeId
			INNER JOIN tblIndicatorMaster I ON TB1.CategoryTypeId=I.CategoryTypeId and I.CentreTypeId= (sELECT CentreTypeId FROM tblSurvey s INNER JOIN tblCentre c ON S.CentreId = C.CentreId WHERE SurveyId =@SurveyId)
			WHERE SurveyId= @SurveyId  


			UNION

			 SELECT
			CT.CategoryTypeId,
			CT.DisplayName AS CategoryType,
			SC.DisplayName AS SubCategoryType,
			I.DisplayName AS Indicators,
			TotalMaxPoint AS TotalPoints,
			Weightage AS ObtainedPoints,			
			 CAST(CAST((Weightage * 100/ (TotalMaxPoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage,
			 '' AS MOName,
			 '' AS LeaderName,
			 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)		
			FROM (Select 
					SUM(A.MaxWeight)As TotalMaxPoint,
					CategoryTypeId,
					SubCategoryTyepId 
					from 
					(Select 
						MAX(A.weightage)As MaxWeight,
						Q.QuestionId,
						Q.SubCategoryTyepId,
						Q.CategoryTypeId 
						from tblAnswer A
						inner join tblQuestion Q on A.QuestionId = Q.QuestionId
						inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
						where Q.CategoryTypeId between 7 and 9 and Q.IsGi=1 And  SurveyId=@SurveyId AND SA.weightage IS NOT NULL
						group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
					) A
				group by SubCategoryTyepId,CategoryTypeId
				) tb1

			inner join 

			(SELECT SUM(SA.weightage) AS Weightage, Q.CategoryTypeId,q.SubCategoryTyepId,SurveyId FROM tblSurveyAnswer SA
			inner join (SELECT QuestionId,CategoryTypeId,SubCategoryTyepId FROM tblQuestion WHERE IsGi=1
						  ) Q on SA.QuestionId=Q.QuestionId
					WHERE Q.CategoryTypeId  between 7 AND 9 AND SA.weightage IS NOT NULL
			GROUP BY Q.SubCategoryTyepId,Q.CategoryTypeId,SurveyId) tb2 on tb1.SubCategoryTyepId =tb2.SubCategoryTyepId

			inner join tblSubCategoryType SC ON TB1.SubCategoryTyepId=SC.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON TB2.CategoryTypeId=CT.CategoryTypeId
			INNER JOIN tblIndicatorMaster I ON TB1.CategoryTypeId=I.CategoryTypeId AND SC.SubCategoryTypeId=I.SubCategoryTypeId and I.CentreTypeId= (sELECT CentreTypeId FROM tblSurvey s INNER JOIN tblCentre c ON S.CentreId = C.CentreId WHERE SurveyId =@SurveyId)
			WHERE SurveyId=@SurveyId


			UNION	
			Select * from (
			   SELECT 
			    CategoryType1='10',
				'Output Indicators' AS SubCategoryType,
				 CategoryType = (SELECT DisplayName FROM tblCategoryType WHERE CategoryTypeId=10),
				 Indicators =(Select IndicatorsForOIResult From tblSurvey S
						inner join tblCentre C on S.CentreId=c.CentreId
						inner join tblCentreType CT on C.CentreTypeId=CT.CentreTypeId
						where SurveyId = @SurveyId),				
				SUM(T.MaxScore) as TotalPoints ,
				SUM(T.ObtainScore) as ObtainedPoints,
				CAST(CAST(SUM(T.ObtainScore * 1.0)*100/SUM(T.MaxScore * 1.0)AS NUMERIC(18,2))AS NVARCHAR) +'%'  AS Percentage,
				  '' AS MOName,
			      '' AS LeaderName,
				  CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)					
					fROM (SELECT SUM(weightage) AS ObtainScore,
					SUM(maxscore) AS MaxScore,
					CAST(CAST((SUM(weightage * 1.0)*100/SUM(maxscore)*1.0)AS NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA :' As CategoryType
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=10 )TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId 
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType

					UNION ALL
	
					select SUM(S.weightage) AS ObtainScore, SUM(IncreaseBy10PercentOrmore) + ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
						   INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
						   INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId  and S.CategoryTypeId=10 ) AS MaxScore ,
					CAST(CAST((SUM(S.weightage)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA : 'As CategoryType from tblGiAnswer G 
					INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
					INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
					WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 AND G.IncreaseBy10PercentOrmore>=0 and Q.IsGi=1
					) T group by T.CategoryType )OI WHERE OI.ObtainedPoints IS NOT NULL
			 
		ORDER BY CategoryType
   END
ELSE
   BEGIN
	 SELECT
			CategoryTypeId = '0',
			' General Facility Readiness' AS CategoryType, 
			C.DisplayName AS SubCategoryType,
			I.DisplayName AS Indicators,
			tb1.Maxpoint AS TotalPoints,
			tb2.Weightage AS ObtainedPoints,
		    CAST(CAST((tb2.Weightage * 100/ (tb1.Maxpoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage,
			MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
			LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
					CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)		
			FROM 
			(Select SUM(A.MaxWeight)As MaxPoint,CategoryTypeId from (Select MAX(A.weightage)As MaxWeight,Q.QuestionId,Q.SubCategoryTyepId,Q.CategoryTypeId from tblAnswer A
				inner join tblQuestion Q on A.QuestionId = Q.QuestionId
				inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
				where Q.CategoryTypeId < 7 and Q.IsGi=1 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
				group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
			) A
				group by CategoryTypeId) tb1

			inner join  

			(SELECT SA.CategoryTypeId,SurveyId,SUM(weightage)AS Weightage 
			FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId=Q.QuestionId 
			WHERE SA.CategoryTypeId < 7  and Q.IsGi=1 AND SA.weightage IS NOT NULL
			GROUP BY SA.CategoryTypeId,SurveyId) tb2 on tb1.CategoryTypeId=tb2.CategoryTypeId
			inner join tblCategoryType C ON TB1.CategoryTypeId = C.CategoryTypeId
			INNER JOIN tblIndicatorMaster I ON TB1.CategoryTypeId=I.CategoryTypeId and I.CentreTypeId= (sELECT CentreTypeId FROM tblSurvey s INNER JOIN tblCentre c ON S.CentreId = C.CentreId WHERE SurveyId =@SurveyId)
			WHERE SurveyId= @SurveyId  


			UNION

			 SELECT
			CT.CategoryTypeId,
			CT.DisplayName AS CategoryType,
			SC.DisplayName AS SubCategoryType,
			I.DisplayName AS Indicators,
			TotalMaxPoint AS TotalPoints,
			Weightage AS ObtainedPoints,			
			 CAST(CAST((Weightage * 100/ (TotalMaxPoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage,
			 '' AS MOName,
			 '' AS LeaderName,
			 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)		
			FROM (Select 
					SUM(A.MaxWeight)As TotalMaxPoint,
					CategoryTypeId,
					SubCategoryTyepId 
					from 
					(Select 
						MAX(A.weightage)As MaxWeight,
						Q.QuestionId,
						Q.SubCategoryTyepId,
						Q.CategoryTypeId 
						from tblAnswer A
						inner join tblQuestion Q on A.QuestionId = Q.QuestionId
						inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
						where Q.CategoryTypeId between 7 and 9 and Q.IsGi=1 And  SurveyId=@SurveyId AND SA.weightage IS NOT NULL
						group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
					) A
				group by SubCategoryTyepId,CategoryTypeId
				) tb1

			inner join 

			(SELECT SUM(SA.weightage) AS Weightage, Q.CategoryTypeId,q.SubCategoryTyepId,SurveyId FROM tblSurveyAnswer SA
			inner join (SELECT QuestionId,CategoryTypeId,SubCategoryTyepId FROM tblQuestion WHERE IsGi=1
						  ) Q on SA.QuestionId=Q.QuestionId
					WHERE Q.CategoryTypeId  between 7 AND 9  AND SA.weightage IS NOT NULL
			GROUP BY Q.SubCategoryTyepId,Q.CategoryTypeId,SurveyId) tb2 on tb1.SubCategoryTyepId =tb2.SubCategoryTyepId

			inner join tblSubCategoryType SC ON TB1.SubCategoryTyepId=SC.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON TB2.CategoryTypeId=CT.CategoryTypeId
			INNER JOIN tblIndicatorMaster I ON TB1.CategoryTypeId=I.CategoryTypeId AND SC.SubCategoryTypeId=I.SubCategoryTypeId and I.CentreTypeId= (sELECT CentreTypeId FROM tblSurvey s INNER JOIN tblCentre c ON S.CentreId = C.CentreId WHERE SurveyId =@SurveyId)
			WHERE SurveyId=@SurveyId


			UNION	

			Select * from (
			 select  
			 CategoryType1='10',
			 'Output Indicators' AS SubCategoryType,
			 CategoryType = (SELECT DisplayName FROM tblCategoryType WHERE CategoryTypeId=10),
			 Indicators =(Select IndicatorsForOIResult From tblSurvey S
						inner join tblCentre C on S.CentreId=c.CentreId
						inner join tblCentreType CT on C.CentreTypeId=CT.CentreTypeId
						where SurveyId = @SurveyId),
			 
			 SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G   INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=10 and Q.IsGi=1 ) AS TotalPoints ,
			 SUM(S.weightage) AS ObtainedPoints,		
			 CAST(CAST((SUM(S.weightage * 1.0)*100/SUM(IncreaseBy10PercentOrmore *1.0))As NUMERIC(18,2))AS NVARCHAR)+'%' AS Percentage,
			 '' AS MOName,
			 '' AS LeaderName,
			 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)		
			 from tblGiAnswer G 
			 INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
			 INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
			 WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 and  IncreaseBy10PercentOrmore>=0 aND Q.IsGi=1) OI WHERE OI.ObtainedPoints IS NOT NULL

			ORDER BY CategoryType
   END
	END TRY
	BEGIN CATCH	
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Get_GiSurveyResultCategoryWise]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 01/12/2014
-- Description:	To get datatable of  Output Indicator Survey Result 
-- Example: csp_Get_GiSurveyResultCategoryWise 25,10

-- =============================================
CREATE PROC [dbo].[csp_Get_GiSurveyResultCategoryWise]
(
@SurveyId INT,
@CategoryTypeId INT
)
AS
BEGIN						
	BEGIN TRY

          select SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeId ) AS maxscore ,
		   SUM(S.weightage) AS ObtainScore,'QA : 'As CategoryType,
           CAST(CAST((SUM(S.weightage*1.0)*100/(SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeId )))As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent] 
		   from tblGiAnswer G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
           WHERE SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeID and  IncreaseBy10PercentOrmore>=0
           
  UNION
          select SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeId ) AS maxscore ,
		   SUM(S.weightage) AS ObtainScore,'GI : 'As CategoryType,
           CAST(CAST((SUM(S.weightage*1.0)*100/(SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeId )))As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent] 
		   from tblGiAnswer G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
           WHERE SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeID and  IncreaseBy10PercentOrmore>=0 and Q.IsGi='1'
	END TRY
	BEGIN CATCH	
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[csp_Get_GiSurveyResultCategoryWise_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 01/12/2014
-- Description:	To get datatable of  Output Indicator Survey Result 
-- Example: csp_Get_GiSurveyResultCategoryWise_Report 3,10

-- =============================================
CREATE PROC [dbo].[csp_Get_GiSurveyResultCategoryWise_Report]
(
@SurveyId INT
)
AS
BEGIN
	BEGIN TRY
		If((Select C.CentreTypeId from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId where S.SurveyId = @SurveyId) = 3)
     BEGIN
     
	  SELECT SUM(T.MaxScore) as maxscore ,SUM(T.ObtainScore) as ObtainScore,ResultType fROM (SELECT SUM(weightage) AS ObtainScore,
	SUM(maxscore) AS MaxScore,
	'QA' As ResultType
	FROM(SELECT weightage,QuestionId,CategoryTypeId 
	FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=10)TBL1
	INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
	GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
	INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
	INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
	GROUP BY TBL1.CategoryTypeId,CT.CategoryType

	UNION ALL
	
	select SUM(S.weightage) AS ObtainScore, SUM(IncreaseBy10PercentOrmore) + ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId  and S.CategoryTypeId=10 ) AS MaxScore ,
		   'QA'As ResultType
		    from tblGiAnswer G 
    INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
    INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
    WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 AND G.IncreaseBy10PercentOrmore>=0
	

	UNION ALL 
	select SUM(S.weightage) AS ObtainScore, SUM(IncreaseBy10PercentOrmore) + ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=10 ) AS MaxScore ,
	'GI'As ResultType 
	from tblGiAnswer G 
    inner join tblSurveyAnswer S on G.QuestionId=S.QuestionId
    INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
    where S.SurveyId=@SurveyId and S.CategoryTypeId=10 and Q.IsGi='1' AND G.IncreaseBy10PercentOrmore>=0)T
    group by T.ResultType 
	
     END
ELSE
    BEGIN

  select SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=10 ) AS maxscore ,SUM(S.weightage) AS ObtainScore,'QA'As ResultType
           
		   from tblGiAnswer G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
           WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 and  IncreaseBy10PercentOrmore>=0
           
  UNION
          select SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=10 ) AS maxscore ,SUM(S.weightage) AS ObtainScore,'GI'As ResultType
         
		   from tblGiAnswer G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
           WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 and  IncreaseBy10PercentOrmore>=0 and Q.IsGi='1'

   END
	END TRY
	BEGIN CATCH	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Grade]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Mahesh Warambhe
-- Create date: 29/11/2014
-- Description:	To get datatable of Centre 
-- Example: csp_Get_Grade
-- =============================================
CREATE PROC [dbo].[csp_Get_Grade]
(
@Score NUMERIC(18,2)
)
AS
BEGIN	
	select Grade from tblGrade where  MinScore < = @Score AND MaxScore  >= @Score 
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Hierarchy]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [dbo].[csp_Get_Hierarchy]
AS
BEGIN						
	BEGIN TRY
		 SELECT NULL as ParentId,DistrictName as HierarchyName,1 as HierarchyTypeId,DistrictId as RelativeId FROM tblDistrict 
			UNION ALL
		 SELECT DistrictId as ParentId,TalukaName as HierarchyName,2 as HierarchyTypeId, TalukaId as RelativeId  FROM tblTaluka
			UNION ALL
		 SELECT TalukaId as ParentId,Centre as HierarchyName,3 as HierarchyTypeId, CentreId as RelativeId  FROM tblCentre		 
	END TRY
	BEGIN CATCH	
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[csp_Get_HRProfile_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	31/07/2014
-- Description	:	
-- Example		:	csp_Get_SurveyHRProfile_Report
-- ======================================================================

CREATE PROC [dbo].[csp_Get_HRProfile_Report]
	(
		@SurveyId INT
	)
AS
BEGIN
	SELECT 
	Designation,
	PostSanctionedNo,
	RegularNo,
	Contractual,
	Remark 
	FROM tblHRProfile H
	INNER JOIN tblDesignationMaster D ON H.DesignationId=D.DesignationId
	WHERE SurveyId= @SurveyId
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_LatestSurveyDetailsFromServer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Mahesh Warambhe
-- Create date: 29/11/2014
-- Description:	To get datatables of  Data Survey Details From Server
-- Example: csp_Get_LatestSurveyDetailsFromServer 
-- =============================================

CREATE PROC [dbo].[csp_Get_LatestSurveyDetailsFromServer]
(
	@CentreId INT
)

AS
BEGIN	
	BEGIN TRY

	DECLARE @ServerSurveyId int = (SELECT TOP(1)SurveyId FROM tblSurvey WHERE CentreId= @CentreId ORDER BY VisitDate DESC)

	SELECT * FROM tblSurvey WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblDQAG WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblStaffRespondent WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblHRProfile WHERE SurveyId=@ServerSurveyId

    SELECT * FROM tblSkillTrainingStatus WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblSurveyAnswer WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblGiResult WHERE SurveyId =@ServerSurveyId

	SELECT * FROM tblResult WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblRevievRecord WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblActionPlan WHERE SurveyId=@ServerSurveyId

	END TRY
	BEGIN CATCH	
	END CATCH
		
END

GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Module]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Abhinandan Patil
-- Create date: 24/09/2014
-- Description:	To get datatable of Module
-- Example: csp_Get_Module 1
-- =============================================    
CREATE PROC [dbo].[csp_Get_Module] 
(           
	@RoleId INT = NULL         
)
AS            
BEGIN 

	IF EXISTS (SELECT RoleId FROM tblModuleAccess WHERE RoleId=@RoleId)  
	BEGIN
		SELECT 
			MM.ModuleId,
			MM.ModuleName,
			MM.ParentId,
			MM.ModuleTypeId,
			MM.ModuleIdentifyId,
			ISNULL(MA.[View],'true') AS [View], 
			ISNULL(MA.[Add],'true') AS [Add], 
			ISNULL(MA.[Update],'true') AS [Update], 
			ISNULL(MA.[Delete],'true') AS [Delete]			
		FROM tblModuleMaster MM
		LEFT JOIN tblModuleAccess MA ON MA.ModuleId = MM.ModuleId AND MA.RoleId = @RoleId		
	END
	ELSE
	BEGIN
		SELECT    
			ModuleId,
			ModuleName,
			ModuleTypeId,
			ParentId,			
			ModuleIdentifyId,
			CONVERT(bit,'true') AS [View],
			CONVERT(bit,'true') AS [Add],
			CONVERT(bit,'true') AS [Update],
			CONVERT(bit,'true') AS [Delete]           
		FROM tblModuleMaster    
	END
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_NameofMO]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author: Parshwanath Chougule
-- Create date: 19/12/2014
-- Description:	To get datatable of Nameof MO 
-- Example: csp_Get_NameofMO 3,22
-- =============================================
CREATE PROC [dbo].[csp_Get_NameofMO]
(
    @Operation Int, -- 1. Result 2. Gi Result 3.ActionPlan
	@SurveyId INT
)
AS
BEGIN	

	IF(@Operation =1) --1. Result 
		 BEGIN
		IF EXISTS(SELECT ResultId FROM tblResult WHERE SurveyId = @SurveyId AND ResultMOICName IS NULL)
		BEGIN
			SELECT ResultMOICName,GiMOICName,ActionPlanMOICName from tblResult
		WHERE SurveyId in (SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
		(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate desc)
		END
		ELSE
		BEGIN
			SELECT ResultMOICName,GiMOICName,ActionPlanMOICName from tblResult
		WHERE SurveyId = @SurveyId
		END
     END
	IF(@Operation =2) --2. GiResult 
	    BEGIN
		IF EXISTS(SELECT ResultId FROM tblResult WHERE SurveyId = @SurveyId AND GiMOICName IS NULL)
		BEGIN
			SELECT ResultMOICName,GiMOICName,ActionPlanMOICName from tblResult
		WHERE SurveyId in (SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
		(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate desc)
		END
		ELSE
		BEGIN
			SELECT ResultMOICName,GiMOICName,ActionPlanMOICName from tblResult
		WHERE SurveyId = @SurveyId
		END
	END
	IF(@Operation =3) --3. ActionPlan
	    BEGIN
		IF EXISTS(SELECT ResultId FROM tblResult WHERE SurveyId = @SurveyId AND ActionPlanMOICName IS NULL)
		BEGIN
			SELECT ResultMOICName,GiMOICName,ActionPlanMOICName from tblResult
		WHERE SurveyId in (SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
		(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate desc)
		END
		ELSE
		BEGIN
			SELECT ResultMOICName,GiMOICName,ActionPlanMOICName from tblResult
		WHERE SurveyId = @SurveyId
		END
		END
	
END


GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Optinal_SubCategoryType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Yograj Sulakhe
-- Create date: 02/12/2014
-- Description:	To get datatable of SubCateggory 
-- Example: csp_Get_SubCategoryType
-- =============================================
CREATE PROC [dbo].[csp_Get_Optinal_SubCategoryType]
(
@SubCategoryTypeId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT		
		IsOptional 
		FROM tblSubCategoryType 
		WHERE SubCategoryTypeId=@SubCategoryTypeId		
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_PeopleToAttend]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author:Parshwanath Chougule
-- Create date: 02/11/2014
-- Description:	To get datatable of People dropdown
-- Example: [csp_Get_PeopleToAttend_GD_Dropdown] 
-- =============================================
CREATE PROC [dbo].[csp_Get_PeopleToAttend]
(
   @CentreId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT DISTINCT SP.UserId,UM.FirstName + ' ' +UM.LastName AS People FROM tblUserCentreMapping UCM 	
		INNER JOIN tblUserMaster UM ON UM.UserId = UCM.UserId 
		INNER JOIN tblSurveyPeople SP ON UM.UserId=SP.UserId
		INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
	    WHERE SS.CentreId = @CentreId 
	END TRY
	BEGIN CATCH	
	END CATCH
END







GO
/****** Object:  StoredProcedure [dbo].[csp_Get_PeopleToAttend_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author:Parshwanath Chougule
-- Create date: 02/11/2014
-- Description:	To get datatable of People dropdown
-- Example: csp_Get_People_to_attend_Dropdown 
-- =============================================
CREATE PROC [dbo].[csp_Get_PeopleToAttend_Dropdown]
(
   @CentreId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT UCM.UserId,UM.FirstName + ' ' +UM.LastName AS People FROM tblUserCentreMapping UCM 	
		INNER JOIN tblUserMaster UM ON UM.UserId = UCM.UserId WHERE UCM.CentreId = @CentreId
	
			END TRY
	BEGIN CATCH	
	END CATCH
END







GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Qualification]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Abhinandan Patil
-- Create date: 28/11/2014
-- Description:	To get datatable of Qualification
-- Example: csp_Get_Qualification
-- =============================================
CREATE PROC [dbo].[csp_Get_Qualification]
AS
BEGIN						
	BEGIN TRY
		SELECT QualificationId,Qualification,Description FROM tblQualification
	END TRY
	BEGIN CATCH	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Qualification_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Parshwanath Chougule
-- Create date: 01/12/2014
-- Description:	To get datatable of Qualification dropdown
-- Example: csp_Get_Qualification_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_Qualification_Dropdown]
AS
BEGIN						
	BEGIN TRY
		SELECT QualificationId,Qualification FROM tblQualification ORDER BY Qualification
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Question]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Yograj Sulakhe
-- Create date: 04/12/2014
-- Description:	To get datatable of question
-- Example: csp_Get_question
-- =============================================
CREATE PROC [dbo].[csp_Get_Question]
AS
BEGIN						
	BEGIN TRY
		SELECT  
		Q.QuestionId,
		Q.Question, 
		Q.CategoryTypeId,
		Q.CenterTypeId,
		CT.CentreType,
		Q.SubCategoryTyepId,
		C.CategoryType,
		SC.SubCategoryType,
		Q.AnswerTyepId,
		Status = CASE Q.Status WHEN 0 THEN '0'
		                       WHEN 1 THEN '1'
		                        END , 
		IsGi = CASE Q.IsGi   WHEN 0 THEN 'False'
							 WHEN 1 THEN'True'
							 END,
		AT.AnswerType 
		FROM tblQuestion Q  
		INNER JOIN tblCentreType CT ON CT.CentreTypeId=Q.CenterTypeId
		INNER JOIN tblSubCategoryType SC ON SC.SubCategoryTypeId=Q.SubCategoryTyepId
		INNER JOIN tblCategoryType	C ON C.CategoryTypeId=SC.CategoryTypeId
		INNER JOIN tblAnsewerType AT ON AT.AnswerTypeId=Q.AnswerTyepId
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Question_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--=============================================
-- Author: Mahesh Warambhe
-- Create date: 27/11/2014
-- Description:	To get datatable of Taulka
-- Example: csp_Get_Question_Report 25
-- =============================================
CREATE PROC [dbo].[csp_Get_Question_Report]
(
	@SurveyId INT 	
)
AS
BEGIN	
	-- Session A CategaryTypeId = 1

	  SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=1 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=1 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=1)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1 And weightage IS NOT NULL
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=1)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1 And weightage IS NOT NULL
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
					
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=1  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=1 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=1 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=1)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1 And weightage IS NOT NULL
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=1)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1 And weightage IS NOT NULL
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId = 1 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
	) P order by SubCategoryTyepId,QuestionId


	-- Session B CategaryTypeId = 2

	  SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=2 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=2 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=2 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=2 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
					
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId 
	LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=2  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,
					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=2 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=2 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=2 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=2 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId=2 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
		
	) P order by SubCategoryTyepId,QuestionId

	-- Session C CategaryTypeId = 3 

       SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=3 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=3 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=3 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=3 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )						
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId 
	LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=3  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,
					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=3 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=3 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=3 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=3 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId=3 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
		
	) P order by SubCategoryTyepId,QuestionId


	-- Session D CategaryTypeId = 4

	   SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=4 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=4 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=4 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=4 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
					
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId 
	LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=4  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,
					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=4 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=4 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=4 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=4 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId=4 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
		
	) P order by SubCategoryTyepId,QuestionId

	-- Session E CategaryTypeId = 5

	   SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=5 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=5 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=5 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=5 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId 
	LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=5  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,
					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=5 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=5 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=5 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=5 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId=5 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
		
	) P order by SubCategoryTyepId,QuestionId

	-- Session F CategaryTypeId = 6

	   SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=6 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=6 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=6 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=6 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )
					
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId 
	LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=6  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,
					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=6 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=6 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=6 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=6 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId=6 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
		
	) P order by SubCategoryTyepId,QuestionId

	-- Session F CategaryTypeId = 7

	   SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=7)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=7 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=7 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=7)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId 
	LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=7  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,
					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=7)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=7 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=7 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=7)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId=7 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
		
	) P order by SubCategoryTyepId,QuestionId


	-- Session G CategaryTypeId = 8
 
	   SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=8 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=8 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=8 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=8 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )			
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId 
	LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=8  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,
					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=8 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=8 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=8 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=8 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId=8 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
		
	) P order by SubCategoryTyepId,QuestionId

	-- Session I CategaryTypeId = 9

	   SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By Q.QuestionId)) QNo,
		Q.QuestionId,
		Q.CategoryTypeId,
		CategoryType,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId,
		A.weightage,
		Answer = Case ISNULL(AW.Answer, 'NULLVALUE') when 'NULLVALUE'  then 'NA' else AW.Answer End,
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=9 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=9 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=9 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=9 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )
					
	FROM tblSurveyAnswer A
	INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId		
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId 
	LEFt JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
	WHERE A.SurveyId=@SurveyId AND  A.CategoryTypeId=9  AND Q.SubCategoryTyepId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))


	UNION

	SELECT 
		NULL as QNo,
		NULL as QuestionId,
		NULL as CategoryTypeId,
		CategoryType,
		SubCategoryTypeId,
		SubCategoryType  as Question,
		'Sub-elements Instructions: Ask to MO I/C & Fill the following  questions Confirm that services were provided in last three months (verify from record)' as Instructions,
		'' AS AnswerId,			
		'' as weightage,
		'' AS Answer,
					
		QAObtainScore =   (SELECT SUM(weightage)
				FROM(SELECT weightage,QuestionId,CategoryTypeId 
				FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=9 And weightage IS NOT NULL)TBL1
				INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
				GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
				INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
				INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
				GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		QAMaxScore =	(SELECT 
						SUM(maxscore) 
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=9 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIObtainScore =	(SELECT SUM(weightage)
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=9 And weightage IS NOT NULL)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType),
		GIMaxScore	=	(SELECT 
						SUM(maxscore) AS MaxScore
						FROM(SELECT weightage,QuestionId,CategoryTypeId 
						FROM tblSurveyAnswer WHERE SurveyId= @SurveyId AND CategoryTypeId=9 And weightage IS NOT NULL)TBL1
						INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
						GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
						INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
						INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi =1
						GROUP BY TBL1.CategoryTypeId,CT.CategoryType )	
		FROM tblSubCategoryType SC
		inner join tblCategoryType CT on sc.CategoryTypeId=ct.CategoryTypeId
		WHERE SC.CategoryTypeId=9 AND SC.SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=21))
		
		
	) P order by SubCategoryTyepId,QuestionId

	-- Session J CategaryTypeId = 10
	
       SELECT 'Q' + CT.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER By GR.QuestionId)) QNo, GR.QuestionId,
	GR.QuestionId,
	Q.Question,
	ThreeMonthRecordA AS ThreeMonthRecordA,
	ThreeMonthRecordB AS ThreeMonthRecordB,
	Percentage 	,
	Gi.DecreaseBy10PercentOrMore,
	gi.IncreaseBy10PercentOrmore,
	gi.[ScoreRange-10TO+10] As ScoreRange	  
	FROM tblGIResult GR  
	INNER JOIN tblQuestion Q ON GR.QuestionId=Q.QuestionId 
	INNER JOIN tblCategoryType CT ON Q.CategoryTypeId=CT.CategoryTypeId
	inner join tblGiAnswer Gi On q.QuestionId= Gi.QuestionId
	WHERE  SurveyId= @SurveyId and GR.CategoryTypeId = 10

	DECLARE @dtRowCount int =(
								Select Count(*)  
								FROM tblGIResult GR  
								INNER JOIN tblQuestion Q ON GR.QuestionId=Q.QuestionId 
								INNER JOIN tblCategoryType CT ON Q.CategoryTypeId=CT.CategoryTypeId
								inner join tblGiAnswer Gi On q.QuestionId= Gi.QuestionId
								WHERE  SurveyId= @SurveyId and GR.CategoryTypeId = 10
						     )
	-- Session J CategaryTypeId = 10

			DECLARE @GiResult TABLE 
			(
			maxscore INT,
			ObtainScore INT,
			ResultType NVARCHAR(10)
			)

			INSERT INTO @GiResult
			(
			maxscore,
			ObtainScore,
			ResultType
			)
              EXEC csp_Get_GiSurveyResultCategoryWise_Report @SurveyId

	 SELECT 'Q' + CT.Prefix + ' ' + CONVERT(NVARCHAR,@dtRowCount+ROW_NUMBER() OVER (ORDER By RR.QuestionId)) QNo, RR.QuestionId,
	 RR.QuestionId,
	 Q.Question,Q.ReviewRecordNo,
	 RR.LastThreeMonthPerformance AS LastThreeMonthPerformance,
	 Gi.DecreaseBy10PercentOrMore,
	 Gi.IncreaseBy10PercentOrmore,
	 Gi.[ScoreRange-10TO+10] As  ScoreRange,
	 GiMaxScore =(SELECT maxscore FROM @GiResult WHERE ResultType='GI'),
	 GiObtainMaxScore =(SELECT ObtainScore FROM @GiResult WHERE ResultType='GI'),
	 MaxScore =(SELECT maxscore FROM @GiResult WHERE ResultType='QA'),
	 ObtainMaxScore=(SELECT ObtainScore FROM @GiResult WHERE ResultType='QA')
	 FROM   tblRevievRecord RR  
	 INNER JOIN tblQuestion Q ON RR.QuestionId=Q.QuestionId 
	 INNER JOIN tblCategoryType CT ON Q.CategoryTypeId=CT.CategoryTypeId
	 inner join tblGiAnswer Gi On Q.QuestionId= Gi.QuestionId
	 WHERE  SurveyId= @SurveyId and RR.CategoryTypeId = 10

END

GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ReportingManager_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Parshwanath Chougule
-- Create date: 01/12/2014
-- Description:	To get datatable of ReportingManager dropdown
-- Example: csp_Get_ReportingManager_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_ReportingManager_Dropdown]
AS
BEGIN						
	BEGIN TRY
		SELECT UserId AS ReportingManagerId,FirstName + ' ' + LastName AS ReportingManager FROM tblUserMaster ORDER BY ReportingManager
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ReviewRecordSurveyQuestion]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 05/11/2014
-- Description:	To get datatable of Answer Option
-- Example: csp_Get_ReviewRecordSurveyQuestion 3,10
-- =============================================
CREATE PROC [dbo].[csp_Get_ReviewRecordSurveyQuestion]

(

@SurveyId INT,

@CategoryTypeId INT

)
AS

BEGIN						

	BEGIN TRy

	IF EXISTS(SELECT SurveyAnswerId FROM tblSurveyAnswer WHERE SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId)

	BEGIN
	
	 SELECT '' as QNo, 
	 RR.QuestionId,
	 Q.Question,Q.ReviewRecordNo,
	 RR.LastThreeMonthPerformance AS LastThreeMonthPerformance
	 FROM   tblRevievRecord RR  
	 INNER JOIN tblQuestion Q ON RR.QuestionId=Q.QuestionId 
	 INNER JOIN tblCategoryType CT ON Q.CategoryTypeId=CT.CategoryTypeId
	 WHERE  SurveyId=@SurveyId and RR.CategoryTypeId =@CategoryTypeId
	END				

 ELSE

	BEGIN
     
    SELECT  '' as QNo, 
	QuestionId, Question ,'' AS LastThreeMonthPerformance,ReviewRecordNo 
    FROM tblQuestion Q
    INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId
    INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId
	INNER JOIN tblCentre TC ON CT.CentreTypeId = TC.CentreTypeId
	INNER JOIN tblSurvey S ON TC.CentreId=S.CentreId  
    WHERE Q.CategoryTypeId= @CategoryTypeId AND  q.Status ='1' AND ReviewRecordNo IS NOT NULL AND ReviewRecordNo !='1' AND S.SurveyId=@SurveyId
	
	END

	END TRY

	BEGIN CATCH	

	END CATCH

	END










GO
/****** Object:  StoredProcedure [dbo].[csp_Get_ReviewRecordSurveyResult]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 01/12/2014
-- Description:	To get datatable of Review Record Survey Result 
-- Example: csp_Get_ReviewRecordSurveyResult 2,7

-- =============================================
CREATE PROC [dbo].[csp_Get_ReviewRecordSurveyResult]
(
@SurveyId INT,
@CategoryTypeId INT
)
AS
BEGIN						
	BEGIN TRY

	 SELECT SUM(weightage) AS ObtainScore,
	 SUM(maxscore) AS MaxScore,
	 CAST(CAST((SUM(weightage)*100/SUM(maxscore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],CT.CategoryType
	 FROM(SELECT weightage,QuestionId,CategoryTypeId 
	 FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=@CategoryTypeId )TBL1
	 INNER JOIN (SELECT MAX(IncreaseBy10PercentOrmore)AS maxscore,QuestionId FROM tblGiAnswer 
	 GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
	 INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
	 INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi ='0'
	 GROUP BY TBL1.CategoryTypeId,CT.CategoryType
	
	UNION 
	
	SELECT SUM(weightage) AS ObtainScore,
	SUM(maxscore) AS MaxScore,
	CAST(CAST((SUM(weightage)*100/SUM(maxscore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],CT.CategoryType
	FROM(SELECT weightage,QuestionId,CategoryTypeId 
	FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=@CategoryTypeId )TBL1
	INNER JOIN (SELECT MAX(IncreaseBy10PercentOrmore)AS maxscore,QuestionId FROM tblGiAnswer 
	GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
	INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
	INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi ='1'
	GROUP BY TBL1.CategoryTypeId,CT.CategoryType

 
	END TRY
	BEGIN CATCH	
    END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Role]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Parshwanath Chougule
-- Create date: 04/12/2014
-- Description:	To get datatable of Qualification
-- Example: csp_Get_Role
-- =============================================
CREATE PROC [dbo].[csp_Get_Role]
AS
BEGIN						
	BEGIN TRY
		SELECT RoleId,RoleName,Description FROM tblRoleMaster
	END TRY
	BEGIN CATCH	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Role_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Parshwanath Chougule
-- Create date: 01/12/2014
-- Description:	To get datatable of Role dropdown
-- Example: csp_Get_Role_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_Role_Dropdown]
AS
BEGIN						
	BEGIN TRY
		SELECT RoleId,RoleName FROM tblRoleMaster ORDER BY RoleName
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SentSMS]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Abhinandan Patil
-- Create date: 06/11/2014
-- Description:	To get datatable of SMS Queue
-- Example: csp_Get_SentSMS
-- =============================================
CREATE PROC [dbo].[csp_Get_SentSMS]
AS
BEGIN						
	BEGIN TRY
		SELECT SMSQueueId,Response FROM tblSMSQueue WHERE IsSend=1 AND DeliveryStatus='Pending'
	END TRY
	BEGIN CATCH	
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SkillTraining_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	31/07/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Get_SurveySkillTraining_Report
-- ======================================================================

CREATE PROC [dbo].[csp_Get_SkillTraining_Report]
	(
		@SurveyId INT
	)
AS
BEGIN 
	    SELECT 
		StaffName,
		Designation,
		Qualification,	
		Minilap,
		NSV,
		MTP,
		BEMOC,
		EMOC,
		STIRTI,
		IUD,
		LSAS,
		IMEP,
		CTC,
		NSSK,
		RI,
		FIMNCI,
		SBA,
		IYCF,
		Other
		FROM tblSkillTrainingStatus S
		INNER JOIN tblDesignationMaster D ON S.DesignationId=D.DesignationId
		INNER JOIN tblQualification Q ON S.QualificationId=Q.QualificationId
		WHERE SurveyId =@SurveyId
			
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SMSEmailPrivilege]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Abhinandan Patil
-- Create date: 05/11/2014
-- Description:	To get datatable of SMSEmail Privilege
-- Example: csp_Get_SMSeMailPrivilege
-- =============================================
CREATE  PROC [dbo].[csp_Get_SMSEmailPrivilege]
AS
BEGIN						
	BEGIN TRY
		SELECT SMSEmailPrivilegeId,Particular,SMS, Email FROM tblSMSEmailPrivilegeMaster
	END TRY
	BEGIN CATCH	
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SMSQueue]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: YOGRAJ SULAKHE
-- Create date: 06/11/2014
-- Description:	To get datatable of SMS Queue
-- Example: csp_Get_SMSQueue
-- =============================================
CREATE PROC [dbo].[csp_Get_SMSQueue]
AS
BEGIN						
	BEGIN TRY
		
		-- Insert SMS  for Survey Scheduled.
		
		BEGIN
					
			IF EXISTS(SELECT top(1) U.ContactNumber FROM tblUserMaster U 
			   INNER JOIN tblSurveyPeople SP ON U.UserId=SP.UserId
		       INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
		       INNER JOIN tblCentre C ON SS.CentreId=C.CentreId  WHERE SS.SurveyDate > DATEADD(DAY, +1, GETDATE()) AND  SP.SurveyPeopleId  
			   NOT IN ( SELECT SurveyPeopleId from tblSMSQueue where YEAR(GETDATE())=YEAR(SMSDate) AND MONTH(GETDATE())=MONTH(SMSDate)AND DAY(GETDATE())=DAY(SMSDate)))
			
			BEGIN
				DECLARE @Center NVARCHAR(50);
				DECLARE @Surveydate DateTime;
				DECLARE @SurveyStartTime nvarchar(30);
				DECLARE @sms NVARCHAR(max);
				DECLARE @name1 NVARCHAR(100);
				DECLARE @name2 NVARCHAR(100);
				

			   SELECT top(1) @name1=U.FirstName,@name2=U.LastName, @Center=C.Centre,@Surveydate=SS.SurveyDate,@SurveyStartTime=Convert(nvarchar(30),SS.SurveyStartTime,8) FROM tblUserMaster U 
			   INNER JOIN tblSurveyPeople SP ON U.UserId=SP.UserId
		       INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
		       INNER JOIN tblCentre C ON SS.CentreId=C.CentreId  WHERE SS.SurveyDate > DATEADD(DAY, +1, GETDATE()) AND  SP.SurveyPeopleId  
			   NOT IN ( SELECT SurveyPeopleId from tblSMSQueue where YEAR(GETDATE())=YEAR(SMSDate) AND MONTH(GETDATE())=MONTH(SMSDate)AND DAY(GETDATE())=DAY(SMSDate))
			

			 SET @sms = 'Dear '+@name1 +' '+ @name2 +'  survey is scheduled on dated '+ Convert(nvarchar(30),@Surveydate,103)+' at ' + @SurveyStartTime+' for '+@Center+'center.';

				INSERT INTO tblSMSQueue
				(
					SurveyPeopleId,
					ContactNo,
					Subject,
					IsSend,
					SMSDate
				
				)
				VALUES
				(
				  (SELECT top(1) SP.SurveyPeopleId FROM tblUserMaster U 
			   INNER JOIN tblSurveyPeople SP ON U.UserId=SP.UserId
		       INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
		       INNER JOIN tblCentre C ON SS.CentreId=C.CentreId  WHERE SS.SurveyDate > DATEADD(DAY, +1, GETDATE()) AND  SP.SurveyPeopleId  
			   NOT IN ( SELECT SurveyPeopleId from tblSMSQueue where YEAR(GETDATE())=YEAR(SMSDate) AND MONTH(GETDATE())=MONTH(SMSDate)AND DAY(GETDATE())=DAY(SMSDate)))
			,
				  (SELECT top(1) U.ContactNumber FROM tblUserMaster U 
			   INNER JOIN tblSurveyPeople SP ON U.UserId=SP.UserId
		       INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
		       INNER JOIN tblCentre C ON SS.CentreId=C.CentreId  WHERE SS.SurveyDate > DATEADD(DAY, +1, GETDATE()) AND  SP.SurveyPeopleId  
			   NOT IN ( SELECT SurveyPeopleId from tblSMSQueue where YEAR(GETDATE())=YEAR(SMSDate) AND MONTH(GETDATE())=MONTH(SMSDate)AND DAY(GETDATE())=DAY(SMSDate)))
				,
					@sms,
					0,
					GETDate()
				)
			END
							
		
		END
		
		BEGIN
					
			IF EXISTS(SELECT top(1) U.ContactNumber FROM tblUserMaster U 
			   INNER JOIN tblSurveyPeople SP ON U.UserId=SP.UserId
		       INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
		       INNER JOIN tblCentre C ON SS.CentreId=C.CentreId  WHERE SS.SurveyDate > DATEADD(DAY, +1, GETDATE()) AND  SP.SurveyPeopleId  
			   IN ( SELECT SurveyPeopleId from tblSMSQueue where YEAR(GETDATE())=YEAR(SMSDate) AND MONTH(GETDATE())=MONTH(SMSDate)AND DAY(GETDATE())>DAY(SMSDate)))
			
			BEGIN
				DECLARE @Center1 NVARCHAR(50);
				DECLARE @Surveydate1 DateTime;
				DECLARE @SurveyStartTime1 nvarchar(30);
				DECLARE @sms1 NVARCHAR(max);
				DECLARE @name NVARCHAR(100);
				DECLARE @nameL NVARCHAR(100);
				

				SELECT top(1) @name=U.FirstName,@nameL=U.LastName, @Center1=C.Centre,@Surveydate1=SS.SurveyDate,@SurveyStartTime1=Convert(nvarchar(30),SS.SurveyStartTime,8) FROM tblUserMaster U 
			   INNER JOIN tblSurveyPeople SP ON U.UserId=SP.UserId
		       INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
		       INNER JOIN tblCentre C ON SS.CentreId=C.CentreId  WHERE SS.SurveyDate > DATEADD(DAY, +1, GETDATE()) AND  SP.SurveyPeopleId  
			   IN ( SELECT SurveyPeopleId from tblSMSQueue where YEAR(GETDATE())=YEAR(SMSDate) AND MONTH(GETDATE())=MONTH(SMSDate)AND DAY(GETDATE())>DAY(SMSDate))
			

			 SET @sms1 = 'Dear '+@name +' '+ @nameL +'  survey is scheduled on dated '+ Convert(nvarchar(30),@Surveydate1,103)+' at ' + @SurveyStartTime1+' for '+@Center1+'center.';


			 UPDATE tblSMSQueue SET Subject =@sms1,IsSend=0,SMSDate=GETDate(),ContactNo= (SELECT top(1) U.ContactNumber FROM tblUserMaster U 
			   INNER JOIN tblSurveyPeople SP ON U.UserId=SP.UserId
		       INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
		       INNER JOIN tblCentre C ON SS.CentreId=C.CentreId  WHERE SS.SurveyDate > DATEADD(DAY, +1, GETDATE()) AND  SP.SurveyPeopleId  
			   IN ( SELECT SurveyPeopleId from tblSMSQueue where YEAR(GETDATE())=YEAR(SMSDate) AND MONTH(GETDATE())=MONTH(SMSDate)AND DAY(GETDATE())>DAY(SMSDate)))  WHERE tblSMSQueue.SurveyPeopleId=(SELECT top(1) SP.SurveyPeopleId FROM tblUserMaster U 
			   INNER JOIN tblSurveyPeople SP ON U.UserId=SP.UserId
		       INNER JOIN tblSurveySchedule SS ON SP.SurveyScheduleId=SS.SurveyScheduleId
		       INNER JOIN tblCentre C ON SS.CentreId=C.CentreId  WHERE SS.SurveyDate > DATEADD(DAY, +1, GETDATE()) AND  SP.SurveyPeopleId  
			   IN ( SELECT SurveyPeopleId from tblSMSQueue where YEAR(GETDATE())=YEAR(SMSDate) AND MONTH(GETDATE())=MONTH(SMSDate)AND DAY(GETDATE())>DAY(SMSDate)))
			
							
			END
							
		
		END		
		
		SELECT 
		Q.SMSQueueId,
		Q.ContactNo,
		Q.Subject,
		SA.SMSAPIUserId,
		SA.SMSAPIPassword,
		SA.SenderId
		FROM tblSMSQueue Q INNER JOIN tblSMSAuthenticationMaster SA ON SA.SMSAuthenticationId=1
		WHERE Q.ISSend=0


	END TRY
	BEGIN CATCH	
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[csp_Get_StaffDetail_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Mahesh Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Survey General Information 
-- Example: csp_Get_StaffDetail_Report 1
-- =============================================

CREATE PROC [dbo].[csp_Get_StaffDetail_Report]
(
	@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY
	
	--- staff detail
		SELECT
		SR.UserName,			
		Q.Qualification,
		DM.Designation,
		SR.MobNo	
		from tblStaffRespondent SR 
		INNER JOIN tblQualification Q ON SR.QualificationId = Q.QualificationId
		INNER JOIN tblDesignationMaster DM ON SR.DesignationId = DM.DesignationId 
	    WHERE SR.SurveyId = @SurveyId

	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_StaffMemberDetail_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Mahesh Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Survey General Information 
-- Example: csp_Get_DQGAMemberDetail_Report 1
-- =============================================

CREATE PROC [dbo].[csp_Get_StaffMemberDetail_Report]
(
	@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY
	-- DQGA member
		Select 
		UM.FirstName+' '+UM.LastName AS PeopleName,
		Q.Qualification,
		DM.Designation,		
		UM.ContactNumber		
		from tblDQAG D
		INNER JOIN tblUserMaster UM ON D.UserId = UM.UserId
		INNER JOIN tblQualification Q ON UM.QualificationId = Q.QualificationId
		INNER JOIN tblDesignationMaster DM ON UM.DesignationId = DM.DesignationId 
	    WHERE D.SurveyId = @SurveyId 

	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Staffrespondents]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of DQAGMembersTeam 
-- Example: csp_Get_Staffrespondents 9
-- =============================================
CREATE PROC [dbo].[csp_Get_Staffrespondents]
(
	@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY
	IF EXISTS (SELECT SurveyId FROM tblStaffRespondent WHERE SurveyId = @SurveyId)
		BEGIN
			SELECT 
			SR.DesignationId,
			SR.QualificationId,
			SR.UserName,
			DM.Designation,
			Q.Qualification,
			SR.MobNo 
			from tblStaffRespondent SR 
			INNER JOIN tblQualification Q ON SR.QualificationId = Q.QualificationId
			INNER JOIN tblDesignationMaster DM ON SR.DesignationId = DM.DesignationId 
			WHERE SR.SurveyId = @SurveyId
		END
	ELSE
		BEGIN
			
			SELECT 
			SR.DesignationId,
			SR.QualificationId,
			SR.UserName,
			DM.Designation,
			Q.Qualification,
			SR.MobNo 
			from 
			tblStaffRespondent SR
			INNER JOIN tblQualification Q ON SR.QualificationId = Q.QualificationId
			INNER JOIN tblDesignationMaster DM ON SR.DesignationId = DM.DesignationId 
			WHERE SR.SurveyId IN   
					( select Top(1)SurveyId from tblSurvey WHERE CentreId IN 
					(select CentreId from tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER By VisitDate DESC)

		END
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SubCategoryType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Yograj Sulakhe
-- Create date: 02/12/2014
-- Description:	To get datatable of SubCateggory 
-- Example: csp_Get_SubCategoryType
-- =============================================
CREATE PROC [dbo].[csp_Get_SubCategoryType]
AS
BEGIN						
	BEGIN TRY
		SELECT 
		SC.SubCategoryTypeId,
		SC.CategoryTypeId,
		C.CategoryType,
		SC.SubCategoryType,
		SC.Description,
		IsOptional = Case IsOptional when 0 then 'No' when 1 then 'Yes' end
		FROM tblSubCategoryType SC
		INNER JOIN tblCategoryType C ON C.CategoryTypeId= SC.CategoryTypeId ORDER BY SubCategoryTypeId DESC		
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SubCategoryType_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 02/11/2014
-- Description:	To get datatable of CategoryType dropdown
-- Example: csp_Get_District_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_SubCategoryType_Dropdown]
(
@CategoryTypeId INT
)
AS
BEGIN						
	BEGIN TRY
			SELECT SubCategoryTypeId,SubCategoryType FROM tblSubCategoryType  WHERE CategoryTypeId=@CategoryTypeId
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Survey_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Survey Dropdown 
-- Example: [csp_Get_Survey_Dropdown]
-- =============================================
CREATE PROC [dbo].[csp_Get_Survey_Dropdown]
(
@CentreId INT,
@UserId INT = NULL,
@RoleId INT = NULL
)
AS
BEGIN						
	BEGIN TRY	
	IF(@RoleId<>0)	
		BEGIN			
			SELECT 
			SurveyId,
			CONVERT(varchar(12),VisitDate,103) AS VisitDate
			FROM tblSurvey S
			WHERE SurveyId IN (SELECT SurveyId FROM tblSurvey 
			INNER JOIN tblUserCentreMapping U ON S.CentreId=U.CentreId
			WHERE S.CentreId = @CentreId AND U.UserId = @UserId) 
			ORDER BY VisitDate DESC
		END
	ELSE
		BEGIN
		SELECT 
			SurveyId,
			CONVERT(varchar(12),VisitDate,103) AS VisitDate
			FROM tblSurvey S
			WHERE SurveyId IN (SELECT SurveyId FROM tblSurvey 
			INNER JOIN tblUserCentreMapping U ON S.CentreId=U.CentreId
			WHERE S.CentreId = @CentreId) 
			ORDER BY VisitDate DESC
		END
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Survey_GeneralInformation]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Survey General Information 
-- Example: csp_Get_Survey_GeneralInformation 1
-- =============================================

CREATE PROC [dbo].[csp_Get_Survey_GeneralInformation]
(

	@roleId int =null,
   @userId int =null
)
AS
BEGIN	
	IF(@roleId<>0)	
		BEGIN							
			BEGIN TRY
				SELECT 
			S.SurveyId,
			D.DistrictId,
			D.DistrictName,
			C.TalukaId,
			T.TalukaName,
			S.CentreId,
			S.NameofMO,
			S.MobNoofMO,
			S.Email,
			C.Centre,
			S.TelephoneNo,
			S.VisitDate,
			S.VisitRound,
			S.PreviousVisitDate,
			S.PreviousVisitScore,
			S.SubCentresNo,
			S.PopulationCovered,
			S.IPHSStatus,
			S.[247Status],
			S.DeliveryPoint,
			S.Distance,
			S.VisitStartTime,
			S.VisitEndTime,
			S.TotalTime,
			Status =  CASE  IsComplete  WHEN 0 THEN 'WIP' WHEN 1 THEN 'Completed' END,
			IsComplete = CASE  IsComplete  WHEN 0 THEN '0' WHEN 1 THEN '1' END
		FROM tblSurvey S
		INNER JOIN tblCentre C ON C.CentreId = S.CentreId
		INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
		INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
		WHERE T.DistrictId 
			IN (SELECT DistrictId FROM tblTaluka  WHERE TalukaId 
			IN (SELECT TalukaId FROM tblCentre WHERE CentreId 
			IN (SELECT CentreId FROM tblUserCentreMapping WHERE UserId = @userId)))
		ORDER BY S.SurveyId DESC
			END TRY
			BEGIN CATCH	
			END CATCH
	END
	ELSE
	BEGIN							
			BEGIN TRY
				SELECT 
			S.SurveyId,
			D.DistrictId,
			D.DistrictName,
			C.TalukaId,
			T.TalukaName,
			S.CentreId,
			S.NameofMO,
			S.MobNoofMO,
			S.Email,
			C.Centre,
			S.TelephoneNo,
			S.VisitDate,
			S.VisitRound,
			S.PreviousVisitDate,
			S.PreviousVisitScore,
			S.SubCentresNo,
			S.PopulationCovered,
			S.IPHSStatus,
			S.[247Status],
			S.DeliveryPoint,
			S.Distance,
			S.VisitStartTime,
			S.VisitEndTime,
			S.TotalTime,
			Status =  CASE  IsComplete  WHEN 0 THEN 'WIP' WHEN 1 THEN 'Completed' END,
			IsComplete = CASE  IsComplete  WHEN 0 THEN '0' WHEN 1 THEN '1' END
		FROM tblSurvey S
		INNER JOIN tblCentre C ON C.CentreId = S.CentreId
		INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
		INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
		ORDER BY S.SurveyId DESC
			END TRY
			BEGIN CATCH	
			END CATCH
	END
		
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyActionPlan]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Ajay Birari
-- Create date	:	31/07/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Get_SurveyActionPlan  8
-- ======================================================================


CREATE PROC [dbo].[csp_Get_SurveyActionPlan]
	(
		@SurveyId INT=NULL
	)
AS
		BEGIN
		    IF EXISTS(SELECT SurveyId FROM tblActionPlan WHERE SurveyId =@SurveyId)
				BEGIN
					Select					
					C.CategoryTypeId,
				    S.SubCategoryTypeId,
					' General Facility Readiness' AS CategoryType,
					C.DisplayName AS SubCategoryType,
					[Problem],
					[Solution],
					[PHCLevel],
					convert(nvarchar(10),DueDate,103) as DueDate,
					[DistrictLevel],
					[StateLevel],
					[ResponsiblePerson],
					MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
		            LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
					A.ActionPlanId
					from tblActionPlan A
					INNER join tblCategoryType C on A.CategoryTypeId = C.CategoryTypeId
					INNER join tblSubCategoryType S ON A.SubCategoryTypeId = S.SubCategoryTypeId
					where C.CategoryTypeId < 7 AND SurveyId=@SurveyId

					union

					Select					
						C.CategoryTypeId,
						S.SubCategoryTypeId,
						CategoryType,
						s.DisplayName AS SubCategoryType,
						[Problem],
					[Solution],
					[PHCLevel],
					convert(nvarchar(10),DueDate,103) as DueDate,
					[DistrictLevel],
					[StateLevel],
					[ResponsiblePerson],
					MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
		         	LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
					A.ActionPlanId
					from tblActionPlan A
					INNER join tblCategoryType C on A.CategoryTypeId = C.CategoryTypeId
					INNER join tblSubCategoryType S ON A.SubCategoryTypeId = S.SubCategoryTypeId
					WHERE C.CategoryTypeId >6 and SurveyId=@SurveyId

				END
			ELSE
				BEGIN

				Select
					C.CategoryTypeId,
					S.SubCategoryTypeId ,
					' General Facility Readiness' AS CategoryType,
					C.DisplayName AS SubCategoryType,
					[Problem],
					[Solution],
					[PHCLevel],
					convert(nvarchar(10),DueDate,103) as DueDate,
					[DistrictLevel],
					[StateLevel],
					[ResponsiblePerson] ,
					MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
			        LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId) ,
					A.ActionPlanId					
					from tblActionPlan A
					INNER join tblCategoryType C on A.CategoryTypeId = C.CategoryTypeId
					INNER join tblSubCategoryType S ON A.SubCategoryTypeId = S.SubCategoryTypeId
					where C.CategoryTypeId < 7 AND A.SurveyId IN   
					( SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
					(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate DESC)
   
					union

					Select				
						C.CategoryTypeId,
						S.SubCategoryTypeId,
						CategoryType,
						s.DisplayName AS SubCategoryType,
						[Problem],
					[Solution],
					[PHCLevel],
					convert(nvarchar(10),DueDate,103) as DueDate,
					[DistrictLevel],
					[StateLevel],
					[ResponsiblePerson],
					MOName =(SELECT GiMOICName from tblResult	WHERE SurveyId=@SurveyId),				
			        LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.GiQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
					A.ActionPlanId 
					from tblActionPlan A
					INNER join tblCategoryType C on A.CategoryTypeId = C.CategoryTypeId
					INNER join tblSubCategoryType S ON A.SubCategoryTypeId = S.SubCategoryTypeId
					WHERE C.CategoryTypeId >6 	AND A.SurveyId IN   
					( SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
					(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate DESC)
   

				END
		END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyAnswerOption]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 05/11/2014
-- Description:	To get datatable of SurveyAnswer Option
-- Example: csp_Get_SurveyAnswerOption
-- =============================================
CREATE PROC [dbo].[csp_Get_SurveyAnswerOption]
(
@QuestionId INT
)
AS
BEGIN						
	BEGIN TRy
		select Answer,AnswerId FROM tblAnswer WHERE QuestionId=@QuestionId 
		END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyDetailsFromLocalMachine]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==============================================
-- Author: Mahesh Warambhe
-- Create date: 29/11/2014
-- Description:	To get datatables of  Data Survey Details From Server
-- Example: csp_Get_SurveyDetailsFromLocalMachine 
-- =============================================

CREATE PROC [dbo].[csp_Get_SurveyDetailsFromLocalMachine]
(
	@SurveyId INT
)

AS
BEGIN	
	BEGIN TRY

		SELECT * FROM tblSurvey WHERE SurveyId=@SurveyId

		SELECT * FROM tblDQAG WHERE SurveyId=@SurveyId

		SELECT * FROM tblStaffRespondent WHERE SurveyId=@SurveyId

		SELECT * FROM tblHRProfile WHERE SurveyId=@SurveyId

		SELECT * FROM tblSkillTrainingStatus WHERE SurveyId=@SurveyId

		SELECT * FROM tblSurveyAnswer WHERE SurveyId=@SurveyId

		SELECT * FROM tblGiResult WHERE SurveyId =@SurveyId

		SELECT * FROM tblResult WHERE SurveyId=@SurveyId

		SELECT * FROM tblRevievRecord WHERE SurveyId=@SurveyId

	    SELECT * FROM tblActionPlan WHERE SurveyId=@SurveyId

	END TRY
	BEGIN CATCH	
	END CATCH
		
END

GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyHRProfile]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	31/07/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Get_SurveyHRProfile 1
-- ======================================================================

CREATE PROC [dbo].[csp_Get_SurveyHRProfile]
	(
		@SurveyId INT
	)
AS
BEGIN

   IF  EXISTS( SELECT HRProfileId FROM tblHRProfile WHERE SurveyId= @SurveyId)
    BEGIN
		SELECT 
		DesignationId,
		PostSanctionedNo,
		RegularNo,
		Contractual,
		Remark 
		FROM tblHRProfile WHERE SurveyId= @SurveyId
	END
   ELSE
    BEGIN
	    SELECT 
		SurveyId,
		DesignationId,
		PostSanctionedNo,
		RegularNo,
		Contractual,
		Remark 
		FROM tblHRProfile WHERE SurveyId IN   
					( SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
					(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate DESC)
    END
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyQuestion]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================

-- Author:	Yograj Sulakhe

-- Create date: 05/11/2014

-- Description:	To get datatable of Answer Option

-- Example: csp_Get_SurveyQuestion 14,1

-- =============================================
CREATE PROC [dbo].[csp_Get_SurveyQuestion]
(
	@SurveyId INT,
	@CategoryTypeId INT
)
AS
BEGIN
	BEGIN TRY
	IF EXISTS(SELECT SurveyAnswerId FROM tblSurveyAnswer WHERE SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId)
	BEGIN		
	    SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER BY Q.QuestionId)) QNo,
		A.QuestionId,
		Q.CategoryTypeId,
		SubCategoryTyepId,		
		Q.Question,
		C.Instructions,
		A.AnswerId 
		FROM tblSurveyAnswer A
		INNER JOIN tblQuestion Q ON Q.QuestionId=A.QuestionId
		INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId
		INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId
		LEFT JOIN tblAnswer AW ON AW.AnswerId=A.AnswerId
		WHERE A.SurveyId= @SurveyId  AND  A.CategoryTypeId=@CategoryTypeId

		UNION

		SELECT 
			NULL AS QNo,
			NULL AS QuestionId,
			NULL AS CategoryTypeId,
			SubCategoryTypeId,
			'<div style=''background:#C0C0C0;margin:-3px -3px;text-align:center''><b>' + SubCategoryType + '</b></div>' AS Question,
			NULL AS Instructions,
			'0' AS AnswerId 
		FROM tblSubCategoryType WHERE CategoryTypeId=@CategoryTypeId AND SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))
	) P ORDER BY SubCategoryTyepId,QuestionId

	END	
	ELSE
	BEGIN
	SELECT * FROM (SELECT 
		'Q' + C.Prefix + ' ' + CONVERT(NVARCHAR,ROW_NUMBER() OVER (ORDER BY QuestionId)) QNo,
		QuestionId,
		Q.CategoryTypeId,
		SubCategoryTyepId,
		Question,
		C.Instructions
		
	FROM tblQuestion Q
	INNER JOIN tblCentreType CT ON Q.CenterTypeId=CT.CentreTypeId
	INNER JOIN tblCategoryType C ON C.CategoryTypeId=Q.CategoryTypeId
	INNER JOIN tblCentre TC ON CT.CentreTypeId = TC.CentreTypeId
	INNER JOIN tblSurvey S ON TC.CentreId=S.CentreId 
	WHERE  Q.CategoryTypeId=@CategoryTypeId AND  Q.Status=1 AND ReviewRecordNo IS NULL AND S.SurveyId=@SurveyId

	UNION

	SELECT 
	NULL AS QNo,
	NULL AS QuestionId,
	NULL AS CategoryTypeId,
	SubCategoryTypeId,
	
	'<div style=''background:#C0C0C0;margin:-3px -3px;text-align:center''><b>' + SubCategoryType + '</b></div>' AS Question,
	NULL AS Instructions 
	FROM tblSubCategoryType WHERE CategoryTypeId=@CategoryTypeId AND SubCategoryTypeId IN (SELECT DISTINCT(SubCategoryTyepId) FROM tblQuestion WHERE CenterTypeId IN (SELECT C.CentreTypeId FROM tblSurvey S INNER JOIN tblCentre C ON S.CentreId=C.CentreId WHERE S.SurveyId=@SurveyId))
	) P ORDER BY SubCategoryTyepId,QuestionId

	END

	END TRY

	BEGIN CATCH	

	END CATCH

	END


	










GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyResult]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Mahesh Warambhe
-- Create date: 01/12/2014
-- Description:	To get datatable of SurveyResult 
-- Example: csp_Get_SurveyResult 3
-- =============================================
CREATE PROC [dbo].[csp_Get_SurveyResult]
(
@SurveyId INT
)
AS
BEGIN						
	BEGIN TRY
		If((Select C.CentreTypeId from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId where S.SurveyId = @SurveyId) = 3)
   BEGIN
     SELECT
			CategoryTypeId = '0',
			' General Facility Readiness' AS CategoryType, 
			DisplayName AS SubCategoryType,
			C.Indicators,
			tb1.Maxpoint AS TotalPoints,
			tb2.Weightage AS ObtainedPoints,
		    CAST(CAST((tb2.Weightage * 100/ (tb1.Maxpoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage
			FROM 
			(Select SUM(A.MaxWeight)As MaxPoint,CategoryTypeId from (Select MAX(A.weightage)As MaxWeight,Q.QuestionId,Q.SubCategoryTyepId,Q.CategoryTypeId from tblAnswer A
				inner join tblQuestion Q on A.QuestionId = Q.QuestionId
				inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
				where Q.CategoryTypeId < 7 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
				group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
			) A
				group by CategoryTypeId) tb1

			inner join  

			(SELECT SA.CategoryTypeId,SurveyId,SUM(weightage)AS Weightage 
			FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId=Q.QuestionId 
			WHERE SA.CategoryTypeId < 7 AND SA.weightage IS NOT NULL  
			GROUP BY SA.CategoryTypeId,SurveyId) tb2 on tb1.CategoryTypeId=tb2.CategoryTypeId
			inner join tblCategoryType C ON TB1.CategoryTypeId = C.CategoryTypeId
			WHERE SurveyId= @SurveyId


			UNION

			SELECT
			CT.CategoryTypeId,
			CT.DisplayName AS CategoryType,
			SC.DisplayName AS SubCategoryType,
			SC.Indicators,
			TotalMaxPoint AS TotalPoints,
			Weightage AS ObtainedPoints,			
			 CAST(CAST((Weightage * 100/ (TotalMaxPoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage
			FROM (Select 
					SUM(A.MaxWeight)As TotalMaxPoint,
					CategoryTypeId,
					SubCategoryTyepId 
					from 
					(Select 
						MAX(A.weightage)As MaxWeight,
						Q.QuestionId,
						Q.SubCategoryTyepId,
						Q.CategoryTypeId 
						from tblAnswer A
						inner join tblQuestion Q on A.QuestionId = Q.QuestionId
						inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
						where Q.CategoryTypeId between 7 and 9 And SurveyId=@SurveyId
						group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
					) A
				group by SubCategoryTyepId,CategoryTypeId
				) tb1

			inner join 

			(SELECT SUM(SA.weightage) AS Weightage, Q.CategoryTypeId,q.SubCategoryTyepId,SurveyId FROM tblSurveyAnswer SA
			inner join (SELECT QuestionId,CategoryTypeId,SubCategoryTyepId FROM tblQuestion
						  ) Q on SA.QuestionId=Q.QuestionId
					WHERE Q.CategoryTypeId between 7 AND 9 AND SA.weightage IS NOT NULL
			GROUP BY Q.SubCategoryTyepId,Q.CategoryTypeId,SurveyId) tb2 on tb1.SubCategoryTyepId =tb2.SubCategoryTyepId

			inner join tblSubCategoryType SC ON TB1.SubCategoryTyepId=SC.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON TB2.CategoryTypeId=CT.CategoryTypeId
			WHERE SurveyId=@SurveyId 


			UNION	

			Select * from (
			   SELECT 
			    CategoryType1='10',
				'Output Indicators' AS SubCategoryType,
				CategoryType = (SELECT DisplayName FROM tblCategoryType WHERE CategoryTypeId=10),
				 Indicators =(Select IndicatorsForOIResult From tblSurvey S
						inner join tblCentre C on S.CentreId=c.CentreId
						inner join tblCentreType CT on C.CentreTypeId=CT.CentreTypeId
						where SurveyId = @SurveyId),				
				SUM(T.MaxScore) as TotalPoints ,
				SUM(T.ObtainScore) as ObtainedPoints,
				CAST(CAST(SUM(T.ObtainScore  * 1.0)*100/SUM(T.MaxScore)AS NUMERIC(18,2))AS NVARCHAR) +'%'  AS Percentage			
					fROM (SELECT SUM(weightage) AS ObtainScore,
					SUM(maxscore) AS MaxScore,
					CAST(CAST((SUM(weightage  * 1.0)*100/SUM(maxscore)*1.0)AS NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA :' As CategoryType
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=10)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType

					UNION ALL
	
					select SUM(S.weightage) AS ObtainScore, SUM(IncreaseBy10PercentOrmore) + ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
						   INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
						   INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId  and S.CategoryTypeId=10 ) AS MaxScore ,
					CAST(CAST((SUM(S.weightage)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA : 'As CategoryType from tblGiAnswer G 
					INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
					INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
					WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 AND G.IncreaseBy10PercentOrmore>=0
					) T group by T.CategoryType ) OI Where OI.ObtainedPoints IS NOT NULL
			 
		ORDER BY CategoryType
   END
ELSE
   BEGIN
	 SELECT
			CategoryTypeId = '0',
			' General Facility Readiness' AS CategoryType, 
			DisplayName AS SubCategoryType,
			C.Indicators,
			tb1.Maxpoint AS TotalPoints,
			tb2.Weightage AS ObtainedPoints,
		    CAST(CAST((tb2.Weightage * 100/ (tb1.Maxpoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage
			FROM 
			(Select SUM(A.MaxWeight)As MaxPoint,CategoryTypeId from (Select MAX(A.weightage)As MaxWeight,Q.QuestionId,Q.SubCategoryTyepId,Q.CategoryTypeId from tblAnswer A
				inner join tblQuestion Q on A.QuestionId = Q.QuestionId
				inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
				where Q.CategoryTypeId < 7 And SurveyId=@SurveyId  AND SA.weightage IS NOT NULL
				group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
			) A
				group by CategoryTypeId) tb1

			inner join  

			(SELECT SA.CategoryTypeId,SurveyId,SUM(weightage)AS Weightage 
			FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId=Q.QuestionId 
			WHERE SA.CategoryTypeId < 7  AND SA.weightage IS NOT NULL
			GROUP BY SA.CategoryTypeId,SurveyId) tb2 on tb1.CategoryTypeId=tb2.CategoryTypeId
			inner join tblCategoryType C ON TB1.CategoryTypeId = C.CategoryTypeId
			WHERE SurveyId= @SurveyId


			UNION

			SELECT
			CT.CategoryTypeId,
			CT.DisplayName AS CategoryType,
			SC.DisplayName AS SubCategoryType,
			SC.Indicators,
			TotalMaxPoint AS TotalPoints,
			Weightage AS ObtainedPoints,			
			 CAST(CAST((Weightage * 100/ (TotalMaxPoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage
			FROM (Select 
					SUM(A.MaxWeight)As TotalMaxPoint,
					CategoryTypeId,
					SubCategoryTyepId 
					from 
					(Select 
						MAX(A.weightage)As MaxWeight,
						Q.QuestionId,
						Q.SubCategoryTyepId,
						Q.CategoryTypeId 
						from tblAnswer A
						inner join tblQuestion Q on A.QuestionId = Q.QuestionId
						inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
						where Q.CategoryTypeId between 7 and 9 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
						group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
					) A
				group by SubCategoryTyepId,CategoryTypeId
				) tb1

			inner join 

			(SELECT SUM(SA.weightage) AS Weightage, Q.CategoryTypeId,q.SubCategoryTyepId,SurveyId FROM tblSurveyAnswer SA
			inner join (SELECT QuestionId,CategoryTypeId,SubCategoryTyepId FROM tblQuestion
						  ) Q on SA.QuestionId=Q.QuestionId
					WHERE Q.CategoryTypeId between 7 AND 9  AND SA.weightage IS NOT NULL
			GROUP BY Q.SubCategoryTyepId,Q.CategoryTypeId,SurveyId) tb2 on tb1.SubCategoryTyepId =tb2.SubCategoryTyepId

			inner join tblSubCategoryType SC ON TB1.SubCategoryTyepId=SC.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON TB2.CategoryTypeId=CT.CategoryTypeId
			WHERE SurveyId=@SurveyId 


			UNION	


			 Select * from (select  
			 CategoryType1='10',
			 'Output Indicators' AS SubCategoryType,
			 CategoryType = (SELECT DisplayName FROM tblCategoryType WHERE CategoryTypeId=10),
			 Indicators =(Select IndicatorsForOIResult From tblSurvey S
						inner join tblCentre C on S.CentreId=c.CentreId
						inner join tblCentreType CT on C.CentreTypeId=CT.CentreTypeId
						where SurveyId = @SurveyId),			
			 SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G   INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=10 ) AS TotalPoints ,
			 SUM(S.weightage) AS ObtainedPoints,		
			 CAST(CAST((SUM(S.weightage * 1.0)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As DECIMAL(18,2))AS NVARCHAR)+'%' AS Percentage
			 from tblGiAnswer G 
			 INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
			 INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
			 WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 and  IncreaseBy10PercentOrmore>=0) OI Where OI.ObtainedPoints IS NOT NULL

			ORDER BY CategoryType
   END
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyResult_Report]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Mahesh Warambhe
-- Create date: 01/12/2014
-- Description:	To get datatable of SurveyResult 
-- Example: csp_Get_SurveyResult_Report 1
-- =============================================
CREATE PROC [dbo].[csp_Get_SurveyResult_Report]
(
@SurveyId INT
)
AS
BEGIN						
		If((Select C.CentreTypeId from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId where S.SurveyId = @SurveyId) = 3)
   BEGIN
    SELECT
			CategoryTypeId = '0',
			' General Facility Readiness' AS CategoryType, 
			DisplayName AS SubCategoryType,
			C.Indicators,
			tb1.Maxpoint AS TotalPoints,
			tb2.Weightage AS ObtainedPoints,
		    CAST(CAST((tb2.Weightage * 100/ (tb1.Maxpoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage,
			MOName =(SELECT ResultMOICName from tblResult 
					WHERE SurveyId=@SurveyId),
			LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.ResultQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
			'SC' as CentreType
			FROM 
			(Select SUM(A.MaxWeight)As MaxPoint,CategoryTypeId from (Select MAX(A.weightage)As MaxWeight,Q.QuestionId,Q.SubCategoryTyepId,Q.CategoryTypeId from tblAnswer A
				inner join tblQuestion Q on A.QuestionId = Q.QuestionId
				inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
				where Q.CategoryTypeId < 7 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
				group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
			) A
				group by CategoryTypeId) tb1

			inner join  

			(SELECT SA.CategoryTypeId,SurveyId,SUM(weightage)AS Weightage 
			FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId=Q.QuestionId 
			WHERE SA.CategoryTypeId < 7  AND SA.weightage IS NOT NULL
			GROUP BY SA.CategoryTypeId,SurveyId) tb2 on tb1.CategoryTypeId=tb2.CategoryTypeId
			inner join tblCategoryType C ON TB1.CategoryTypeId = C.CategoryTypeId
			WHERE SurveyId= @SurveyId


			UNION

			SELECT
			CT.CategoryTypeId,
			CT.DisplayName AS CategoryType,
			SC.DisplayName AS SubCategoryType,
			SC.Indicators,
			TotalMaxPoint AS TotalPoints,
			Weightage AS ObtainedPoints,			
			 CAST(CAST((Weightage * 100/ (TotalMaxPoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage,
			  '' AS MOName,
			 '' AS LeaderName,
			 'SC' as CentreType
			FROM (Select 
					SUM(A.MaxWeight)As TotalMaxPoint,
					CategoryTypeId,
					SubCategoryTyepId 
					from 
					(Select 
						MAX(A.weightage)As MaxWeight,
						Q.QuestionId,
						Q.SubCategoryTyepId,
						Q.CategoryTypeId 
						from tblAnswer A
						inner join tblQuestion Q on A.QuestionId = Q.QuestionId
						inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
						where Q.CategoryTypeId between 7 and 9 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
						group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
					) A
				group by SubCategoryTyepId,CategoryTypeId
				) tb1

			inner join 

			(SELECT SUM(SA.weightage) AS Weightage, Q.CategoryTypeId,q.SubCategoryTyepId,SurveyId FROM tblSurveyAnswer SA
			inner join (SELECT QuestionId,CategoryTypeId,SubCategoryTyepId FROM tblQuestion
						  ) Q on SA.QuestionId=Q.QuestionId
					WHERE Q.CategoryTypeId between 7 AND 9 AND SA.weightage IS NOT NULL
			GROUP BY Q.SubCategoryTyepId,Q.CategoryTypeId,SurveyId) tb2 on tb1.SubCategoryTyepId =tb2.SubCategoryTyepId

			inner join tblSubCategoryType SC ON TB1.SubCategoryTyepId=SC.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON TB2.CategoryTypeId=CT.CategoryTypeId
			WHERE SurveyId=@SurveyId 


			UNION	

				Select * from (
			   SELECT 
			    CategoryType1='10',
				'Output Indicators' AS SubCategoryType,
			 	CategoryType = (SELECT DisplayName FROM tblCategoryType WHERE CategoryTypeId=10),
				 Indicators =(Select IndicatorsForOIResult From tblSurvey S
						inner join tblCentre C on S.CentreId=c.CentreId
						inner join tblCentreType CT on C.CentreTypeId=CT.CentreTypeId
						where SurveyId = @SurveyId),				
				SUM(T.MaxScore) as TotalPoints ,
				SUM(T.ObtainScore) as ObtainedPoints,
				CAST(CAST(SUM(T.ObtainScore * 1.0)*100/SUM(T.MaxScore)AS NUMERIC(18,2))AS NVARCHAR) +'%'  AS Percentage,
				 '' AS MOName,
			     '' AS LeaderName,
				 'SC' as CentreType			
					fROM (SELECT SUM(weightage) AS ObtainScore,
					SUM(maxscore) AS MaxScore,
					CAST(CAST((SUM(weightage * 1.0)*100/SUM(maxscore)*1.0)AS NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA :' As CategoryType
					FROM(SELECT weightage,QuestionId,CategoryTypeId 
					FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=10)TBL1
					INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
					GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
					INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
					INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
					GROUP BY TBL1.CategoryTypeId,CT.CategoryType

					UNION ALL
	
					select SUM(S.weightage) AS ObtainScore, SUM(IncreaseBy10PercentOrmore) + ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
						   INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
						   INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId  and S.CategoryTypeId=10 ) AS MaxScore ,
					CAST(CAST((SUM(S.weightage * 1.0)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA : 'As CategoryType from tblGiAnswer G 
					INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
					INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
					WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 AND G.IncreaseBy10PercentOrmore>=0
						) T group by T.CategoryType ) OI Where OI.ObtainedPoints IS NOT NULL
			 
		ORDER BY CategoryType
   END
ELSE
   BEGIN
		SELECT
			CategoryTypeId = '0',
			' General Facility Readiness' AS CategoryType, 
			DisplayName AS SubCategoryType,
			C.Indicators,
			tb1.Maxpoint AS TotalPoints,
			tb2.Weightage AS ObtainedPoints,
		    CAST(CAST((tb2.Weightage * 100/ (tb1.Maxpoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage,
			MOName =(SELECT ResultMOICName from tblResult 
					WHERE SurveyId=@SurveyId),
			LeaderName =(SELECT U.FirstName +' '+U.LastName from tblResult R
					INNER JOIN tblUserMaster U ON R.ResultQATeamLeaderId = U.UserId WHERE SurveyId=@SurveyId),
			CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)			
			FROM 
			(Select SUM(A.MaxWeight)As MaxPoint,CategoryTypeId from (Select MAX(A.weightage)As MaxWeight,Q.QuestionId,Q.SubCategoryTyepId,Q.CategoryTypeId from tblAnswer A
				inner join tblQuestion Q on A.QuestionId = Q.QuestionId
				inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
				where Q.CategoryTypeId < 7 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
				group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
			) A
				group by CategoryTypeId) tb1

			inner join  

			(SELECT SA.CategoryTypeId,SurveyId,SUM(weightage)AS Weightage 
			FROM tblSurveyAnswer SA
			INNER JOIN tblQuestion Q ON SA.QuestionId=Q.QuestionId 
			WHERE SA.CategoryTypeId < 7  AND SA.weightage IS NOT NULL
			GROUP BY SA.CategoryTypeId,SurveyId) tb2 on tb1.CategoryTypeId=tb2.CategoryTypeId
			inner join tblCategoryType C ON TB1.CategoryTypeId = C.CategoryTypeId
			WHERE SurveyId= @SurveyId


			UNION

			SELECT
			CT.CategoryTypeId,
			CT.DisplayName AS CategoryType,
			SC.DisplayName AS SubCategoryType,
			SC.Indicators,
			TotalMaxPoint AS TotalPoints,
			Weightage AS ObtainedPoints,			
			 CAST(CAST((Weightage * 100/ (TotalMaxPoint * 1.0)) AS NUMERIC(18,2)) AS NVARCHAR) + ' %'  AS Percentage,
			  '' AS MOName,
			 '' AS LeaderName,
			 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)			
			FROM (Select 
					SUM(A.MaxWeight)As TotalMaxPoint,
					CategoryTypeId,
					SubCategoryTyepId 
					from 
					(Select 
						MAX(A.weightage)As MaxWeight,
						Q.QuestionId,
						Q.SubCategoryTyepId,
						Q.CategoryTypeId 
						from tblAnswer A
						inner join tblQuestion Q on A.QuestionId = Q.QuestionId
						inner join tblSurveyAnswer SA on Q.QuestionId=SA.QuestionId
						where Q.CategoryTypeId between 7 and 9 And SurveyId=@SurveyId AND SA.weightage IS NOT NULL
						group by Q.QuestionId ,Q.SubCategoryTyepId ,Q.CategoryTypeId				
					) A
				group by SubCategoryTyepId,CategoryTypeId
				) tb1

			inner join 

			(SELECT SUM(SA.weightage) AS Weightage, Q.CategoryTypeId,q.SubCategoryTyepId,SurveyId FROM tblSurveyAnswer SA
			inner join (SELECT QuestionId,CategoryTypeId,SubCategoryTyepId FROM tblQuestion
						  ) Q on SA.QuestionId=Q.QuestionId
					WHERE Q.CategoryTypeId between 7 AND 9 AND SA.weightage IS NOT NULL
			GROUP BY Q.SubCategoryTyepId,Q.CategoryTypeId,SurveyId) tb2 on tb1.SubCategoryTyepId =tb2.SubCategoryTyepId

			inner join tblSubCategoryType SC ON TB1.SubCategoryTyepId=SC.SubCategoryTypeId
			INNER JOIN tblCategoryType CT ON TB2.CategoryTypeId=CT.CategoryTypeId
			WHERE SurveyId=@SurveyId 


			UNION	

			 Select * from (
			 select  
			 CategoryType1='10',
			 'Output Indicators' AS SubCategoryType,
			 CategoryType = (SELECT DisplayName FROM tblCategoryType WHERE CategoryTypeId=10),
			 Indicators =(Select IndicatorsForOIResult From tblSurvey S
						inner join tblCentre C on S.CentreId=c.CentreId
						inner join tblCentreType CT on C.CentreTypeId=CT.CentreTypeId
						where SurveyId = @SurveyId),			
			 SUM(IncreaseBy10PercentOrmore)+ ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G   INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=10 ) AS TotalPoints ,
			 SUM(S.weightage) AS ObtainedPoints,		
			 CAST(CAST((SUM(S.weightage * 1.0)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS Percentage,
			  '' AS MOName,
			 '' AS LeaderName,
			 CentreType =(Select CT.CentreType from tblSurvey S inner join tblCentre C on S.CentreId=C.CentreId 
inner join tblCentreType CT ON C.CentreTypeId=CT.CentreTypeId where S.SurveyId = @SurveyId)			
			 from tblGiAnswer G 
			 INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
			 INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
			 WHERE SurveyId=@SurveyId and S.CategoryTypeId=10 and  IncreaseBy10PercentOrmore>=0) OI Where OI.ObtainedPoints IS NOT NULL

			ORDER BY CategoryType
   END
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyResultCategoryWise]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 01/12/2014
-- Description:	To get datatable of SurveyResultCategoryWise
-- Example:  csp_Get_SurveyResultCategoryWise 14,1

-- =============================================
CREATE PROC [dbo].[csp_Get_SurveyResultCategoryWise]
(
@SurveyId INT,
@CategoryTypeId INT
)
AS
BEGIN						
	BEGIN TRY

	SELECT SUM(TBL1.weightage) AS ObtainScore,
	SUM(maxscore) AS MaxScore,
	CAST(CAST((SUM(TBL1.weightage)*100/SUM(maxscore*1.0))AS NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],' QA :' As CategoryType
	FROM(SELECT weightage,QuestionId,CategoryTypeId 
	FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=@CategoryTypeId  And weightage IS NOT NULL )TBL1
	INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
	GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
	INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
	INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId	
	GROUP BY TBL1.CategoryTypeId,CT.CategoryType
	
	UNION ALL
	
	SELECT SUM(weightage) AS ObtainScore,
	SUM(maxscore) AS MaxScore,
	CAST(CAST((SUM(weightage)*100/SUM(maxscore*1.0))AS NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],' GI :' As CategoryType
	FROM(SELECT weightage,QuestionId,CategoryTypeId 
	FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=@CategoryTypeId  And weightage IS NOT NULL)TBL1
	INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
	GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
	INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
	INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId and IsGi ='1'
	GROUP BY TBL1.CategoryTypeId,CT.CategoryType
 
	END TRY
	BEGIN CATCH	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyResultCategoryWiseSCCenter]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 01/12/2014
-- Description:	To get datatable of SurveyResultCategoryWise
-- Example: csp_Get_SurveyResultCategoryWiseSCCenter 8,10

-- =============================================
CREATE PROC [dbo].[csp_Get_SurveyResultCategoryWiseSCCenter]
(
@SurveyId INT,
@CategoryTypeId INT
)
AS
BEGIN						
	BEGIN TRY

	 SELECT SUM(T.MaxScore) as maxscore ,SUM(T.ObtainScore) as ObtainScore,CAST(CAST(SUM(T.ObtainScore)*100/SUM(T.MaxScore)AS NUMERIC(18,2))AS NVARCHAR) +'%'  AS [Percent],CategoryType fROM (SELECT SUM(weightage) AS ObtainScore,
	SUM(maxscore) AS MaxScore,
	CAST(CAST((SUM(weightage)*100/SUM(maxscore)*1.0)AS NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA :' As CategoryType
	FROM(SELECT weightage,QuestionId,CategoryTypeId 
	FROM tblSurveyAnswer WHERE SurveyId=@SurveyId AND CategoryTypeId=@CategoryTypeId)TBL1
	INNER JOIN (SELECT MAX(weightage)AS maxscore,QuestionId FROM tblAnswer 
	GROUP BY QuestionId) TBL2 ON TBL1.QuestionId= TBL2.QuestionId
	INNER JOIN tblCategoryType CT ON TBL1.CategoryTypeId=CT.CategoryTypeId
	INNER JOIN  tblQuestion QT on TBL1.QuestionId=QT.QuestionId
	GROUP BY TBL1.CategoryTypeId,CT.CategoryType
	UNION ALL
	
	select SUM(S.weightage) AS ObtainScore, SUM(IncreaseBy10PercentOrmore) + ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId  and S.CategoryTypeId=@CategoryTypeId ) AS MaxScore ,
    CAST(CAST((SUM(S.weightage)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'QA : 'As CategoryType from tblGiAnswer G 
    INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
    INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
    WHERE SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeId AND G.IncreaseBy10PercentOrmore>=0
	

	UNION ALL 
	select SUM(S.weightage) AS ObtainScore, SUM(IncreaseBy10PercentOrmore) + ( select SUM(DecreaseBy10PercentOrMore) from tblGiAnswer  G 
           INNER JOIN tblSurveyAnswer S on G.QuestionId=S.QuestionId
           INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId  where DecreaseBy10PercentOrMore>=0 and SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeId ) AS MaxScore ,
    CAST(CAST((SUM(S.weightage)*100/SUM(IncreaseBy10PercentOrmore)*1.0)As NUMERIC(18,2))AS NVARCHAR)+'%' AS [Percent],'GI : 'As CategoryType from tblGiAnswer G 
    inner join tblSurveyAnswer S on G.QuestionId=S.QuestionId
    INNER JOIN tblQuestion Q on S.QuestionId=Q.QuestionId
    where S.SurveyId=@SurveyId and S.CategoryTypeId=@CategoryTypeId and Q.IsGi='1' AND G.IncreaseBy10PercentOrmore>=0)T
    group by T.CategoryType 


	
  	END TRY
	BEGIN CATCH	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveySchedule]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--============================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of SurveySchedule 
-- Example: csp_Get_SurveySchedule
-- =============================================

CREATE PROC [dbo].[csp_Get_SurveySchedule]
(
	@roleId int =null,
   @userId int =null
)
AS
BEGIN	
	IF(@roleId<>0)	
		BEGIN						
			BEGIN TRY
		SELECT 
			SS.SurveyScheduleId,
			SS.CentreId,
			C.TalukaId,
			T.DistrictId,
			SS.SurveyDate,
			SS.SurveyStartTime,
			SS.SurveyEndTime,
			D.DistrictName AS District,
			T.TalukaName AS Taluka,
			C.Centre
		FROM tblSurveySchedule SS
		INNER JOIN tblCentre C ON C.CentreId = SS.CentreId
		INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
		INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
		WHERE T.DistrictId 
			IN (SELECT DistrictId FROM tblTaluka  WHERE TalukaId 
			IN (SELECT TalukaId FROM tblCentre WHERE CentreId 
			IN (SELECT CentreId FROM tblUserCentreMapping WHERE UserId = @userId)))
		ORDER BY SS.SurveyScheduleId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
		END
	ELSE
		BEGIN						
			BEGIN TRY
		SELECT 
			SS.SurveyScheduleId,
			SS.CentreId,
			C.TalukaId,
			T.DistrictId,
			SS.SurveyDate,
			SS.SurveyStartTime,
			SS.SurveyEndTime,
			D.DistrictName AS District,
			T.TalukaName AS Taluka,
			C.Centre
		FROM tblSurveySchedule SS
		INNER JOIN tblCentre C ON C.CentreId = SS.CentreId
		INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
		INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
		ORDER BY SS.SurveyScheduleId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
		END
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveySchedule_By_Centre]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--============================
-- Author: Parshwanath Chougule
-- Create date: 09/12/2014
-- Description:	To get datatable of SurveySchedule By Center
-- Example: csp_Get_SurveySchedule_By_Centre
-- =============================================
CREATE PROC [dbo].[csp_Get_SurveySchedule_By_Centre]
(
	@CentreId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT 
			SS.SurveyScheduleId,
			SS.CentreId,
			C.TalukaId,
			T.DistrictId,
			SS.SurveyDate,
			SS.SurveyStartTime,
			SS.SurveyEndTime,
			D.DistrictName AS District,
			T.TalukaName AS Taluka,
			C.Centre
		FROM tblSurveySchedule SS
		INNER JOIN tblCentre C ON C.CentreId = SS.CentreId
		INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
		INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
		WHERE SS.CentreId = @CentreId
		ORDER BY SS.SurveyScheduleId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveySchedule_By_District]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--============================
-- Author: Parshwanath Chougule
-- Create date: 09/12/2014
-- Description:	To get datatable of SurveySchedule By District
-- Example: csp_Get_SurveySchedule_By_District
-- =============================================
CREATE PROC [dbo].[csp_Get_SurveySchedule_By_District]
(
	@DistrictId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT 
			SS.SurveyScheduleId,
			SS.CentreId,
			C.TalukaId,
			T.DistrictId,
			SS.SurveyDate,
			SS.SurveyStartTime,
			SS.SurveyEndTime,
			D.DistrictName AS District,
			T.TalukaName AS Taluka,
			C.Centre
		FROM tblSurveySchedule SS
		INNER JOIN tblCentre C ON C.CentreId = SS.CentreId
		INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
		INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
		WHERE D.DistrictId = @DistrictId
		ORDER BY SS.SurveyScheduleId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveySchedule_By_Taluka]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--============================
-- Author: Parshwanath Chougule
-- Create date: 09/12/2014
-- Description:	To get datatable of SurveySchedule By Taluka
-- Example: csp_Get_SurveySchedule_By_Taluka
-- =============================================
CREATE PROC [dbo].[csp_Get_SurveySchedule_By_Taluka]
(
	@TalukaId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT 
			SS.SurveyScheduleId,
			SS.CentreId,
			C.TalukaId,
			T.DistrictId,
			SS.SurveyDate,
			SS.SurveyStartTime,
			SS.SurveyEndTime,
			D.DistrictName AS District,
			T.TalukaName AS Taluka,
			C.Centre
		FROM tblSurveySchedule SS
		INNER JOIN tblCentre C ON C.CentreId = SS.CentreId
		INNER JOIN tblTaluka T ON T.TalukaId = C.TalukaId
		INNER JOIN tblDistrict D ON D.DistrictId = T.DistrictId
		WHERE T.TalukaId = @TalukaId 
		ORDER BY SS.SurveyScheduleId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveySkillTrainingStatus]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	31/07/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Get_SurveySkillTrainingStatus 1
-- ======================================================================

CREATE PROC [dbo].[csp_Get_SurveySkillTrainingStatus]
	(
		@SurveyId INT
	)
AS
BEGIN 
	IF EXISTS (SELECT SurveyId FROM tblSkillTrainingStatus WHERE SurveyId =  @SurveyId )
	BEGIN
	    SELECT 
		StaffName,
		DesignationId,
		QualificationId,	
		Minilap,
		NSV,
		MTP,
		BEMOC,
		EMOC,
		STIRTI,
		IUD,
		LSAS,
		IMEP,
		CTC,
		NSSK,
		RI,
		FIMNCI,
		SBA,
		IYCF,
		Other
		FROM tblSkillTrainingStatus WHERE SurveyId =@SurveyId
	END
	ELSE
	BEGIN
		SELECT
		StaffName,
		DesignationId,
		QualificationId,	
		Minilap,
		NSV,
		MTP,
		BEMOC,
		EMOC,
		STIRTI,
		IUD,
		LSAS,
		IMEP,
		CTC,
		NSSK,
		RI,
		FIMNCI,
		SBA,
		IYCF,
		Other
		FROM tblSkillTrainingStatus WHERE SurveyId IN   
					( SELECT Top(1)SurveyId from tblSurvey WHERE CentreId IN 
					(SELECT CentreId FROM tblSurvey WHERE SurveyId=@SurveyId) AND SurveyId <> @SurveyId ORDER BY VisitDate DESC)
    END
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Get_SurveyToUploadFromLoacalMachine]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--============================
-- Author: Mahesh Warambhe
-- Create date: 07/01/2015
-- Description:	To get datatable of SurveyToUploadOnServer 
-- Example: csp_Get_SurveyToUploadFromLoacalMachine
-- =============================================

CREATE PROC [dbo].[csp_Get_SurveyToUploadFromLoacalMachine]
(
   @CentreId int 
)
AS
BEGIN	
	Select 
	SurveyId,
	CentreId,
	VisitDate 
	from tblSurvey 
	Where @CentreId = @CentreId 
	order by VisitDate desc
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Taluka]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Yograj Sulakhe
-- Create date: 27/11/2014
-- Description:	To get datatable of Taulka
-- Example: csp_Get_Taluka
-- =============================================
CREATE PROC [dbo].[csp_Get_Taluka]
(
	@roleId int =null,
	 @userId int =null
)
AS
BEGIN	
	IF(@roleId<>0)	
		BEGIN						
			BEGIN TRY
				SELECT T.TalukaId,
				   T. TalukaName,
				   T.DistrictId,
				   D.DistrictName, 
				   T.Description
				   FROM tblTaluka  T  
				INNER JOIN tblDistrict D ON D.DistrictId= T.DistrictId
				WHERE TalukaId IN 
					 (SELECT TalukaId FROM tblCentre WHERE CentreId 
					 IN (SELECT CentreId FROM tblUserCentreMapping WHERE UserId = @userId))    
				   ORDER BY TalukaId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
		END
	ELSE
		BEGIN
		BEGIN TRY
		SELECT T.TalukaId,
		       T. TalukaName,
			   T.DistrictId,
			   D.DistrictName, 
			   T.Description
			   FROM tblTaluka  T  
			   INNER JOIN tblDistrict D ON D.DistrictId= T.DistrictId    
			   ORDER BY TalukaId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
		END
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Taluka_Dropdown]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Parshwanath Chougule
-- Create date: 27/11/2014
-- Description:	To get datatable of Taluka dropdown
-- Example: csp_Get_Taluka_Dropdown
-- =============================================
CREATE PROC [dbo].[csp_Get_Taluka_Dropdown]
(
	@DistrictId int,
	@roleId int =null,
	 @userId int =null
)
AS
BEGIN	
	IF(@roleId<>0)	
		BEGIN						
			BEGIN TRY
		SELECT TalukaId,TalukaName FROM tblTaluka 
		WHERE DistrictId = @DistrictId 
			AND TalukaId 
			IN (SELECT TalukaId FROM tblCentre WHERE CentreId 
			IN (SELECT CentreId FROM tblUserCentreMapping WHERE UserId = @userId))
		 ORDER BY TalukaName
	END TRY
	BEGIN CATCH	
	END CATCH
		END
	ELSE
		BEGIN						
			BEGIN TRY
				SELECT TalukaId,TalukaName FROM tblTaluka WHERE DistrictId = @DistrictId ORDER BY TalukaName
			END TRY
			BEGIN CATCH	
			END CATCH
		END
		
END



GO
/****** Object:  StoredProcedure [dbo].[csp_Get_User]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of User 
-- Example: [csp_Get_User] 9
-- =============================================
CREATE PROC [dbo].[csp_Get_User]
AS
BEGIN						
	BEGIN TRY
		SELECT 
			UM.UserId,
			UM.QualificationId,
			UM.DesignationID,
			UM.ReportingManagerId,
			UM.RoleId,
			UM.FirstName,
			UM.MiddleName,
			UM.LastName,
			Q.Qualification,
			DM.Designation,
			REM.FirstName + ' ' + REM.LastName AS ReportingManager,
			RM.RoleName,
			UM.UserName,
			UM.ContactNumber,
			UM.ContactEmail
		FROM tblUserMaster UM
		LEFT JOIN tblQualification Q ON Q.QualificationId = UM.QualificationId
		LEFT JOIN tblDesignationMaster DM ON DM.DesignationId = UM.DesignationId
		LEFT JOIN tblUserMaster REM  ON REM.UserId = UM.ReportingManagerId
		LEFT JOIN tblRoleMaster  RM ON RM.RoleId = UM.RoleId
		ORDER BY UM.UserId DESC
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_UserCentreMapping]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of Centre 
-- Example: csp_Get_UserCentreMapping
-- =============================================
CREATE PROC [dbo].[csp_Get_UserCentreMapping]
(
	@UserId INT
)
AS
BEGIN						
	BEGIN TRY
		SELECT CentreId FROM tblUserCentreMapping WHERE UserId=@UserId
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_UserMappedinCentre]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of User 
-- Example: csp_Get_UserMappedinCentre 4,1,1
-- =============================================
CREATE PROC [dbo].[csp_Get_UserMappedinCentre]
(
@CenterId INT,
@DistrictID INT,
@TalukaId INT
)
AS
BEGIN						
	BEGIN TRY
					
			SELECT UM.UserId,UM.ReportingManagerId,UM.DesignationId,UM.RoleId,UM.UserName,UM.Password,
			UM.FirstName,UM.MiddleName,UM.LastName,UM.QualificationId,UM.ContactNumber,UM.ContactEmail 
			FROM tblUserMaster UM 
			INNER JOIN  tblUserCentreMapping UC ON UM.UserId=UC.UserId 
			INNER JOIN  tblCentre C on UC.CentreId=C.CentreId
			INNER JOIN tblTaluka T on C.TalukaId=T.TalukaId
			INNER JOIN  tblDistrict D on T.DistrictId=D.DistrictId 
			WHERE  UC.CentreId=@CenterId   and C.TalukaId=@TalukaId  and T.DistrictId=@DistrictID 
			ORDER BY  UM.UserId
 
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_UserProfile]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Abhinandan Patil
-- Create date: 29/09/2014
-- Description:	To get datatable of City
-- Example: csp_Get_UserProfile
-- =============================================
CREATE PROC [dbo].[csp_Get_UserProfile]   
(       
	@UserName  nvarchar(50),  
	@Password nvarchar(50)   
)
AS          
BEGIN                 
     SELECT 
		UserId,
		UserName,
		FirstName + ' ' + ISNULL(LastName,'') AS DisplayName,
		RoleId
	FROM tblUserMaster 
	WHERE Username = @UserName AND Password = @Password  COLLATE SQL_Latin1_General_CP1_CS_AS   
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Get_Weightage]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author:	Yograj Sulakhe
-- Create date: 05/11/2014
-- Description:	To get datatable of SurveyAnswer Option
-- Example: csp_Get_SurveyAnswerOption
-- =============================================
cREATE PROC [dbo].[csp_Get_Weightage]
(
@QuestionId INT,
@Performance FLOAT
)
AS
BEGIN						
	--BEGIN TRy
		
				 IF(@Performance < -10)
					BEGIN
							SELECT DecreaseBy10PercentOrMore AS Weightage FROM tblGiAnswer WHERE QuestionId=@QuestionId 
					END
						 
						ELSE IF(@Performance <= 10)
					 
					BEGIN
							SELECT IncreaseBy10PercentOrmore AS Weightage FROM tblGiAnswer WHERE QuestionId=@QuestionId 
					END
						ELSE
						
				    BEGIN
							SELECT [ScoreRange-10TO+10] AS Weightage  FROM  tblGiAnswer WHERE QuestionId=@QuestionId 
					END
								
		--END TRY
	--BEGIN CATCH	
	--END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_GetDataSurveyDetailsFromServer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==============================================
-- Author: Mahesh Warambhe
-- Create date: 29/11/2014
-- Description:	To get datatables of  DataSurveyDetailsFromServer
-- Example: csp_GetDataSurveyDetailsFromServer 23
-- =============================================

CREATE PROC [dbo].[csp_GetDataSurveyDetailsFromServer]
(
	@CentreId INT,
	@VisitDate DATETIME =NULL
)

AS
BEGIN	
	BEGIN TRY

	DECLARE @ServerSurveyId int = (SELECT SurveyId FROM tblSurvey WHERE CentreId= @CentreId and VisitDate=@VisitDate)

	SELECT * FROM tblSurvey WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblDQAG WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblStaffRespondent WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblHRProfile WHERE SurveyId=@ServerSurveyId

    SELECT * FROM tblSkillTrainingStatus WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblSurveyAnswer WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblGiResult WHERE SurveyId =@ServerSurveyId

	SELECT * FROM tblResult WHERE SurveyId=@ServerSurveyId

	SELECT * FROM tblRevievRecord WHERE SurveyId=@ServerSurveyId

	END TRY
	BEGIN CATCH	
	END CATCH
		
END






GO
/****** Object:  StoredProcedure [dbo].[csp_Insert_UserMappedinCentre]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=============================================
-- Author: Parshwanath Chougule
-- Create date: 29/11/2014
-- Description:	To get datatable of User 
-- Example: csp_Get_UserMappedinCentre 4,1,1
-- =============================================
CREATE PROC [dbo].[csp_Insert_UserMappedinCentre]
(
@UserMappedinCentre  UserMappedinCentre readonly
)
AS
BEGIN						
	BEGIN TRY
	BEGIN 
	INSERT INTO tblUserMaster
	(
	UserId,
    ReportingManagerId,
	DesignationId,
	RoleId,
	UserName,
	Password,
	FirstName,
	MiddleName ,
	LastName,
	QualificationId,
	ContactNumber,
	ContactEmail
	)
	SELECT UserId,ReportingManagerId,DesignationId,RoleId,UserName,Password,
			FirstName,MiddleName,LastName,QualificationId,ContactNumber,ContactEmail 
			FROM @UserMappedinCentre
    END
	END TRY
	BEGIN CATCH	
	END CATCH
END






GO
/****** Object:  StoredProcedure [dbo].[csp_InsertDataOnLocalMachine]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	29/11/2014
-- Description	:	Insert, Update, Delete User Table Data
-- Used For		:	Insert, Update, Delete User Table Data
-- Example		:	csp_Modify_User 1,0,59,1,0,2,'Test','Test','p',p','p',0,'p',0
-- ======================================================================
CREATE PROC [dbo].[csp_InsertDataOnLocalMachine]
	(
	@AnsewerType  AnsewerType READONLY, 
	@Answer  Answer READONLY, 
	@CategoryType CategoryType  READONLY,
	@Centre Centre  READONLY,
    @CentreType  CentreType READONLY,
	@DesignationMaster DesignationMaster READONLY,
	@District District READONLY,
	@GAnswer GAnswer READONLY,
	@Grade Grade READONLY,
	@IndicatorMaster IndicatorMaster READONLY,
	@Qualification Qualification READONLY,
	@Question Question READONLY,
	@RoleMaster RoleMaster  READONLY,
	@SubCategoryType SubCategoryType READONLY,
	@SurveyPeopleFromServer  SurveyPeopleFromServer READONLY,
	@SurveySchedule SurveySchedule  READONLY, 
    @Taluka Taluka  READONLY, 
	@UserCentreMappingFromServer UserCentreMappingFromServer READONLY,
	@UserMaster UserMaster READONLY,
	@ModuleAccess ModuleAccess READONLY,
	@ModuleMaster ModuleMaster READONLY,
	@ReturnVal  INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	---BEGIN TRY	
	--INSERT QUERY
	--BEGIN

	
	 DELETE FROM tblResult
	 DELETE FROM tblGIResult
	  DELETE FROM tblActionPlanProgress
	 DELETE FROM tblActionPlan
	 DELETE FROm tblDQAG
	 DELETE FROM tblRevievRecord
	 DELETE FROM tblSkillTrainingStatus
	 DELETE FROM tblHRProfile
	 DELETE FROM tblStaffRespondent
	 DELETE FROM  tblSurveyAnswer
	

	
	 DELETE FROM tblModuleAccess
	 DELETE FROM tblModuleMaster
	 DELETE FROM tblSurveyPeople
	  DELETE FROM tblSurveySchedule
	 DELETE FROM tblUserCentreMapping
	 DELETE FROM tblUserMaster
	 DELETE FROM tblRoleMaster
	  DELETE FROM tblSurvey
	 
	
	 DELETE FROM tblIndicatorMaster
	 DELETE FROM tblGrade
	 DELETE FROM tblGiAnswer
	 DELETE FROM tblDesignationMaster
	 DELETE FROM tblQualification
	 DELETE FROM tblAnswer
	 DELETE FROM tblQuestion
	 DELETE FROM tblAnsewerType
	 DELETE FROM tblSubCategoryType
	 DELETE FROM tblCategoryType
	 DELETE FROM tblCentre
	 DELETE FROM tblCentreType
	 DELETE FROM  tblTaluka
	 DELETE FROM tblDistrict
	 

	 INSERT INTO  tblDistrict
		(
		DistrictId,
		DistrictName,
		Description
		)
		SELECT  DistrictId,	DistrictName,Description FROM  @District

			INSERT INTO tblTaluka
		(
		TalukaId,
		DistrictId,
		TalukaName,
		Description
		)
		SELECT  TalukaId,DistrictId,TalukaName,	Description FROM @Taluka

		INSERT INTO  tblCentreType
		(
		CentreTypeId,
		CentreType,
		Description,
		IndicatorsForOIResult
		)
		SELECT CentreTypeId,CentreType,	Description,IndicatorsForOIResult FROM   @CentreType

		INSERT INTO tblCentre
		(
		CentreId,
		TalukaId,
	    CentreTypeId,
	    Centre,
		Address,
		ContactPerson,
		ContactEmail,
		ContactNumber
		)
		SELECT  CentreId,TalukaId, CentreTypeId, Centre,Address,ContactPerson,ContactEmail,	ContactNumber FROM @Centre

		INSERT  INTO tblCategoryType
		(
		CategoryTypeId,
	    CategoryType,
		Description,
	    Prefix,
	    Instructions,
	    Indicators,
	    DisplayName
		)
		SELECT CategoryTypeId, CategoryType,Description, Prefix, Instructions, Indicators, DisplayName FROM @CategoryType
		
		INSERT INTO tblSubCategoryType
		(
		SubCategoryTypeId,
		CategoryTypeId,
		SubCategoryType,
		Description,
		PreFix,
		Instructions,
		Indicators,
		DisplayName,
		IsOptional
		)
		SELECT SubCategoryTypeId,CategoryTypeId,SubCategoryType,Description,PreFix,	Instructions,Indicators,DisplayName,IsOptional FROM  @SubCategoryType


	   INSERT INTO tblAnsewerType
	   (
		AnswerTypeId,
		AnswerType
		)
		SELECT AnswerTypeId,AnswerType FROM @AnsewerType

			INSERT INTO tblQuestion
		(
		QuestionId,
		CenterTypeId,
		CategoryTypeId,
		SubCategoryTyepId,
		Question,
		Status,
		AnswerTyepId,
		IsDeletable,
		IsGi,
		ReviewRecordNo
		)
		SELECT QuestionId,CenterTypeId,	CategoryTypeId,	SubCategoryTyepId,	Question,Status,AnswerTyepId,IsDeletable,IsGi,ReviewRecordNo		 FROM @Question


		INSERT INTO tblAnswer
		(
		AnswerId,
		QuestionId,
		Answer,
		weightage
		)
		SELECT AnswerId,QuestionId,Answer,weightage FROM @Answer

		

		INSERT INTO tblQualification
		(
		QualificationId,
		Qualification,
		Description
		) 
		SELECT QualificationId,	Qualification,Description FROM  @Qualification

		INSERT INTO  tblDesignationMaster
		(
		DesignationId,
		Designation,
		Description
		)
		SELECT  DesignationId,Designation,	Description FROM  @DesignationMaster

	
		INSERT INTO  tblGiAnswer
		(
		GiAnswerId,
		QuestionId,
		[ScoreRange-10TO+10],
		DecreaseBy10PercentOrMore,
		IncreaseBy10PercentOrmore
		)
		SELECT  GiAnswerId,	QuestionId,[ScoreRange-10TO+10],DecreaseBy10PercentOrMore,IncreaseBy10PercentOrmore FROM @GAnswer

		INSERT INTO tblGrade
		(
		GradeId,
		MinScore,
		MaxScore,
		Grade
		)
		SELECT GradeId,MinScore,MaxScore,Grade FROM @Grade

		INSERT INTO  tblIndicatorMaster
		(
		IndicatorId,
		CategoryTypeId,
		SubCategoryTypeId,
		CentreTypeId,DisplayName
		)
		SELECT IndicatorId,	CategoryTypeId,	SubCategoryTypeId,CentreTypeId,DisplayName FROM @IndicatorMaster

			INSERT INTO tblModuleMaster
	(
	ModuleId,
	ModuleName,
	ParentId,
	ModuleTypeId,
	ModuleIdentifyId
	)
	SELECT ModuleId,ModuleName,ParentId,ModuleTypeId,ModuleIdentifyId FROM @ModuleMaster
	
	INSERT INTO tblRoleMaster
		(
		RoleId,
		RoleName,
		Description
		)
		SELECT RoleId,RoleName, Description FROM  @RoleMaster

		INSERT INTO tblModuleAccess
		(
		ModuleAccessId,
		RoleId,
		ModuleId,
		[View],
		[Add],
		[Update],
		[Delete]
		)
		SELECT  ModuleAccessId,RoleId,ModuleId,[View],[Add],[Update],[Delete] FROM @ModuleAccess

		
		INSERT INTO tblUserMaster 
		(
		UserId,
		ReportingManagerId,
		DesignationId,
		RoleId,
		UserName,
		Password,
		FirstName,
		MiddleName,
		LastName,
		QualificationId,
		ContactNumber,
		ContactEmail
		)
		SELECT UserId,ReportingManagerId,DesignationId,	RoleId,	UserName,Password,FirstName,MiddleName,	   LastName,QualificationId,ContactNumber,	ContactEmail FROM @UserMaster

		INSERT INTO tblUserCentreMapping
		(
		UserCentreMappingId,
		UserId,
		CentreId
		)
		SELECT  UserCentreMappingId,UserId,	CentreId FROM  @UserCentreMappingFromServer

		INSERT INTO tblSurveySchedule
		(
		SurveyScheduleId,
		CentreId,
		SurveyDate,
		SurveyStartTime,
		SurveyEndTime
		)
		SELECT  SurveyScheduleId,CentreId,SurveyDate,SurveyStartTime,SurveyEndTime FROM @SurveySchedule


			INSERT INTO tblSurveyPeople 
		(
		SurveyPeopleId,
		SurveyScheduleId,
		UserId
		)
		SELECT SurveyPeopleId,SurveyScheduleId,UserId FROM @SurveyPeopleFromServer

		
	
		
		      
			  IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
	
		
	END
	--END TRY	
	--BEGIN CATCH	
	--SET @ReturnVal = -3;
	--RETURN @ReturnVal;
	--END CATCH
--END



GO
/****** Object:  StoredProcedure [dbo].[csp_InsertLatestSurveyDataToLocalMachine]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==============================================
-- Author: Mahesh Warambhe
-- Create date: 29/11/2014
-- Description:	To get datatables of  DataSurveyDetailsFromServer
-- Example: csp_InsertLatestSurveyDataToLocalMachine 
-- =============================================

CREATE PROC [dbo].[csp_InsertLatestSurveyDataToLocalMachine]
(
	@tblTypeSurvey tblTypeSurvey  ReadOnly,
	@tblTypeDQAG tblTypeDQAG ReadOnly,
	@tblTypeStaffRespondent tblTypeStaffRespondent ReadOnly,
    @tblTypeHRProfile  tblTypeHRProfile ReadOnly,
	@tblTypeSkillTrainingStatus  tblTypeSkillTrainingStatus ReadOnly,
    @tblTypeResult  tblTypeResult ReadOnly,
    @tblTypeSurveyAnswer tblTypeSurveyAnswer ReadOnly,
    @tblTypeGIResult tblTypeGIResult ReadOnly,
    @tblTypeRevievRecord  tblTypeRevievRecord ReadOnly,
	@tblTypeActionPlan tblTypeActionPlan ReadOnly,
	@ReturnVal INT OUTPUT -- Output paramerter return value of operation
)

AS
BEGIN	
	BEGIN TRY

	DECLARE @SurveyIdTemp INT;

	INSERT INTO tblSurvey
	 (
	[CentreId],
	[NameofMO],
	[MobNoofMO],
	[Email],
	[TelephoneNo],
	[VisitDate],
	[VisitRound],
	[PreviousVisitDate],
	[PreviousVisitScore],
	[SubCentresNo],
	[PopulationCovered],
	[IPHSStatus],
	[247Status],
	[DeliveryPoint],
	[Distance],
	[VisitStartTime],
	[VisitEndTime],
	[TotalTime],
	[Status],
	[IsComplete]
   	)

	SELECT	
	[CentreId],
	[NameofMO],
	[MobNoofMO],
	[Email],
	[TelephoneNo],
	[VisitDate],
	[VisitRound],
	[PreviousVisitDate],
	[PreviousVisitScore],
	[SubCentresNo],
	[PopulationCovered],
	[IPHSStatus],
	[247Status],
	[DeliveryPoint],
	[Distance],
	[VisitStartTime],
	[VisitEndTime],
	[TotalTime],
	[Status],
	[IsComplete] FROM @tblTypeSurvey

	SET @SurveyIdTemp = @@IDENTITY;

	INSERT INTO tblDQAG
	(
	[SurveyId],
	[UserId]
	)
	SELECT @SurveyIdTemp,[UserId] FROM @tblTypeDQAG

	INSERT INTO tblStaffRespondent
	(
	[SurveyId],
	[UserName],
    [DesignationId],
	[QualificationId],
	[MobNo]
	)
	SELECT @SurveyIdTemp,[UserName],[DesignationId],[QualificationId], [MobNo]FROM @tblTypeStaffRespondent

	INSERT INTO tblHRProfile
	(
	[SurveyId],
	[DesignationId],
	[PostSanctionedNo],
	[RegularNo],
	[Contractual],
	[Remark]
	)
	SELECT @SurveyIdTemp,[DesignationId],[PostSanctionedNo],[RegularNo],[Contractual],[Remark]FROM @tblTypeHRProfile
	
	INSERT INTO tblSkillTrainingStatus
	(
	[SurveyId],
	[StaffName],
	[DesignationId],
	[QualificationId],
	[Minilap],
	[NSV],
	[MTP],
	[BEMOC],
	[EMOC],
	[STIRTI],
	[IUD],
	[LSAS],
	[IMEP],
	[CTC],
	[NSSK],
	[RI],
	[FIMNCI],
	[SBA],
	[IYCF],
	[Other]
	)
	SELECT
	@SurveyIdTemp,	
	[StaffName],
	[DesignationId],
	[QualificationId],
	[Minilap],
	[NSV],
	[MTP],
	[BEMOC],
	[EMOC],
	[STIRTI],
	[IUD],
	[LSAS],
	[IMEP],
	[CTC],
	[NSSK],
	[RI],
	[FIMNCI],
	[SBA],
	[IYCF],
	[Other]
	FROM  @tblTypeSkillTrainingStatus

	INSERT INTO tblResult 
	(
	[SurveyId],
	[MaxScore],
	[ScoreObtain],
	[Percentage],
	[Grade],
	[ResultMOICName],
	[ResultQATeamLeaderId],
	[GiMOICName],
	[GiQATeamLeaderId],
	[ActionPlanMOICName],
	[ActionQATeamLeaderId]
	)

	SELECT
	@SurveyIdTemp,
	[MaxScore],
	[ScoreObtain],
	[Percentage],
	[Grade],
	[ResultMOICName],
	[ResultQATeamLeaderId],
	[GiMOICName],
	[GiQATeamLeaderId],
	[ActionPlanMOICName],
	[ActionQATeamLeaderId] 
	FROM  @tblTypeResult

	INSERT INTO tblSurveyAnswer 
	(
	[SurveyId],
	[CategoryTypeId],
	[QuestionId],
	[AnswerId],
	[weightage],
	[IsGi]
	)
	SELECT @SurveyIdTemp,[CategoryTypeId],	[QuestionId],	[AnswerId],	[weightage],[IsGi] FROM  @tblTypeSurveyAnswer

	INSERT INTO tblGIResult
	(
	[SurveyId],
	[QuestionId],
	[CategoryTypeId],
	[ThreeMonthRecordA],
	[ThreeMonthRecordB],
	[Percentage]
	)
	SELECT  @SurveyIdTemp,[QuestionId],	[CategoryTypeId],[ThreeMonthRecordA],[ThreeMonthRecordB],[Percentage] FROM @tblTypeGIResult

	INSERT INTO tblRevievRecord
	(
	[SurveyId],
	[QuestionId],
	[CategoryTypeId],
	[LastThreeMonthPerformance]
	)
	SELECT @SurveyIdTemp,[QuestionId],[CategoryTypeId],	[LastThreeMonthPerformance] FROM  @tblTypeRevievRecord

	INSERT INTO tblActionPlan
	(
	[SurveyId],
	[CategoryTypeId],
	[SubCategoryTypeId],
	[Problem],
	[Solution],
	[PHCLevel],
	[DistrictLevel],
	[StateLevel],
	[DueDate],
	[ResponsiblePerson]
	)
	SELECT 
	@SurveyIdTemp,
	[CategoryTypeId],
	[SubCategoryTypeId],
	[Problem],
	[Solution],
	[PHCLevel],
	[DistrictLevel],
	[StateLevel],
	[DueDate],
	[ResponsiblePerson] 
	FROM  @tblTypeActionPlan


	       IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END		

	END TRY
	BEGIN CATCH	
	            SET @ReturnVal = -3; -- if Exception occur
				RETURN @ReturnVal; 
	END CATCH
		
END






GO
/****** Object:  StoredProcedure [dbo].[csp_LogExceptionToDB]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:   Abhinandan Patil
-- Create date	:	18/09/2014
-- Description	:	Insert exceptions
-- Used For		:	Error Handling
-- Example		:	
-- ======================================================================
CREATE PROC [dbo].[csp_LogExceptionToDB]
@source varchar(100),
@LogDateTime dateTime,
@Message varchar(1000),
@QueryString varchar(2000),
@TargetSite varchar(300),
@StackTrace varchar(4000),
@ServerName varchar(300),
@RequestURL varchar(300),
@UserAgent varchar(300),
@UserIP varchar(300),
@UserAuthentication varchar(300),
@UserName varchar(300),
@EventId int output

AS

INSERT INTO tblExceptionLogItems
(Source, LogDateTime,Message,QueryString,TargetSite,StackTrace,ServerName,RequestURL,
UserAgent,UserIP,UserAuthentication,UserName)
Values ( 
@Source,
@LogDateTime,
@Message,
@QueryString,
@TargetSite,
@StackTrace,
@ServerName,
@RequestURL,
@UserAgent,
@UserIP,
@UserAuthentication,
@UserName
)

Select @EventId=IDENT_CURRENT('tblExceptionLogItems')






GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_CategoryType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Yograj Sulakhe
-- Create date	:	29/11/2014
-- Description	:	Insert, Update, Delete category Table Data
-- Used For		:	Insert, Update, Delete category Table Data
-- Example		:	csp_Modify_category 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_CategoryType]
(
	@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
	@CategoryTypeId INT,
	@CategoryType NVARCHAR(200),
	@Description NVARCHAR(MAX),		
	@ReturnVal INT OUTPUT -- Output paramerter return value of operation
)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT CategoryTypeId  FROM  tblCategoryType WHERE CategoryType=@CategoryType)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblCategoryType
					(
						CategoryType,
						Description
					)
					VALUES
					(
						@CategoryType,
						@Description		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT CategoryTypeId FROM tblCategoryType WHERE CategoryType=@CategoryType AND CategoryTypeId<>@CategoryTypeId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblCategoryType SET CategoryType=@CategoryType,Description=@Description  WHERE CategoryTypeId=@CategoryTypeId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT CategoryTypeId FROM tblCategoryType WHERE CategoryTypeId=@CategoryTypeId)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblCategoryType WHERE CategoryTypeId=@CategoryTypeId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Centre]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	29/11/2014
-- Description	:	Insert, Update, Delete Centre Table Data
-- Used For		:	Insert, Update, Delete Centre Table Data
-- Example		:	[csp_Modify_Centre] 2,1,'Test','Test',1
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_Centre]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@CentreId INT,		
		@TalukaId INT,
		@CentreTypeId INT,
		@Centre NVARCHAR(200),
		@Address NVARCHAR(MAX),	
		@ContactPerson NVARCHAR(200),
		@ContactEmail NVARCHAR(200),
		@ContactNumber NVARCHAR(50),
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT CentreId  FROM  tblCentre WHERE Centre=@Centre)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblCentre
					(					
						TalukaId,
						CentreTypeId,
						Centre,
						Address,
						ContactPerson,
						ContactEmail,
						ContactNumber
					)
					VALUES
					(					
						@TalukaId,
						@CentreTypeId,
						@Centre,
						@Address,
						@ContactPerson,
						@ContactEmail,
						@ContactNumber		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT CentreId  FROM  tblCentre WHERE Centre=@Centre AND CentreId<>@CentreId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblCentre SET
					TalukaId =@TalukaId,
					CentreTypeId = @CentreTypeId,
					Centre = @Centre,
					Address = @Address,
					ContactPerson = @ContactPerson,
					ContactEmail = @ContactEmail,
					ContactNumber = @ContactNumber WHERE CentreId=@CentreId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT CentreId  FROM  tblCentre WHERE CentreId=@CentreId)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblCentre WHERE CentreId=@CentreId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_CentreType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	27/11/2014
-- Description	:	Insert, Update, Delete CentreType Table Data
-- Used For		:	Insert, Update, Delete CentreType Table Data
-- Example		:	[csp_Modify_CentreType] 2,1,'5464','est',''
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_CentreType]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@CentreTypeId INT,
		@CentreType NVARCHAR(200),
		@Description NVARCHAR(MAX),		
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT CentreTypeId  FROM  tblCentreType WHERE CentreType=@CentreType)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblCentreType
					(
						CentreType,
						Description
					)
					VALUES
					(
						@CentreType,
						@Description		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT CentreTypeId  FROM  tblCentreType WHERE CentreType=@CentreType AND CentreTypeId<>@CentreTypeId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblCentreType SET CentreType=@CentreType, Description=@Description  WHERE CentreTypeId=@CentreTypeId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT CentreTypeId  FROM  tblCentreType WHERE @CentreTypeId=@CentreTypeId)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblCentreType WHERE CentreTypeId=@CentreTypeId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_ChangePassword]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	29/11/2014
-- Description	:	Update UserMaster Table Data
-- Used For		:	Update Table Data
-- Example		:	csp_Modify_ChangePassword 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_ChangePassword]
(
	@UserId INT,
	@CurrentPassword NVARCHAR(200),
	@NewPassword NVARCHAR(200),		
	@ReturnVal INT OUTPUT -- Output paramerter return value of operation
)
AS
BEGIN
	BEGIN TRY	
	
		
			IF EXISTS(SELECT UserId FROM tblUserMaster WHERE UserId=@UserId AND [Password] = @CurrentPassword)
			
				BEGIN
					UPDATE tblUserMaster SET Password= @NewPassword WHERE  UserId=@UserId
				END
			ELSE 
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END



		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		
	
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Designation]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	27/11/2014
-- Description	:	Insert, Update, Delete Qualification Table Data
-- Used For		:	Insert, Update, Delete Qualification Table Data
-- Example		:	[csp_Modify_Designation] 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_Designation]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@DesignationId INT,
		@Designation NVARCHAR(200),
		@Description NVARCHAR(MAX),		
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT DesignationId  FROM tblDesignationMaster WHERE Designation=@Designation)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblDesignationMaster
					(
						Designation,
						Description
					)
					VALUES
					(
						@Designation,
						@Description		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT @DesignationId  FROM  tblDesignationMaster WHERE Designation=@Designation AND DesignationId<>@DesignationId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblDesignationMaster SET Designation=@Designation,Description=@Description WHERE DesignationId=@DesignationId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT @DesignationId  FROM  tblDesignationMaster WHERE Designation=@Designation)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblDesignationMaster WHERE DesignationId=@DesignationId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_District]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Yograj Sulakhe
-- Create date	:	27/11/2014
-- Description	:	Insert, Update, Delete District Table Data
-- Used For		:	Insert, Update, Delete District Table Data
-- Example		:	csp_Modify_District 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_District]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@DistrictId INT,
		@DistrictName NVARCHAR(200),
		@Description NVARCHAR(300),		
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT DistrictId  FROM  tblDistrict WHERE DistrictName=@DistrictName)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblDistrict
					(
					DistrictName,
					Description
					)
					VALUES
					(
						@DistrictName,
						@Description		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT DistrictId FROM  tblDistrict WHERE DistrictName=@DistrictName AND DistrictId<>@DistrictId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblDistrict SET DistrictName=@DistrictName,Description=@Description  WHERE DistrictId=@DistrictId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT DistrictId FROM tblDistrict WHERE DistrictId=@DistrictId)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblDistrict WHERE DistrictId=@DistrictId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_DQAGMemberSelfAssessmentTeam]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	07/12/2014
-- Description	:	Insert, Update, Delete DQAGMemberSelfAssessmentTeam Table Data
-- Used For		:	Insert, Update, Delete DQAGMemberSelfAssessmentTeam Table Data
-- Example		:	csp_Modify_DQAGMemberSelfAssessmentTeam 
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_DQAGMemberSelfAssessmentTeam]
	(
		@SurveyId INT,
		@DQAG DQAG READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- UPDATE QUERY
	BEGIN
			IF EXISTS(SELECT DQAGId  FROM  tblDQAG WHERE SurveyId=@SurveyId)
				BEGIN

					DELETE FROM tblDQAG WHERE SurveyId=@SurveyId
			END
			

		INSERT INTO tblDQAG  SELECT @SurveyId,UserId FROM @DQAG
				
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_EmailLog]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Yogesh
-- Create date	:	06/11/2014
-- Description	:	Insert, Update, Delete City Table Data
-- Used For		:	Insert, Update, Delete City Table Data
-- Example		:	csp_Modify_EmailLog
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_EmailLog]
	(
		@Action NVARCHAR(MAX)
	)
AS
BEGIN
	BEGIN TRY	
		
	INSERT INTO tblEmailLog
	(
		Action,
		TimeStamp
	)
	VALUES
	(
		@Action,
		GETDATE()
	)	
	
	DELETE FROM tblSMSLog WHERE Timestamp < DATEADD(DAY, -7, GETDATE())
				
	END TRY	
	BEGIN CATCH		
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_EmailQueue]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Yograj Sulakhe
-- Create date	:	12/11/2014
-- Description	:	Insert, Update, Delete Email Queue Table Data
-- Used For		:	Insert, Update, Delete Email Queue Table Data
-- Example		:	csp_Modify_SMSQueue
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_EmailQueue]
	(		
		@EmailQueueId INT,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	
	UPDATE tblEmailQueue SET 
			IsSend=1
			WHERE EmailQueueId=@EmailQueueId


		
	IF @@ERROR <>0
		BEGIN
			SET @ReturnVal = -2; -- if error occur
			RETURN @ReturnVal; 
		END
	ELSE
		BEGIN
			SET @ReturnVal = 1; -- If record successfully inserted 
			RETURN @ReturnVal;
		END

	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_GiResult_MOQAName]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	07/12/2014
-- Description	:	 Update Result Table Data
-- Used For		:	 Updat Result Table Data
-- Example		:	csp_Modify_GiResult_MOQAName 2,'ajay',1,'' 
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_GiResult_MOQAName]
	(
		@SurveyId INT,
		@GiMOName nvarchar(200),
		@GiQATeamLeaderId INT,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- UPDATE QUERY
	BEGIN
					UPDATE tblResult SET GiMOICName=@GiMOName,GiQATeamLeaderId=@GiQATeamLeaderId WHERE SurveyId=@SurveyId 
			

			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_GiSurveyAnswer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Yograj Sulakhe
-- Create date	:	31/07/2014
-- Description	:	Insert, Update, Delete Question
-- Used For		:	Insert, Update, Delete  Question
-- Example		:	csp_Modify_SurveyAnswer 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_GiSurveyAnswer]
	(
		@SurveyId INT=NULL,
		@CategoryTypeId INT,
		@GiAnswer GiAnswer READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
		
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	
				IF EXISTS( SELECT GIResultId FROM tblGIResult WHERE CategoryTypeId=@CategoryTypeId AND SurveyId=@SurveyId )
	            BEGIN 
	            DELETE FROM tblGIResult WHERE  CategoryTypeId=@CategoryTypeId AND SurveyId=@SurveyId
	            END
	        
	            INSERT INTO TblGIResult
	            (
	            QuestionId,
	            CategoryTypeId,
	            SurveyId,
	            ThreeMonthRecordA,
	            ThreeMonthRecordB,
	            Percentage
	            )
	            SELECT 
	            QuestionId,
	            @CategoryTypeId,
	            @SurveyId,
	            ThreeMonthRecordA,
	            ThreeMonthRecordB,
	            Performance 
	            FROM @GiAnswer
	
	
				IF EXISTS(SELECT SurveyAnswerId FROM tblSurveyAnswer WHERE SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId)
				BEGIN
					DELETE FROM tblSurveyAnswer WHERE  SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId 
				END
				
				INSERT INTO tblSurveyAnswer
				(
					SurveyId,
					CategoryTypeId,
					QuestionId,
					weightage		
				)
				 SELECT 
				 @SurveyId,
				 @CategoryTypeId,
				 QuestionId,
				 Weightage FROM @GiAnswer
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
	END TRY
    BEGIN CATCH
    SET @ReturnVal = -3;
	RETURN @ReturnVal; 
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_ModuleAccessMaster]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================    
-- Author  : Parshwanath Chougule     
-- Create date : 14-feb-2014    
-- Description : Insert, Update,  ModuleAccessMaster Table Data    
-- Used For  : Insert, Update,  RoleApplicability  Table Data       
-- Example  :[csp_Modify_ModuleAccessMaster]
-- ======================================================================    
    
CREATE PROC [dbo].[csp_Modify_ModuleAccessMaster]    
  (    
	@tblModuleAccessTable ModifyModuleAccess readonly,  
	@ReturnVal int output -- Output paramerter return value of operation    
  )    
AS    
BEGIN           
	IF EXISTS(SELECT RoleId FROM tblModuleAccess WHERE RoleId IN (SELECT MA.RoleId FROM @tblModuleAccessTable MA ))    
		BEGIN  
			DELETE FROM tblModuleAccess WHERE RoleId IN (SELECT MA.RoleId FROM @tblModuleAccessTable MA)
			INSERT INTO tblModuleAccess
			(
				RoleId,
				ModuleId,
				[View],
				[Add],
				[Update],
				[Delete]
			) 
			SELECT MA.RoleId,MA.ModuleId,MA.[View],MA.[Add],MA.[Edit],MA.[Delete] 
			FROM @tblModuleAccessTable MA

   SET @ReturnVal = 1;--record already exist    
   RETURN @ReturnVal;    
   END    
   ELSE    
   BEGIN    
		INSERT INTO tblModuleAccess
			(
				RoleId,
				ModuleId,
				[View],
				[Add],
				[Update],
				[Delete]
			) 
			SELECT MA.RoleId,MA.ModuleId,MA.[View],MA.[Add],MA.[Edit],MA.[Delete]
			FROM @tblModuleAccessTable MA
      END    
      
  IF @@ERROR <>0    
   BEGIN    
   SET @ReturnVal = -2; -- if error occur    
   RETURN @ReturnVal;     
   END    
  ELSE    
   BEGIN    
   SET @ReturnVal = 1; -- If record successfully inserted     
   RETURN @ReturnVal;    
END 
END



GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Qualification]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	27/11/2014
-- Description	:	Insert, Update, Delete Qualification Table Data
-- Used For		:	Insert, Update, Delete Qualification Table Data
-- Example		:	[csp_Modify_Qualification] 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_Qualification]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@QualificationId INT,
		@Qualification NVARCHAR(200),
		@Description NVARCHAR(MAX),		
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT QualificationId  FROM tblQualification WHERE Qualification=@Qualification)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblQualification
					(
						Qualification,
						Description
					)
					VALUES
					(
						@Qualification,
						@Description		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT QualificationId  FROM  tblQualification WHERE Qualification=@Qualification AND QualificationId<>@QualificationId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblQualification SET Qualification=@Qualification,Description=@Description WHERE QualificationId=@QualificationId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT QualificationId  FROM  tblQualification WHERE Qualification=@Qualification)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblQualification WHERE QualificationId=@QualificationId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Question]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author	 :	Yograj Sulakhe
-- Create date	:	31/07/2014
-- Description	:	Insert, Update, Delete Question
-- Used For	 :	Insert, Update, Delete  Question
-- Example	 :	csp_Modify_Question 1,1,'Test','Test'
-- ======================================================================

CREATE PROC [dbo].[csp_Modify_Question]
(
@Operation INT = NULL, -- operation that is 1 = Insert,2=Update,3=Delete
@QuestionId INT=NULL ,
@CenterTypeId INT,
@CategoryTypeId INT,
@SubCategoryTypeId INT,
@AnswerTypeId INT,
@Status BIT,
@Question NVARCHAR(MAX), 
@IsDeletable BIT,
@IsGi BIT,
@AnswerOption AnswerOption READONLY,
@ReturnVal INT OUTPUT -- Output paramerter return value of operation
)
AS
BEGIN
BEGIN TRY	
-- INSERT QUERY
		IF (@Operation = 1)
		BEGIN
		IF EXISTS(SELECT QuestionId FROM tblQuestion  WHERE Question = @Question AND CenterTypeId=@CenterTypeId)
		BEGIN
			SET @ReturnVal = -1;--record already exist
			RETURN @ReturnVal;
		END
		ELSE
		BEGIN
		DECLARE @QuestionIdTemp INT;

			INSERT INTO tblQuestion
			(
			CenterTypeId, 
			CategoryTypeId,
			SubCategoryTyepId,
			Question,
			[Status],
			AnswerTyepId,
			IsDeletable,
			IsGi
			)
	VALUES
			(
                @CenterTypeId ,
                @CategoryTypeId,
                @SubCategoryTypeId ,
                @Question,	                 
                @Status,
                @AnswerTypeId,
                @IsDeletable,
                @IsGi      
			)

SET @QuestionIdTemp = @@IDENTITY

		INSERT INTO tblAnswer
		(
		QuestionId,
		Answer,
		weightage	
		)
		SELECT @QuestionIdTemp,Answer,Weightege FROM @AnswerOption	
 	
END

		IF @@ERROR <>0
		BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
		END
		ELSE
		BEGIN
				SET @ReturnVal = 1; -- If record successfully inserted
				RETURN @ReturnVal;
		END
		END

-- UPDATE QUERY
		IF (@Operation = 2)
		
          BEGIN
					UPDATE tblQuestion SET  
					CenterTypeId=@CenterTypeId,
					CategoryTypeId=@CategoryTypeId,
					SubCategoryTyepId=@SubCategoryTypeId,
					Question=@Question,
					AnswerTyepId=@AnswerTypeId,
					Status=@Status,
					IsDeletable=@IsDeletable,
					IsGi= @IsGi
					WHERE QuestionId = @QuestionId


			DECLARE @i INT = 1;

			WHILE @i <> (Select Count(*) From @AnswerOption)+1
			BEGIN
				UPDATE tblAnswer 
				SET Answer =(SELECT Answer FROM @AnswerOption  WHERE RowId =@i) ,weightage= (SELECT Weightege FROM @AnswerOption  WHERE RowId =@i)
				where AnswerId=(Select AnswerId From @AnswerOption where RowId = @i)
							
				SET @i= @i +1;
			END

END

		IF @@ERROR <>0
		BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
		END
		ELSE
		BEGIN
				SET @ReturnVal = 1; -- Update successfully
				RETURN @ReturnVal;
		END


--DELETE QUERY
		IF (@Operation = 3)
		BEGIN	
				IF NOT EXISTS(SELECT QuestionId FROM  tblQuestion WHERE QuestionId=@QuestionId AND CenterTypeId=@CenterTypeId)
		BEGIN
				SET @ReturnVal = -1;-- record not found
				RETURN @ReturnVal;
		END
		ELSE
				BEGIN
				DELETE tblAnswer WHERE QuestionId=@QuestionId 
				DELETE tblQuestion WHERE  QuestionId = @QuestionId AND IsDeletable=1 AND IsGi=0 


		END

		IF @@ERROR <>0
		BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
		END
		ELSE
	BEGIN
SET @ReturnVal = 1; -- delete successfully
RETURN @ReturnVal;
END	
END
END TRY

BEGIN CATCH
SET @ReturnVal = -3;
RETURN @ReturnVal; 
END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Result]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	07/12/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Modify_Result
-- ======================================================================

CREATE PROC [dbo].[csp_Modify_Result]
	(
		@SurveyId INT,
		@MaxScore INT,
		@ScoreObtain INT,
		@Percentage NUMERIC(18,2),
		@Grade NVARCHAR,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	

			IF EXISTS(SELECT ResultId FROM tblResult  WHERE SurveyId = @SurveyId)
				BEGIN				
					UPDATE tblResult SET 
					SurveyId = @SurveyId, 
					MaxScore = @MaxScore,
					ScoreObtain = @ScoreObtain,
					Percentage = @Percentage,
					Grade = @Grade
					WHERE SurveyId = @SurveyId					 
				END
			ELSE
				BEGIN	
					INSERT INTO tblResult
					(
						SurveyId, 
						MaxScore,
						ScoreObtain,
						Percentage,
						Grade
					)
					VALUES
					(
						@SurveyId, 
						@MaxScore,
						@ScoreObtain,
						@Percentage,
						@Grade
					)
				END								
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END		
	END TRY
	BEGIN CATCH
	SET @ReturnVal = -3;
	RETURN @ReturnVal; 
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Result_MOQAName]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	07/12/2014
-- Description	:	 Update Result Table Data
-- Used For		:	 Updat Result Table Data
-- Example		:	csp_Modify_Result_MOQAName 1,'parth',2,''
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_Result_MOQAName]
(
		@SurveyId INT,
		@ResultMOICMoName nvarchar(200),
		@ResultQATeamLeaderId INT,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
)
AS
BEGIN
	BEGIN TRY	
	-- UPDATE QUERY
	BEGIN
					UPDATE tblResult SET ResultMOICName = @ResultMOICMoName,
					ResultQATeamLeaderId = @ResultQATeamLeaderId 
					WHERE SurveyId=@SurveyId 
				
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_ReviewRecordSurveyAnswer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Yograj Sulakhe
-- Create date	:	31/07/2014
-- Description	:	Insert, Update, Delete Question
-- Used For		:	Insert, Update, Delete  Question
-- Example		:	csp_Modify_SurveyAnswer 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_ReviewRecordSurveyAnswer]
	(
		@SurveyId INT=NULL,
		@CategoryTypeId INT,
		@ReviewRecordAnswer ReviewRecordAnswer READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
		
	)
AS

 
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	
				IF EXISTS( SELECT ReviewRecordId FROM tblRevievRecord WHERE CategoryTypeId=@CategoryTypeId AND SurveyId=@SurveyId )
	             BEGIN 
	              DELETE FROM tblRevievRecord WHERE CategoryTypeId=@CategoryTypeId AND SurveyId=@SurveyId
	             END
	        
	            INSERT INTO tblRevievRecord
	            (
	             QuestionId,
	             SurveyId,
	             CategoryTypeId,
	             LastThreeMonthPerformance
	            )
	            SELECT 
	            QuestionId,
	            @SurveyId,
	            @CategoryTypeId,
	            LastThreeMonthPerformance
	            FROM @ReviewRecordAnswer
	
	
				IF EXISTS(SELECT SurveyAnswerId FROM tblSurveyAnswer WHERE SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId)
				BEGIN
					DELETE FROM tblSurveyAnswer WHERE  SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId AND IsGi='1'
				END
				
				INSERT INTO tblSurveyAnswer
				(
					IsGi,
					SurveyId,
					CategoryTypeId,
					QuestionId,
					weightage
							
				)
				 SELECT 
				 1,
				 @SurveyId,
				 @CategoryTypeId,
				 QuestionId,
				 Weightage FROM @ReviewRecordAnswer
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
	END TRY
    BEGIN CATCH
    SET @ReturnVal = -3;
	RETURN @ReturnVal; 
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Role]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	27/11/2014
-- Description	:	Insert, Update, Delete Qualification Table Data
-- Used For		:	Insert, Update, Delete Qualification Table Data
-- Example		:	csp_Modify_Role 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_Role]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@RoleId INT,
		@RoleName NVARCHAR(200),
		@Description NVARCHAR(MAX),		
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT RoleId  FROM tblRoleMaster WHERE RoleName=@RoleName)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblRoleMaster
					(
						RoleName,
						Description
					)
					VALUES
					(
						@RoleName,
						@Description		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT RoleId  FROM  tblRoleMaster WHERE RoleName=@RoleName AND RoleId<>@RoleId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblRoleMaster SET RoleName=@RoleName,Description=@Description WHERE RoleId=@RoleId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT RoleId  FROM  tblRoleMaster WHERE RoleName=RoleName)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblRoleMaster WHERE RoleId=@RoleId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_RoleRight]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	24/09/2014
-- Description	:	Insert, Update, Delete Role & Right Table Data
-- Used For		:	Insert, Update, Delete Role & Right Table Data
-- Example		:	csp_Modify_RoleRight 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_RoleRight]
	(
		@RoleRight RoleRight READONLY,		
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
		 IF EXISTS(SELECT RoleId FROM tblModuleAccess WHERE RoleId in (SELECT RoleId FROM @RoleRight)) 
			BEGIN
				DELETE FROM tblModuleAccess WHERE RoleId IN (SELECT RoleId FROM @RoleRight)
				INSERT INTO tblModuleAccess
					(
						RoleId,
						ModuleId,
						[View],
						[Add],
						[Update],
						[Delete]
					) 
				SELECT RoleId,ModuleId,[View],[Add],[Update],[Delete] FROM @RoleRight
			END 
		ELSE    
			BEGIN    
				INSERT INTO tblModuleAccess
					(
						RoleId,
						ModuleId,
						[View],
						[Add],[Update],
						[Delete]
					) 
				SELECT RoleId,ModuleId,[View],[Add],[Update],[Delete] FROM @RoleRight
			END
		
		IF @@ERROR <>0    
			BEGIN    
				SET @ReturnVal = -2; -- if error occur    
				RETURN @ReturnVal;     
			END    
		ELSE    
			BEGIN    
				SET @ReturnVal = 1; -- If record successfully inserted     
				RETURN @ReturnVal;
			END    
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SMSEmailPrivilege]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Yograj sulakhe
-- Create date	:	14/11/2014
-- Description	:	Modify SMS Email Privilege Data
-- Used For		:	Modify SMS Email Privilege Data
-- Example		:	csp_Modify_SMSEmailPrivilege
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_SMSEmailPrivilege]
	(
		@SMSEmailPrivilege SMSEmailPrivilege READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY

	UPDATE tblSMSEmailPrivilegeMaster 
	SET	SMS=S1.SMS,
		Email=S1.Email
	FROM tblSMSEmailPrivilegeMaster S
	INNER JOIN @SMSEmailPrivilege S1 ON S.SMSEmailPrivilegeId=S1.SMSEmailPrivilegeId

	IF @@ERROR <>0
		BEGIN
		SET @ReturnVal = -2; -- if error occur
		RETURN @ReturnVal; 
		END
	ELSE
		BEGIN
			SET @ReturnVal = 1; -- update successfully
			RETURN @ReturnVal;
		END			
	
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SMSLog]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Abhinandan Patil
-- Create date	:	06/11/2014
-- Description	:	Insert, Update, Delete City Table Data
-- Used For		:	Insert, Update, Delete City Table Data
-- Example		:	csp_Modify_SMSLog
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_SMSLog]
	(
		@Action NVARCHAR(MAX)
	)
AS
BEGIN
	BEGIN TRY	
		
	INSERT INTO tblSMSLog
	(
		Action,
		Timestamp
	)
	VALUES
	(
		@Action,
		GETDATE()
	)	
	
	DELETE FROM tblSMSLog WHERE Timestamp < DATEADD(DAY, -7, GETDATE())
				
	END TRY	
	BEGIN CATCH		
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SMSQueue]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Abhinandan Patil
-- Create date	:	17/09/2014
-- Description	:	Insert, Update, Delete SMS Queue Table Data
-- Used For		:	Insert, Update, Delete SMS Queue Table Data
-- Example		:	csp_Modify_SMSQueue
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_SMSQueue]
	(		
		@SMSQueueId INT,
		@Response NVARCHAR(100),
		@DeliveryStatus NVARCHAR(100),		
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	
	UPDATE tblSMSQueue SET 
		IsSend=1,
		DeliveryStatus=@DeliveryStatus,
		Response=@Response
	WHERE SMSQueueId=@SMSQueueId


		
	IF @@ERROR <>0
		BEGIN
			SET @ReturnVal = -2; -- if error occur
			RETURN @ReturnVal; 
		END
	ELSE
		BEGIN
			SET @ReturnVal = 1; -- If record successfully inserted 
			RETURN @ReturnVal;
		END

	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END


GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_StaffRespondents]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	07/12/2014
-- Description	:	Insert, Update, Delete StaffRespondents Table Data
-- Used For		:	Insert, Update, Delete StaffRespondents Table Data
-- Example		:	csp_Modify_StaffRespondents 
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_StaffRespondents]
	(
		@SurveyId INT,
		@StaffRespondent StaffRespondent READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- UPDATE QUERY
	BEGIN
			IF EXISTS(SELECT StaffRespondentId  FROM  tblStaffRespondent WHERE SurveyId=@SurveyId)
				BEGIN

					DELETE FROM tblStaffRespondent WHERE SurveyId=@SurveyId	

				END
				
		  INSERT INTO tblStaffRespondent
		  (
			SurveyId,
			UserName,
			DesignationId,
			QualificationId,
			MobNo		
		  )
		    SELECT 
			@SurveyId,
			UserName,
			DesignationId,
			QualificationId,
			MobNo
			FROM @StaffRespondent

			EXEC csp_Modify_SurveyStatus @SurveyId 

		IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_StaffRespondentsDQAGMembers]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	07/12/2014
-- Description	:	Insert, Update, Delete User Table Data
-- Used For		:	Insert, Update, Delete User Table Data
-- Example		:	csp_Modify_StaffRespondentsDQAGMembers 
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_StaffRespondentsDQAGMembers]
	(
		@SurveyId INT,
		@StaffRespondent StaffRespondent READONLY,
		@DQAG DQAG READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- UPDATE QUERY
	BEGIN
			IF EXISTS(SELECT StaffRespondentId  FROM  tblStaffRespondent WHERE SurveyId=@SurveyId)
				BEGIN

					DELETE FROM tblDQAG WHERE SurveyId=@SurveyId

					DELETE FROM tblStaffRespondent WHERE SurveyId=@SurveyId	

				END
				
		  INSERT INTO tblStaffRespondent
		  (
			SurveyId,
			UserName,
			DesignationId,
			QualificationId,
			MobNo		
		  )
		    SELECT 
			@SurveyId,
			UserName,
			DesignationId,
			QualificationId,
			MobNo
			FROM @StaffRespondent

			EXEC csp_Modify_SurveyStatus @SurveyId 

		INSERT INTO tblDQAG  SELECT @SurveyId,UserId FROM @DQAG
				
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SubCategoryType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- ======================================================================
-- Author		:	Yograj Sulakhe
-- Create date	:	02/12/2014
-- Description	:	Insert, Update, Delete Subcategory Table Data
-- Used For		:	Insert, Update, Delete Subcategory Table Data
-- Example		:	csp_Modify_Taluka 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_SubCategoryType]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@SubCategoryTypeId INT,
		@CategoryTypeId INT,
		@SubCategoryType NVARCHAR(200),
		@Description NVARCHAR(200),	
		@IsOptional BIT,	
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT SubCategoryTypeId FROM  tblSubCategoryType WHERE SubCategoryType=@SubCategoryType AND CategoryTypeId=@CategoryTypeId)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblSubCategoryType
					(
						CategoryTypeId,
						SubCategoryType,
						Description,
						IsOptional
					)
					VALUES
					(
						@CategoryTypeId,
						@SubCategoryType,
						@Description,
						@IsOptional		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT SubCategoryTypeId FROM  tblSubCategoryType WHERE  SubCategoryType=@SubCategoryType AND CategoryTypeId=@CategoryTypeId AND SubCategoryTypeId<>@SubCategoryTypeId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblSubCategoryType SET  
					CategoryTypeId=@CategoryTypeId,
					SubCategoryType=@SubCategoryType,
					IsOptional = @IsOptional,
					Description=@Description 
					WHERE SubCategoryTypeId=@SubCategoryTypeId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT SubCategoryTypeId  FROM tblSubCategoryType WHERE SubCategoryTypeId=@SubCategoryTypeId)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblSubCategoryType WHERE SubCategoryTypeId=@SubCategoryTypeId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Survey_GeneralInformation]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	29/11/2014
-- Description	:	Insert, Update, Delete Survey General Information Table Data
-- Used For		:	Insert, Update, Delete Survey General Information Table Data
-- Example		:	csp_Modify_Survey_GeneralInformation 1,0,14,'12-Dec-14','3:00 AM','3:00 AM'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_Survey_GeneralInformation]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@SurveyId INT,
		@CentreId INT,	
		@NameofMO NVARCHAR(200),
		@MobNoofMO NVARCHAR(50),
		@Email NVARCHAR(50),
		@TelephoneNo NVARCHAR(50),
		@VisitDate DATETIME,
		@VisitRound NVARCHAR(50),
		@PreviousVisitDate DATETIME,
		@PreviousVisitScore NUMERIC(18,2),
		@SubCentresNo NVARCHAR(50),	
		@PopulationCovered NVARCHAR(50),
		@IPHSStatus BIT,
		@TwoFourSevenStatus BIT,
		@DeliveryPoint BIT,
		@Distance NUMERIC(18,2),
		@VisitStartTime DATETIME,
		@VisitEndTime DATETIME,
		@TotalTime NVARCHAR(50),
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
		    DECLARE @SurveyIdTemp INT

			IF EXISTS(SELECT SurveyId FROM tblSurvey WHERE VisitDate = @VisitDate AND CentreId = @CentreId)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblSurvey
					(					
						CentreId,
						NameofMO,
						MobNoofMO,
						Email,
						TelephoneNo,	
						VisitDate,
						VisitRound,
						PreviousVisitDate,
						PreviousVisitScore,
						SubCentresNo,	
						PopulationCovered,
						IPHSStatus,
						[247Status],
						DeliveryPoint,
						Distance,
						VisitStartTime,
						VisitEndTime,
						TotalTime,
						Status,
						IsComplete
					)
					VALUES
					(					
						@CentreId,
						@NameofMO,
						@MobNoofMO,
						@Email,
						@TelephoneNo,	
						@VisitDate,
						@VisitRound,
						@PreviousVisitDate,
						@PreviousVisitScore,
						@SubCentresNo,	
						@PopulationCovered,
						@IPHSStatus,
						@TwoFourSevenStatus,
						@DeliveryPoint,
						@Distance,
						@VisitStartTime,
						@VisitEndTime,
						@TotalTime,
						0,
						0
					)
													
				END
		     
			

			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					-- If record successfully inserted 
					 SET @ReturnVal = @@IDENTITY;
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT SurveyId FROM tblSurvey WHERE VisitDate = @VisitDate AND CentreId = @CentreId AND SurveyId <> @SurveyId) 
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblSurvey SET
						CentreId=@CentreId,	
						NameofMO=@NameofMO,
						MobNoofMO=@MobNoofMO,
						Email=@Email,
						TelephoneNo=@TelephoneNo,
						VisitDate=@VisitDate,
						VisitRound=@VisitRound,
						PreviousVisitDate=@PreviousVisitDate,
						PreviousVisitScore=@PreviousVisitScore,
						SubCentresNo=@SubCentresNo,	
						PopulationCovered=@PopulationCovered,
						IPHSStatus=@IPHSStatus,
						[247Status]=@TwoFourSevenStatus,
						DeliveryPoint=@DeliveryPoint,
						Distance=@Distance,
						VisitStartTime=@VisitStartTime,
						VisitEndTime=@VisitEndTime,
						TotalTime=@TotalTime
						WHERE SurveyId=@SurveyId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT SurveyId  FROM  tblSurvey WHERE SurveyId = @SurveyId)

				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE FROM tblSurvey WHERE SurveyId = @SurveyId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SurveyActionPlan]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Ajay Birari
-- Create date	:	07/12/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Modify_SurveyActionPlan
-- ======================================================================

CREATE PROC [dbo].[csp_Modify_SurveyActionPlan]
	(
		@SurveyId INT,
		@ActionPlan ActionPlan READONLY,
		@ActionPlanMOName NVARCHAR(200),
		@ActionPlanQATeamLeadId INT,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	--BEGIN TRY	

			IF EXISTS(SELECT SurveyId FROM tblActionPlan  WHERE SurveyId = @SurveyId)
				BEGIN
					DELETE tblActionPlan WHERE SurveyId = @SurveyId
				END
					
			INSERT INTO tblActionPlan
					(
						SurveyId,
						CategoryTypeId, 
						SubCategoryTypeId,
						Problem,
						Solution,	
						PHCLevel,
						DistrictLevel,
						StateLevel,
						DueDate,
						ResponsiblePerson
					)
					SELECT 
						@SurveyId,
						CategoryTypeId,
						SubCategoryTypeId,
						Problem,
						Solution,	
						PHCLevel,
						DistrictLevel,
						StateLevel,
						DueDate,
						ResponsiblePerson		
					FROM @ActionPlan					

			UPDATE tblResult SET ActionPlanMOICName=@ActionPlanMOName,ActionQATeamLeaderId=@ActionPlanQATeamLeadId WHERE SurveyId=@SurveyId 

					EXEC csp_Modify_SurveyStatus @SurveyId 

			UPDATE tblSurvey SET IsComplete=1 WHERE SurveyId = @SurveyId
			UPDATE tblSurvey SET Status = 1
						WHERE SurveyId =@SurveyId
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		
	--END TRY
	--BEGIN CATCH
	SET @ReturnVal = -3;
	RETURN @ReturnVal; 
	--END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SurveyActionPlanProgress]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	29/11/2014
-- Description	:	Insert, Update, Delete Centre Table Data
-- Used For		:	Insert, Update, Delete Centre Table Data
-- Example		:	csp_Modify_SurveyActionPlanProgress
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_SurveyActionPlanProgress]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@ActionPlanProgressId INT,		
		@ActionPlanId INT,
		@SurveyId INT,
		@ActionTakenDate DATETIME,
		@ActualResponsiblePerson NVARCHAR(MAX),	
		@ActionTaken NVARCHAR(MAX),	
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT ActionPlanProgressId  FROM  tblActionPlanProgress WHERE ActionTakenDate=@ActionTakenDate AND  
ActionPlanId=@ActionPlanId)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblActionPlanProgress
					(	
					[SurveyId],
					[ActionPlanId],
					[ActionTakenDate],
					[ActualResponsiblePerson],
					[ActionTaken]
			        )
					VALUES
					(	
					    @SurveyId ,				
						@ActionPlanId ,						
						@ActionTakenDate,
						@ActualResponsiblePerson,	
						@ActionTaken	
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT ActionPlanProgressId  FROM  tblActionPlanProgress WHERE ActionPlanId=@ActionPlanId and ActionTakenDate = @ActionTakenDate and ActionPlanProgressId<>@ActionPlanProgressId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblActionPlanProgress SET
					[SurveyId] = @SurveyId,
					[ActionPlanId] =@ActionPlanId,
					[ActionTakenDate] = @ActionTakenDate,
					[ActualResponsiblePerson]=@ActualResponsiblePerson,
					[ActionTaken] =@ActionTaken
					 WHERE ActionPlanProgressId = @ActionPlanProgressId
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT ActionPlanProgressId  FROM  tblActionPlanProgress  WHERE ActionPlanProgressId = @ActionPlanProgressId)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblActionPlanProgress WHERE ActionPlanProgressId = @ActionPlanProgressId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SurveyAnswer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Yograj Sulakhe
-- Create date	:	31/07/2014
-- Description	:	Insert, Update, Delete Question
-- Used For		:	Insert, Update, Delete  Question
-- Example		:	csp_Modify_SurveyAnswer 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_SurveyAnswer]
	(
		@SurveyId INT=NULL,
		@CategoryTypeId INT,
		@SurveyAnswer SurveyAnswer READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
				IF EXISTS(SELECT SurveyAnswerId FROM tblSurveyAnswer WHERE SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId)
				BEGIN
					DELETE FROM tblSurveyAnswer WHERE  SurveyId= @SurveyId  AND CategoryTypeId=@CategoryTypeId 
				END
				
				INSERT INTO tblSurveyAnswer
				(
					SurveyId,
					CategoryTypeId,
					QuestionId,
					AnswerId,
					weightage		
				)
				 SELECT 
				 @SurveyId,
				 @CategoryTypeId,
				 QuestionId,
				 AnswerId,
				 weightage =( SELECT weightage FROM tblAnswer WHERE AnswerId = S.AnswerId )		 
				 FROM @SurveyAnswer S

				 EXEC csp_Modify_SurveyStatus @SurveyId 
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
	END TRY
    BEGIN CATCH
    SET @ReturnVal = -3;
	RETURN @ReturnVal; 
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SurveyHRProfile]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	07/12/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Modify_HRProfile
-- ======================================================================

CREATE PROC [dbo].[csp_Modify_SurveyHRProfile]
	(
		@SurveyId INT,
		@HrProfile HrProfile READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	

			IF EXISTS(SELECT SurveyId FROM tblHRProfile  WHERE SurveyId = @SurveyId )
				BEGIN
					DELETE tblHRProfile WHERE SurveyId = @SurveyId
				END
					
			INSERT INTO tblHRProfile
					(
						SurveyId, 
						DesignationId,
						PostSanctionedNo,
						RegularNo,
						Contractual,
						Remark
					)
					SELECT 
					@SurveyId,
					DesignationId,
					PostSanctionedNo,
					RegularNo,
					Contractual,
					Remark 
					FROM @HrProfile					

					EXEC csp_Modify_SurveyStatus @SurveyId 
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		
	END TRY
	BEGIN CATCH
	SET @ReturnVal = -3;
	RETURN @ReturnVal; 
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SurveySchedule]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	29/11/2014
-- Description	:	Insert, Update, Delete Survey Schedule Table Data
-- Used For		:	Insert, Update, Delete Survey Schedule Table Data
-- Example		:	csp_Modify_SurveySchedule 1,0,14,'12-Dec-14','3:00 AM','3:00 AM'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_SurveySchedule]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@SurveyScheduleId INT,
		@CentreId INT,	
		@SurveyDate DATETIME,
		@SurveyStartTime DATETIME,
		@SurveyEndTime DATETIME,
		@SurveyPeople SurveyPeople READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT SurveyScheduleId FROM tblSurveySchedule WHERE SurveyDate = @SurveyDate AND CentreId = @CentreId)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblSurveySchedule
					(					
						CentreId,
						SurveyDate,
						SurveyStartTime,
						SurveyEndTime
					)
					VALUES
					(					
						@CentreId,
						@SurveyDate,
						@SurveyStartTime,
						@SurveyEndTime
					)
					
					INSERT INTO tblSurveyPeople  
					SELECT @@IDENTITY,
					UserId 
					FROM @SurveyPeople
									
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT SurveyScheduleId FROM tblSurveySchedule WHERE SurveyDate = @SurveyDate AND CentreId = @CentreId AND SurveyScheduleId <> @SurveyScheduleId) 
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblSurveySchedule SET
					CentreId =@CentreId,
					SurveyDate = @SurveyDate,
					SurveyStartTime = @SurveyStartTime,
					SurveyEndTime= @SurveyEndTime
					WHERE SurveyScheduleId = @SurveyScheduleId
						DELETE FROM tblSurveyPeople WHERE SurveyScheduleId=@SurveyScheduleId;
						INSERT INTO tblSurveyPeople  SELECT @SurveyScheduleId,UserId FROM @SurveyPeople;
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT SurveyScheduleId  FROM  tblSurveySchedule WHERE SurveyScheduleId = @SurveyScheduleId)

				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE FROM tblSurveyPeople WHERE SurveyScheduleId = @SurveyScheduleId
					DELETE tblSurveySchedule WHERE SurveyScheduleId = @SurveyScheduleId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SurveySkillTrainingStatus]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	07/12/2014
-- Description	:	Insert, Update 
-- Used For		:	Insert, Update
-- Example		:	csp_Modify_SurveySkillTrainingStatus
-- ======================================================================

CREATE PROC [dbo].[csp_Modify_SurveySkillTrainingStatus]
	(
		@SurveyId INT,
		@SkillTrainingDetail SkillTrainingDetail READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	

			IF EXISTS(SELECT SurveyId FROM tblSkillTrainingStatus  WHERE SurveyId = @SurveyId)
				BEGIN
					DELETE tblSkillTrainingStatus WHERE SurveyId =@SurveyId
				END
					
			INSERT INTO tblSkillTrainingStatus
					(
						SurveyId, 
						StaffName,
						DesignationId,
						QualificationId,	
						Minilap,
						NSV,
						MTP,
						BEMOC,
						EMOC,
						STIRTI,
						IUD,
						LSAS,
						IMEP,
						CTC,
						NSSK,
						RI,
						FIMNCI,
						SBA,
						IYCF,
						Other
					)
					SELECT 
					@SurveyId,
					StaffName,
					DesignationId,
					QualificationId,	
					Minilap,
					NSV,
					MTP,
					BEMOC,
					EMOC,
					STIRTI,
					IUD,
					LSAS,
					IMEP,
					CTC,
					NSSK,
					RI,
					FIMNCI,
					SBA,
					IYCF,
					Other					
					FROM @SkillTrainingDetail				

					EXEC csp_Modify_SurveyStatus @SurveyId 	
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		
	END TRY
	BEGIN CATCH
	SET @ReturnVal = -3;
	RETURN @ReturnVal; 
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_SurveyStatus]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================================
-- Author		:	Mahesh Warambhe
-- Create date	:	29/11/2014
-- Description	:	Update status
---Update, Delete Survey General Information Table Data
-- Example		:	csp_Modify_SurveyStatus 1
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_SurveyStatus]
	(
		@SurveyId INT
	)
AS
BEGIN
	BEGIN TRY	
	
	
IF EXISTS(SELECT SurveyId FROM tblStaffRespondent WHERE SurveyId = @SurveyId)
BEGIN
	IF EXISTS(SELECT SurveyId FROM tblDQAG WHERE SurveyId = @SurveyId)
	BEGIN
			  IF EXISTS(SELECT SurveyId FROM tblHRProfile WHERE SurveyId = @SurveyId)
			BEGIN

			      IF EXISTS(SELECT SurveyId FROM tblSkillTrainingStatus WHERE SurveyId = @SurveyId)
				BEGIN

				     IF EXISTS(SELECT SurveyId FROM tblSurveyAnswer WHERE SurveyId = @SurveyId)
				BEGIN
							 IF EXISTS(SELECT SurveyId FROM tblActionPlan WHERE SurveyId = @SurveyId)
						BEGIN

						UPDATE tblSurvey SET Status = 1
						WHERE SurveyId =@SurveyId
						END

				END


				END

			END


	END
END

				
	

	END TRY 
	BEGIN CATCH	
	
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_Taluka]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ======================================================================
-- Author		:	Yograj Sulakhe
-- Create date	:	27/11/2014
-- Description	:	Insert, Update, Delete Taluka Table Data
-- Used For		:	Insert, Update, Delete Taluka Table Data
-- Example		:	csp_Modify_Taluka 1,1,'Test','Test'
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_Taluka]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@TalukaId INT,
		@DistrictId INT,
		@TalukaName NVARCHAR(200),
		@Description NVARCHAR(300),		
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT TalukaId FROM  tblTaluka WHERE TalukaName=@TalukaName)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblTaluka
					(
					DistrictId,
					TalukaName,
					Description
					)
					VALUES
					(
						@DistrictId ,
						@TalukaName,
						@Description 		
					)				
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT TalukaId FROM  tblTaluka WHERE TalukaName=@TalukaName AND TalukaId<>@TalukaId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblTaluka SET DistrictId=@DistrictId,TalukaName=@TalukaName,Description=@Description  WHERE TalukaId=@TalukaId 
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT TalukaId FROM tblTaluka WHERE TalukaId=@TalukaId)
				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE tblTaluka WHERE TalukaId=@TalukaId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END





GO
/****** Object:  StoredProcedure [dbo].[csp_Modify_User]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================
-- Author		:	Parshwanath Chougule
-- Create date	:	29/11/2014
-- Description	:	Insert, Update, Delete User Table Data
-- Used For		:	Insert, Update, Delete User Table Data
-- Example		:	csp_Modify_User 1,0,59,1,0,2,'Test','Test','p',p','p',0,'p',0
-- ======================================================================
CREATE PROC [dbo].[csp_Modify_User]
	(
		@Operation INT, -- operation that is 1 = Insert,2=Update,3=Delete
		@UserId INT,		
		@QualificationId INT,
		@DesignationId INT,
		@ReportingManagerId INT=NULL,
		@RoleId INT,
		@UserName NVARCHAR(50),
		@Password NVARCHAR(50),
		@FirstName NVARCHAR(50),
		@MiddleName NVARCHAR(50),
		@LastName NVARCHAR(50),
		@ContactEmail NVARCHAR(200),
		@ContactNumber NVARCHAR(50),
		@UserCentreMapping UserCentreMapping READONLY,
		@ReturnVal INT OUTPUT -- Output paramerter return value of operation
	)
AS
BEGIN
	BEGIN TRY	
	-- INSERT QUERY
	IF (@Operation = 1)
		BEGIN
			IF EXISTS(SELECT UserId  FROM  tblUserMaster WHERE UserName=@UserName)
				BEGIN
					SET @ReturnVal = -1;--record already exist
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN				
					INSERT INTO tblUserMaster
					(					
						ReportingManagerId,
						DesignationId,
						RoleId,
						UserName,
						Password,
						FirstName,
						MiddleName,
						LastName,
						QualificationId,
						ContactNumber,
						ContactEmail
					)
					VALUES
					(					
						@ReportingManagerId,
						@DesignationId,
						@RoleId,
						@UserName,
						@Password,
						@FirstName,
						@MiddleName,
						@LastName,
						@QualificationId,
						@ContactNumber,
						@ContactEmail		
					)
					
					INSERT INTO tblUserCentreMapping  SELECT @@IDENTITY,CentreId FROM @UserCentreMapping
									
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- If record successfully inserted 
					RETURN @ReturnVal;
				END
		END
	
	-- UPDATE QUERY
	IF (@Operation = 2)
		BEGIN	
			IF EXISTS(SELECT UserId FROM tblUserMaster WHERE UserName=@UserName AND UserId<>@UserId)
				BEGIN
					SET @ReturnVal = -1;-- Record already exist you cant insert repeated unit name
					RETURN @ReturnVal;
				END
			ELSE -- , , IsActive
				BEGIN
					UPDATE tblUserMaster SET
					ReportingManagerId = @ReportingManagerId,
						DesignationId = @DesignationId,
						RoleId = @RoleId,
						UserName = @UserName,
						Password = @Password,
						FirstName = @FirstName,
						MiddleName = @MiddleName,
						LastName = @LastName,
						QualificationId = @QualificationId,
						ContactNumber = @ContactNumber,
						ContactEmail = @ContactEmail WHERE UserId=@UserId


						DELETE FROM tblUserCentreMapping WHERE UserId=@UserId;
						INSERT INTO tblUserCentreMapping  SELECT @UserId,CentreId FROM @UserCentreMapping;
				END
		
			IF @@ERROR <>0
				BEGIN
					SET @ReturnVal = -2; -- if error occur
					RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- Update successfully
					RETURN @ReturnVal;
				END
		END
	
	--DELETE QUERY
	IF (@Operation = 3)
		BEGIN	
			IF NOT EXISTS(SELECT UserId  FROM  tblUserMaster WHERE UserId = @UserId)

				BEGIN
					SET @ReturnVal = -1;-- record not found
					RETURN @ReturnVal;
				END
			ELSE
				BEGIN
					DELETE FROM tblUserCentreMapping WHERE UserId=@UserId;
					DELETE tblUserMaster WHERE UserId=@UserId
				END
			
			IF @@ERROR <>0
				BEGIN
				SET @ReturnVal = -2; -- if error occur
				RETURN @ReturnVal; 
				END
			ELSE
				BEGIN
					SET @ReturnVal = 1; -- delete successfully
					RETURN @ReturnVal;
				END			
		END
	END TRY	
	BEGIN CATCH	
	SET @ReturnVal = -3;
	RETURN @ReturnVal;
	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[csp_SectionJComparisonOnMotherCare_ProgrssChart]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--=============================================
-- Author: Mahesh Warambhe
-- Create date: 03/01/2015
-- Description:	To get datatable of  Clinic _RNTCP_ NVBDCP_Progrss Chart
-- Example: csp_SectionJComparisonOnMotherCare_ProgrssChart 4
-- =============================================
CREATE PROC [dbo].[csp_SectionJComparisonOnMotherCare_ProgrssChart]
(
	@CentreId INT   --1.PHC 2.RH 3.SC 4.SDH
)
AS
BEGIN	
	DECLARE @CentreTypeId INT;
	SET @CentreTypeId = (SELECT CentreTypeId FROM tblCentre WHERE CentreId=@CentreId);
	
	IF(@CentreTypeId = 1)  -- PHC
	BEGIN
		SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(297,298,299,303,304)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'MotherCare' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(297,298,299,303,304) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(312,313,315)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ANC' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(312,313,315) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(320)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ChildHealth' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(320) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(321)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'Immunization' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(321) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 
	END
    IF(@CentreTypeId = 2)  -- RH
	BEGIN
		SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(665,666,667,672,673)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'MotherCare' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(665,666,667,672,673) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(680,681,683)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ANC' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(680,681,683) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(688)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ChildHealth' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(688) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(689)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'Immunization' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(689) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 
	END

	IF(@CentreTypeId = 3)  -- SC
	BEGIN
	   	SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1243,1249,1250,1247,1248)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'MotherCare' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1243,1249,1250,1247,1248) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1237,1238,1240)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ANC' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1237,1238,1240) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1252)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ChildHealth' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1252) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1255)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'Immunization' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1255) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 
	END

	IF(@CentreTypeId = 4)  -- SDH
	BEGIN
		SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1197,1198,1199,1204,1205)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'MotherCare' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1197,1198,1199,1204,1205) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1212,1213,1215)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ANC' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1212,1213,1215) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1220)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'ChildHealth' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1220) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 

				UNION

				SELECT 
				CAST(SUM(SA.weightage * 1.0)* 100 /(SELECT SUM(IncreaseBy10PercentOrmore) FROM tblGiAnswer WHERE QuestionId IN(1221)) AS NUMERIC(18,2)) AS Percentage,
				SA.SurveyId,
				CONVERT(NVARCHAR,S.VisitDate,103) AS VisitDate,
				'Immunization' AS Name
				FROM tblSurveyAnswer SA
				INNER JOIN tblSurvey S ON SA.SurveyId=S.SurveyId
				WHERE QuestionId IN(1221) AND SA.SurveyId IN (SELECT TOP(5)surveyId FROM tblSurvey WHERE CentreId=@CentreId ORDER BY VisitDate DESC)
				GROUP BY SA.SurveyId,S.VisitDate 
	END
END

GO
/****** Object:  Table [dbo].[tblActionPlan]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblActionPlan](
	[ActionPlanId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SubCategoryTypeId] [int] NULL,
	[Problem] [nvarchar](max) NULL,
	[Solution] [nvarchar](max) NULL,
	[PHCLevel] [nvarchar](max) NULL,
	[DistrictLevel] [nvarchar](max) NULL,
	[StateLevel] [nvarchar](max) NULL,
	[DueDate] [datetime] NULL,
	[ResponsiblePerson] [nvarchar](max) NULL,
 CONSTRAINT [PK_tblActionPlan] PRIMARY KEY CLUSTERED 
(
	[ActionPlanId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblActionPlanProgress]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblActionPlanProgress](
	[ActionPlanProgressId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[ActionPlanId] [int] NULL,
	[ActionTakenDate] [datetime] NULL,
	[ActualResponsiblePerson] [nvarchar](100) NULL,
	[ActionTaken] [nvarchar](max) NULL,
 CONSTRAINT [PK_tblActionPlanProgress] PRIMARY KEY CLUSTERED 
(
	[ActionPlanProgressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblAnsewerType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblAnsewerType](
	[AnswerTypeId] [int] NOT NULL,
	[AnswerType] [nvarchar](100) NULL,
 CONSTRAINT [PK_AnsewerType] PRIMARY KEY CLUSTERED 
(
	[AnswerTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblAnswer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblAnswer](
	[AnswerId] [int] NOT NULL,
	[QuestionId] [int] NOT NULL,
	[Answer] [nvarchar](200) NULL,
	[weightage] [int] NULL,
 CONSTRAINT [PK_tblAnswer] PRIMARY KEY CLUSTERED 
(
	[AnswerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblCategoryType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblCategoryType](
	[CategoryTypeId] [int] NOT NULL,
	[CategoryType] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL,
	[Prefix] [nvarchar](50) NULL,
	[Instructions] [nvarchar](max) NULL,
	[Indicators] [nvarchar](50) NULL,
	[DisplayName] [nvarchar](100) NULL,
 CONSTRAINT [PK_tblCategory] PRIMARY KEY CLUSTERED 
(
	[CategoryTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblCentre]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblCentre](
	[CentreId] [int] NOT NULL,
	[TalukaId] [int] NULL,
	[CentreTypeId] [int] NULL,
	[Centre] [nvarchar](200) NOT NULL,
	[Address] [nvarchar](max) NULL,
	[ContactPerson] [nvarchar](200) NULL,
	[ContactEmail] [nvarchar](200) NULL,
	[ContactNumber] [nvarchar](50) NULL,
 CONSTRAINT [PK_tblCentre] PRIMARY KEY CLUSTERED 
(
	[CentreId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblCentreType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblCentreType](
	[CentreTypeId] [int] NOT NULL,
	[CentreType] [nvarchar](200) NULL,
	[Description] [nvarchar](300) NULL,
	[IndicatorsForOIResult] [nvarchar](100) NULL,
 CONSTRAINT [PK_tblCentreType1] PRIMARY KEY CLUSTERED 
(
	[CentreTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblDesignationMaster]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblDesignationMaster](
	[DesignationId] [int] NOT NULL,
	[Designation] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL,
 CONSTRAINT [PK_tblDesignationMaster] PRIMARY KEY CLUSTERED 
(
	[DesignationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblDistrict]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblDistrict](
	[DistrictId] [int] NOT NULL,
	[DistrictName] [nvarchar](200) NULL,
	[Description] [nvarchar](300) NULL,
 CONSTRAINT [PK_tblDistrict] PRIMARY KEY CLUSTERED 
(
	[DistrictId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblDQAG]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblDQAG](
	[DQAGId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[UserId] [int] NULL,
 CONSTRAINT [PK_tblDQAG] PRIMARY KEY CLUSTERED 
(
	[DQAGId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblExceptionLogItems]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
CREATE TABLE [dbo].[tblExceptionLogItems](
	[EventId] [int] IDENTITY(1,1) NOT NULL,
	[LogDateTime] [datetime] NULL,
	[Source] [char](100) NULL,
	[Message] [varchar](1000) NULL,
	[QueryString] [varchar](2000) NULL,
	[TargetSite] [varchar](300) NULL,
	[StackTrace] [varchar](4000) NULL,
	[ServerName] [varchar](250) NULL,
	[RequestURL] [varchar](300) NULL,
	[UserAgent] [varchar](300) NULL,
	[UserIP] [varchar](300) NULL,
	[UserAuthentication] [varchar](300) NULL,
	[UserName] [varchar](300) NULL,
 CONSTRAINT [PK_tblExceptionLogItems] PRIMARY KEY CLUSTERED 
(
	[EventId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGiAnswer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblGiAnswer](
	[GiAnswerId] [int] NOT NULL,
	[QuestionId] [int] NULL,
	[ScoreRange-10TO+10] [int] NULL,
	[DecreaseBy10PercentOrMore] [int] NULL,
	[IncreaseBy10PercentOrmore] [int] NULL,
 CONSTRAINT [PK_tblGiAnswerWeightage] PRIMARY KEY CLUSTERED 
(
	[GiAnswerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblGIResult]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblGIResult](
	[GIResultId] [int] IDENTITY(1,1) NOT NULL,
	[QuestionId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SurveyId] [int] NULL,
	[ThreeMonthRecordA] [int] NULL,
	[ThreeMonthRecordB] [int] NULL,
	[Percentage] [float] NULL,
 CONSTRAINT [PK_tblGIResult] PRIMARY KEY CLUSTERED 
(
	[GIResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblGrade]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblGrade](
	[GradeId] [int] NOT NULL,
	[MinScore] [numeric](18, 2) NULL,
	[MaxScore] [numeric](18, 2) NULL,
	[Grade] [nvarchar](50) NULL,
 CONSTRAINT [PK_tblGrade] PRIMARY KEY CLUSTERED 
(
	[GradeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblHRProfile]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblHRProfile](
	[HRProfileId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[DesignationId] [int] NULL,
	[PostSanctionedNo] [int] NULL,
	[RegularNo] [int] NULL,
	[Contractual] [int] NULL,
	[Remark] [nvarchar](max) NULL,
 CONSTRAINT [PK_tblHRProfile] PRIMARY KEY CLUSTERED 
(
	[HRProfileId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblIndicatorMaster]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblIndicatorMaster](
	[IndicatorId] [int] NOT NULL,
	[CategoryTypeId] [int] NULL,
	[SubCategoryTypeId] [int] NULL,
	[CentreTypeId] [int] NULL,
	[DisplayName] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblModuleAccess]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblModuleAccess](
	[ModuleAccessId] [int] NOT NULL,
	[RoleId] [int] NULL,
	[ModuleId] [int] NULL,
	[View] [bit] NULL,
	[Add] [bit] NULL,
	[Update] [bit] NULL,
	[Delete] [bit] NULL,
 CONSTRAINT [PK_tblModuleAccess] PRIMARY KEY CLUSTERED 
(
	[ModuleAccessId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblModuleMaster]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblModuleMaster](
	[ModuleId] [int] NOT NULL,
	[ModuleName] [nvarchar](max) NULL,
	[ParentId] [int] NULL,
	[ModuleTypeId] [int] NULL,
	[ModuleIdentifyId] [int] NULL,
 CONSTRAINT [PK_tblModuleMaster] PRIMARY KEY CLUSTERED 
(
	[ModuleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblQualification]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblQualification](
	[QualificationId] [int] NOT NULL,
	[Qualification] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL,
 CONSTRAINT [PK_tblQualification] PRIMARY KEY CLUSTERED 
(
	[QualificationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblQuestion]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblQuestion](
	[QuestionId] [int] NOT NULL,
	[CenterTypeId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[SubCategoryTyepId] [int] NULL,
	[Question] [nvarchar](max) NULL,
	[Status] [bit] NULL,
	[AnswerTyepId] [int] NULL,
	[IsDeletable] [bit] NULL,
	[IsGi] [bit] NULL,
	[ReviewRecordNo] [int] NULL,
 CONSTRAINT [PK_tblQuestion] PRIMARY KEY CLUSTERED 
(
	[QuestionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblResult]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblResult](
	[ResultId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[MaxScore] [int] NULL,
	[ScoreObtain] [int] NULL,
	[Percentage] [numeric](18, 2) NULL,
	[Grade] [nvarchar](50) NULL,
	[ResultMOICName] [nvarchar](200) NULL,
	[ResultQATeamLeaderId] [int] NULL,
	[GiMOICName] [nvarchar](200) NULL,
	[GiQATeamLeaderId] [int] NULL,
	[ActionPlanMOICName] [nvarchar](200) NULL,
	[ActionQATeamLeaderId] [int] NULL,
 CONSTRAINT [PK_tblResult] PRIMARY KEY CLUSTERED 
(
	[ResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblRevievRecord]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblRevievRecord](
	[ReviewRecordId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[QuestionId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[LastThreeMonthPerformance] [int] NULL,
 CONSTRAINT [PK_tblRevievRecord] PRIMARY KEY CLUSTERED 
(
	[ReviewRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblRoleMaster]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblRoleMaster](
	[RoleId] [int] NOT NULL,
	[RoleName] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL,
 CONSTRAINT [PK_tblRoleMaster] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSkillTrainingStatus]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSkillTrainingStatus](
	[SkillTrainingStatusId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[StaffName] [nvarchar](max) NULL,
	[DesignationId] [int] NULL,
	[QualificationId] [int] NULL,
	[Minilap] [nvarchar](50) NULL,
	[NSV] [nvarchar](50) NULL,
	[MTP] [nvarchar](50) NULL,
	[BEMOC] [nvarchar](50) NULL,
	[EMOC] [nvarchar](50) NULL,
	[STIRTI] [nvarchar](50) NULL,
	[IUD] [nvarchar](50) NULL,
	[LSAS] [nvarchar](50) NULL,
	[IMEP] [nvarchar](50) NULL,
	[CTC] [nvarchar](50) NULL,
	[NSSK] [nvarchar](50) NULL,
	[RI] [nvarchar](50) NULL,
	[FIMNCI] [nvarchar](50) NULL,
	[SBA] [nvarchar](50) NULL,
	[IYCF] [nvarchar](50) NULL,
	[Other] [nvarchar](50) NULL,
 CONSTRAINT [PK_tblSkillTrainingStatus] PRIMARY KEY CLUSTERED 
(
	[SkillTrainingStatusId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSMSAuthenticationMaster]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSMSAuthenticationMaster](
	[SMSAuthenticationId] [int] NOT NULL,
	[SMSAPIUserId] [nvarchar](50) NULL,
	[SMSAPIPassword] [nvarchar](50) NULL,
	[SenderId] [nvarchar](50) NULL,
 CONSTRAINT [PK_tblSMSAuthenticationMaster] PRIMARY KEY CLUSTERED 
(
	[SMSAuthenticationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSMSLog]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSMSLog](
	[SMSLogId] [int] IDENTITY(1,1) NOT NULL,
	[Action] [nvarchar](max) NULL,
	[Timestamp] [datetime] NULL,
 CONSTRAINT [PK_tblSMSLog] PRIMARY KEY CLUSTERED 
(
	[SMSLogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSMSQueue]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSMSQueue](
	[SMSQueueId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyPeopleId] [int] NULL,
	[ContactNo] [nvarchar](50) NULL,
	[Subject] [nvarchar](max) NULL,
	[IsSend] [bit] NULL,
	[SMSDate] [datetime] NULL,
	[Response] [nvarchar](100) NULL,
	[DeliveryStatus] [nvarchar](100) NULL,
 CONSTRAINT [PK_tblSMSQueue] PRIMARY KEY CLUSTERED 
(
	[SMSQueueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblStaffRespondent]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblStaffRespondent](
	[StaffRespondentId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[UserName] [nvarchar](max) NULL,
	[DesignationId] [int] NULL,
	[QualificationId] [int] NULL,
	[MobNo] [nvarchar](50) NULL,
 CONSTRAINT [PK_tblStaffRespondent] PRIMARY KEY CLUSTERED 
(
	[StaffRespondentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSubCategoryType]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSubCategoryType](
	[SubCategoryTypeId] [int] NOT NULL,
	[CategoryTypeId] [int] NULL,
	[SubCategoryType] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
	[PreFix] [nvarchar](10) NULL,
	[Instructions] [nvarchar](max) NULL,
	[Indicators] [nvarchar](50) NULL,
	[DisplayName] [nvarchar](100) NULL,
	[IsOptional] [bit] NULL,
 CONSTRAINT [PK_tblSubCategory] PRIMARY KEY CLUSTERED 
(
	[SubCategoryTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSurvey]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSurvey](
	[SurveyId] [int] IDENTITY(1,1) NOT NULL,
	[CentreId] [int] NULL,
	[NameofMO] [nvarchar](200) NULL,
	[MobNoofMO] [nvarchar](50) NULL,
	[Email] [nvarchar](50) NULL,
	[TelephoneNo] [nvarchar](50) NULL,
	[VisitDate] [datetime] NULL,
	[VisitRound] [nvarchar](50) NULL,
	[PreviousVisitDate] [datetime] NULL,
	[PreviousVisitScore] [numeric](18, 2) NULL,
	[SubCentresNo] [nvarchar](50) NULL,
	[PopulationCovered] [nvarchar](50) NULL,
	[IPHSStatus] [bit] NULL,
	[247Status] [bit] NULL,
	[DeliveryPoint] [bit] NULL,
	[Distance] [numeric](18, 2) NULL,
	[VisitStartTime] [datetime] NULL,
	[VisitEndTime] [datetime] NULL,
	[TotalTime] [nvarchar](50) NULL,
	[Status] [bit] NULL,
	[IsComplete] [bit] NULL,
 CONSTRAINT [PK_tblSurvey] PRIMARY KEY CLUSTERED 
(
	[SurveyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSurveyAnswer]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSurveyAnswer](
	[SurveyAnswerId] [int] IDENTITY(1,1) NOT NULL,
	[SurveyId] [int] NULL,
	[CategoryTypeId] [int] NULL,
	[QuestionId] [int] NULL,
	[AnswerId] [int] NULL,
	[weightage] [int] NULL,
	[IsGi] [bit] NULL,
 CONSTRAINT [PK_tblSurveyAnswer] PRIMARY KEY CLUSTERED 
(
	[SurveyAnswerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSurveyPeople]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSurveyPeople](
	[SurveyPeopleId] [int] NOT NULL,
	[SurveyScheduleId] [int] NULL,
	[UserId] [int] NULL,
 CONSTRAINT [PK_tblSurveyPeople] PRIMARY KEY CLUSTERED 
(
	[SurveyPeopleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSurveySchedule]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSurveySchedule](
	[SurveyScheduleId] [int] NOT NULL,
	[CentreId] [int] NULL,
	[SurveyDate] [datetime] NULL,
	[SurveyStartTime] [datetime] NULL,
	[SurveyEndTime] [datetime] NULL,
 CONSTRAINT [PK_tblSurveySchedule] PRIMARY KEY CLUSTERED 
(
	[SurveyScheduleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblTaluka]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblTaluka](
	[TalukaId] [int] NOT NULL,
	[DistrictId] [int] NOT NULL,
	[TalukaName] [nvarchar](200) NULL,
	[Description] [nvarchar](300) NULL,
 CONSTRAINT [PK_tblTaluka] PRIMARY KEY CLUSTERED 
(
	[TalukaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblUserCentreMapping]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblUserCentreMapping](
	[UserCentreMappingId] [int] NOT NULL,
	[UserId] [int] NULL,
	[CentreId] [int] NULL,
 CONSTRAINT [PK_tblUserCentreMapping] PRIMARY KEY CLUSTERED 
(
	[UserCentreMappingId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblUserMaster]    Script Date: 1/14/2015 11:19:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblUserMaster](
	[UserId] [int] NOT NULL,
	[ReportingManagerId] [int] NULL,
	[DesignationId] [int] NULL,
	[RoleId] [int] NULL,
	[UserName] [nvarchar](50) NULL,
	[Password] [nvarchar](50) NULL,
	[FirstName] [nvarchar](50) NULL,
	[MiddleName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL,
	[QualificationId] [int] NULL,
	[ContactNumber] [nvarchar](50) NULL,
	[ContactEmail] [nvarchar](200) NULL,
 CONSTRAINT [PK_tblUserMaster] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[tblActionPlan]  WITH CHECK ADD  CONSTRAINT [FK_tblActionPlan_tblCategoryType] FOREIGN KEY([CategoryTypeId])
REFERENCES [dbo].[tblCategoryType] ([CategoryTypeId])
GO
ALTER TABLE [dbo].[tblActionPlan] CHECK CONSTRAINT [FK_tblActionPlan_tblCategoryType]
GO
ALTER TABLE [dbo].[tblActionPlan]  WITH CHECK ADD  CONSTRAINT [FK_tblActionPlan_tblSubCategoryType] FOREIGN KEY([SubCategoryTypeId])
REFERENCES [dbo].[tblSubCategoryType] ([SubCategoryTypeId])
GO
ALTER TABLE [dbo].[tblActionPlan] CHECK CONSTRAINT [FK_tblActionPlan_tblSubCategoryType]
GO
ALTER TABLE [dbo].[tblActionPlan]  WITH CHECK ADD  CONSTRAINT [FK_tblActionPlan_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblActionPlan] CHECK CONSTRAINT [FK_tblActionPlan_tblSurvey]
GO
ALTER TABLE [dbo].[tblActionPlanProgress]  WITH CHECK ADD  CONSTRAINT [FK_tblActionPlanProgress_tblActionPlan] FOREIGN KEY([ActionPlanId])
REFERENCES [dbo].[tblActionPlan] ([ActionPlanId])
GO
ALTER TABLE [dbo].[tblActionPlanProgress] CHECK CONSTRAINT [FK_tblActionPlanProgress_tblActionPlan]
GO
ALTER TABLE [dbo].[tblActionPlanProgress]  WITH CHECK ADD  CONSTRAINT [FK_tblActionPlanProgress_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblActionPlanProgress] CHECK CONSTRAINT [FK_tblActionPlanProgress_tblSurvey]
GO
ALTER TABLE [dbo].[tblAnswer]  WITH CHECK ADD  CONSTRAINT [FK_tblAnswer_tblQuestion] FOREIGN KEY([QuestionId])
REFERENCES [dbo].[tblQuestion] ([QuestionId])
GO
ALTER TABLE [dbo].[tblAnswer] CHECK CONSTRAINT [FK_tblAnswer_tblQuestion]
GO
ALTER TABLE [dbo].[tblCategoryType]  WITH CHECK ADD  CONSTRAINT [FK_tblCategoryType_tblCategoryType1] FOREIGN KEY([CategoryTypeId])
REFERENCES [dbo].[tblCategoryType] ([CategoryTypeId])
GO
ALTER TABLE [dbo].[tblCategoryType] CHECK CONSTRAINT [FK_tblCategoryType_tblCategoryType1]
GO
ALTER TABLE [dbo].[tblCentre]  WITH CHECK ADD  CONSTRAINT [FK_tblCentre_tblCentre] FOREIGN KEY([CentreTypeId])
REFERENCES [dbo].[tblCentreType] ([CentreTypeId])
GO
ALTER TABLE [dbo].[tblCentre] CHECK CONSTRAINT [FK_tblCentre_tblCentre]
GO
ALTER TABLE [dbo].[tblCentre]  WITH CHECK ADD  CONSTRAINT [FK_tblCentre_tblTaluka] FOREIGN KEY([TalukaId])
REFERENCES [dbo].[tblTaluka] ([TalukaId])
GO
ALTER TABLE [dbo].[tblCentre] CHECK CONSTRAINT [FK_tblCentre_tblTaluka]
GO
ALTER TABLE [dbo].[tblDQAG]  WITH CHECK ADD  CONSTRAINT [FK_tblDQAG_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblDQAG] CHECK CONSTRAINT [FK_tblDQAG_tblSurvey]
GO
ALTER TABLE [dbo].[tblDQAG]  WITH CHECK ADD  CONSTRAINT [FK_tblDQAG_tblUserMaster] FOREIGN KEY([UserId])
REFERENCES [dbo].[tblUserMaster] ([UserId])
GO
ALTER TABLE [dbo].[tblDQAG] CHECK CONSTRAINT [FK_tblDQAG_tblUserMaster]
GO
ALTER TABLE [dbo].[tblGiAnswer]  WITH CHECK ADD  CONSTRAINT [FK_tblGiAnswerWeightage_tblQuestion] FOREIGN KEY([QuestionId])
REFERENCES [dbo].[tblQuestion] ([QuestionId])
GO
ALTER TABLE [dbo].[tblGiAnswer] CHECK CONSTRAINT [FK_tblGiAnswerWeightage_tblQuestion]
GO
ALTER TABLE [dbo].[tblGIResult]  WITH CHECK ADD  CONSTRAINT [FK_tblGIResult_tblCategoryType] FOREIGN KEY([CategoryTypeId])
REFERENCES [dbo].[tblCategoryType] ([CategoryTypeId])
GO
ALTER TABLE [dbo].[tblGIResult] CHECK CONSTRAINT [FK_tblGIResult_tblCategoryType]
GO
ALTER TABLE [dbo].[tblGIResult]  WITH CHECK ADD  CONSTRAINT [FK_tblGIResult_tblQuestion] FOREIGN KEY([QuestionId])
REFERENCES [dbo].[tblQuestion] ([QuestionId])
GO
ALTER TABLE [dbo].[tblGIResult] CHECK CONSTRAINT [FK_tblGIResult_tblQuestion]
GO
ALTER TABLE [dbo].[tblGIResult]  WITH CHECK ADD  CONSTRAINT [FK_tblGIResult_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblGIResult] CHECK CONSTRAINT [FK_tblGIResult_tblSurvey]
GO
ALTER TABLE [dbo].[tblHRProfile]  WITH CHECK ADD  CONSTRAINT [FK_tblHRProfile_tblDesignationMaster] FOREIGN KEY([DesignationId])
REFERENCES [dbo].[tblDesignationMaster] ([DesignationId])
GO
ALTER TABLE [dbo].[tblHRProfile] CHECK CONSTRAINT [FK_tblHRProfile_tblDesignationMaster]
GO
ALTER TABLE [dbo].[tblHRProfile]  WITH CHECK ADD  CONSTRAINT [FK_tblHRProfile_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblHRProfile] CHECK CONSTRAINT [FK_tblHRProfile_tblSurvey]
GO
ALTER TABLE [dbo].[tblModuleAccess]  WITH CHECK ADD  CONSTRAINT [FK_tblModuleAccess_tblModuleMaster1] FOREIGN KEY([ModuleId])
REFERENCES [dbo].[tblModuleMaster] ([ModuleId])
GO
ALTER TABLE [dbo].[tblModuleAccess] CHECK CONSTRAINT [FK_tblModuleAccess_tblModuleMaster1]
GO
ALTER TABLE [dbo].[tblModuleAccess]  WITH CHECK ADD  CONSTRAINT [FK_tblModuleAccess_tblRoleMaster] FOREIGN KEY([RoleId])
REFERENCES [dbo].[tblRoleMaster] ([RoleId])
GO
ALTER TABLE [dbo].[tblModuleAccess] CHECK CONSTRAINT [FK_tblModuleAccess_tblRoleMaster]
GO
ALTER TABLE [dbo].[tblQuestion]  WITH CHECK ADD  CONSTRAINT [FK_tblQuestion_AnsewerType] FOREIGN KEY([AnswerTyepId])
REFERENCES [dbo].[tblAnsewerType] ([AnswerTypeId])
GO
ALTER TABLE [dbo].[tblQuestion] CHECK CONSTRAINT [FK_tblQuestion_AnsewerType]
GO
ALTER TABLE [dbo].[tblQuestion]  WITH CHECK ADD  CONSTRAINT [FK_tblQuestion_tblCentreType] FOREIGN KEY([CenterTypeId])
REFERENCES [dbo].[tblCentreType] ([CentreTypeId])
GO
ALTER TABLE [dbo].[tblQuestion] CHECK CONSTRAINT [FK_tblQuestion_tblCentreType]
GO
ALTER TABLE [dbo].[tblQuestion]  WITH CHECK ADD  CONSTRAINT [FK_tblQuestion_tblSubCategoryType] FOREIGN KEY([SubCategoryTyepId])
REFERENCES [dbo].[tblSubCategoryType] ([SubCategoryTypeId])
GO
ALTER TABLE [dbo].[tblQuestion] CHECK CONSTRAINT [FK_tblQuestion_tblSubCategoryType]
GO
ALTER TABLE [dbo].[tblResult]  WITH CHECK ADD  CONSTRAINT [FK_tblResult_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblResult] CHECK CONSTRAINT [FK_tblResult_tblSurvey]
GO
ALTER TABLE [dbo].[tblResult]  WITH CHECK ADD  CONSTRAINT [FK_tblResult_tblUserMasterACPTeamLeadId] FOREIGN KEY([ActionQATeamLeaderId])
REFERENCES [dbo].[tblUserMaster] ([UserId])
GO
ALTER TABLE [dbo].[tblResult] CHECK CONSTRAINT [FK_tblResult_tblUserMasterACPTeamLeadId]
GO
ALTER TABLE [dbo].[tblResult]  WITH CHECK ADD  CONSTRAINT [FK_tblResult_tblUserMasterGiTeamLeadId] FOREIGN KEY([GiQATeamLeaderId])
REFERENCES [dbo].[tblUserMaster] ([UserId])
GO
ALTER TABLE [dbo].[tblResult] CHECK CONSTRAINT [FK_tblResult_tblUserMasterGiTeamLeadId]
GO
ALTER TABLE [dbo].[tblResult]  WITH CHECK ADD  CONSTRAINT [FK_tblResult_tblUserMasterResultQATeamLead] FOREIGN KEY([ResultQATeamLeaderId])
REFERENCES [dbo].[tblUserMaster] ([UserId])
GO
ALTER TABLE [dbo].[tblResult] CHECK CONSTRAINT [FK_tblResult_tblUserMasterResultQATeamLead]
GO
ALTER TABLE [dbo].[tblRevievRecord]  WITH CHECK ADD  CONSTRAINT [FK_tblRevievRecord_tblQuestion] FOREIGN KEY([QuestionId])
REFERENCES [dbo].[tblQuestion] ([QuestionId])
GO
ALTER TABLE [dbo].[tblRevievRecord] CHECK CONSTRAINT [FK_tblRevievRecord_tblQuestion]
GO
ALTER TABLE [dbo].[tblRevievRecord]  WITH CHECK ADD  CONSTRAINT [FK_tblRevievRecord_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblRevievRecord] CHECK CONSTRAINT [FK_tblRevievRecord_tblSurvey]
GO
ALTER TABLE [dbo].[tblSkillTrainingStatus]  WITH CHECK ADD  CONSTRAINT [FK_tblSkillTrainingStatus_tblDesignationMaster] FOREIGN KEY([DesignationId])
REFERENCES [dbo].[tblDesignationMaster] ([DesignationId])
GO
ALTER TABLE [dbo].[tblSkillTrainingStatus] CHECK CONSTRAINT [FK_tblSkillTrainingStatus_tblDesignationMaster]
GO
ALTER TABLE [dbo].[tblSkillTrainingStatus]  WITH CHECK ADD  CONSTRAINT [FK_tblSkillTrainingStatus_tblQualification] FOREIGN KEY([QualificationId])
REFERENCES [dbo].[tblQualification] ([QualificationId])
GO
ALTER TABLE [dbo].[tblSkillTrainingStatus] CHECK CONSTRAINT [FK_tblSkillTrainingStatus_tblQualification]
GO
ALTER TABLE [dbo].[tblSkillTrainingStatus]  WITH CHECK ADD  CONSTRAINT [FK_tblSkillTrainingStatus_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblSkillTrainingStatus] CHECK CONSTRAINT [FK_tblSkillTrainingStatus_tblSurvey]
GO
ALTER TABLE [dbo].[tblStaffRespondent]  WITH CHECK ADD  CONSTRAINT [FK_tblStaffRespondent_tblDesignationMaster] FOREIGN KEY([DesignationId])
REFERENCES [dbo].[tblDesignationMaster] ([DesignationId])
GO
ALTER TABLE [dbo].[tblStaffRespondent] CHECK CONSTRAINT [FK_tblStaffRespondent_tblDesignationMaster]
GO
ALTER TABLE [dbo].[tblStaffRespondent]  WITH CHECK ADD  CONSTRAINT [FK_tblStaffRespondent_tblQualification] FOREIGN KEY([QualificationId])
REFERENCES [dbo].[tblQualification] ([QualificationId])
GO
ALTER TABLE [dbo].[tblStaffRespondent] CHECK CONSTRAINT [FK_tblStaffRespondent_tblQualification]
GO
ALTER TABLE [dbo].[tblStaffRespondent]  WITH CHECK ADD  CONSTRAINT [FK_tblStaffRespondent_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblStaffRespondent] CHECK CONSTRAINT [FK_tblStaffRespondent_tblSurvey]
GO
ALTER TABLE [dbo].[tblSubCategoryType]  WITH CHECK ADD  CONSTRAINT [FK_tblSubCategoryType_tblCategoryType] FOREIGN KEY([CategoryTypeId])
REFERENCES [dbo].[tblCategoryType] ([CategoryTypeId])
GO
ALTER TABLE [dbo].[tblSubCategoryType] CHECK CONSTRAINT [FK_tblSubCategoryType_tblCategoryType]
GO
ALTER TABLE [dbo].[tblSurvey]  WITH CHECK ADD  CONSTRAINT [FK_tblSurvey_tblCentre] FOREIGN KEY([CentreId])
REFERENCES [dbo].[tblCentre] ([CentreId])
GO
ALTER TABLE [dbo].[tblSurvey] CHECK CONSTRAINT [FK_tblSurvey_tblCentre]
GO
ALTER TABLE [dbo].[tblSurveyAnswer]  WITH CHECK ADD  CONSTRAINT [FK_tblSurveyAnswer_tblAnswer] FOREIGN KEY([AnswerId])
REFERENCES [dbo].[tblAnswer] ([AnswerId])
GO
ALTER TABLE [dbo].[tblSurveyAnswer] CHECK CONSTRAINT [FK_tblSurveyAnswer_tblAnswer]
GO
ALTER TABLE [dbo].[tblSurveyAnswer]  WITH CHECK ADD  CONSTRAINT [FK_tblSurveyAnswer_tblQuestion] FOREIGN KEY([QuestionId])
REFERENCES [dbo].[tblQuestion] ([QuestionId])
GO
ALTER TABLE [dbo].[tblSurveyAnswer] CHECK CONSTRAINT [FK_tblSurveyAnswer_tblQuestion]
GO
ALTER TABLE [dbo].[tblSurveyAnswer]  WITH CHECK ADD  CONSTRAINT [FK_tblSurveyAnswer_tblSurvey] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[tblSurvey] ([SurveyId])
GO
ALTER TABLE [dbo].[tblSurveyAnswer] CHECK CONSTRAINT [FK_tblSurveyAnswer_tblSurvey]
GO
ALTER TABLE [dbo].[tblSurveyPeople]  WITH CHECK ADD  CONSTRAINT [FK_tblSurveyPeople_tblSurveyPeople] FOREIGN KEY([SurveyScheduleId])
REFERENCES [dbo].[tblSurveySchedule] ([SurveyScheduleId])
GO
ALTER TABLE [dbo].[tblSurveyPeople] CHECK CONSTRAINT [FK_tblSurveyPeople_tblSurveyPeople]
GO
ALTER TABLE [dbo].[tblSurveyPeople]  WITH CHECK ADD  CONSTRAINT [FK_tblSurveyPeople_tblUserMaster] FOREIGN KEY([UserId])
REFERENCES [dbo].[tblUserMaster] ([UserId])
GO
ALTER TABLE [dbo].[tblSurveyPeople] CHECK CONSTRAINT [FK_tblSurveyPeople_tblUserMaster]
GO
ALTER TABLE [dbo].[tblSurveySchedule]  WITH CHECK ADD  CONSTRAINT [FK_tblSurveySchedule_tblCentre] FOREIGN KEY([CentreId])
REFERENCES [dbo].[tblCentre] ([CentreId])
GO
ALTER TABLE [dbo].[tblSurveySchedule] CHECK CONSTRAINT [FK_tblSurveySchedule_tblCentre]
GO
ALTER TABLE [dbo].[tblTaluka]  WITH CHECK ADD  CONSTRAINT [FK_tblTaluka_tblDistrict] FOREIGN KEY([DistrictId])
REFERENCES [dbo].[tblDistrict] ([DistrictId])
GO
ALTER TABLE [dbo].[tblTaluka] CHECK CONSTRAINT [FK_tblTaluka_tblDistrict]
GO
ALTER TABLE [dbo].[tblUserCentreMapping]  WITH CHECK ADD  CONSTRAINT [FK_tblUserCentreMapping_tblCentre] FOREIGN KEY([CentreId])
REFERENCES [dbo].[tblCentre] ([CentreId])
GO
ALTER TABLE [dbo].[tblUserCentreMapping] CHECK CONSTRAINT [FK_tblUserCentreMapping_tblCentre]
GO
ALTER TABLE [dbo].[tblUserCentreMapping]  WITH CHECK ADD  CONSTRAINT [FK_tblUserCentreMapping_tblUserMaster] FOREIGN KEY([UserId])
REFERENCES [dbo].[tblUserMaster] ([UserId])
GO
ALTER TABLE [dbo].[tblUserCentreMapping] CHECK CONSTRAINT [FK_tblUserCentreMapping_tblUserMaster]
GO
ALTER TABLE [dbo].[tblUserMaster]  WITH CHECK ADD  CONSTRAINT [FK_tblUserMaster_tblDesignationMaster] FOREIGN KEY([DesignationId])
REFERENCES [dbo].[tblDesignationMaster] ([DesignationId])
GO
ALTER TABLE [dbo].[tblUserMaster] CHECK CONSTRAINT [FK_tblUserMaster_tblDesignationMaster]
GO
ALTER TABLE [dbo].[tblUserMaster]  WITH CHECK ADD  CONSTRAINT [FK_tblUserMaster_tblQualification] FOREIGN KEY([QualificationId])
REFERENCES [dbo].[tblQualification] ([QualificationId])
GO
ALTER TABLE [dbo].[tblUserMaster] CHECK CONSTRAINT [FK_tblUserMaster_tblQualification]
GO
ALTER TABLE [dbo].[tblUserMaster]  WITH CHECK ADD  CONSTRAINT [FK_tblUserMaster_tblRoleMaster] FOREIGN KEY([RoleId])
REFERENCES [dbo].[tblRoleMaster] ([RoleId])
GO
ALTER TABLE [dbo].[tblUserMaster] CHECK CONSTRAINT [FK_tblUserMaster_tblRoleMaster]
GO
ALTER TABLE [dbo].[tblUserMaster]  WITH CHECK ADD  CONSTRAINT [FK_tblUserMaster_tblUserMaster1] FOREIGN KEY([ReportingManagerId])
REFERENCES [dbo].[tblUserMaster] ([UserId])
GO
ALTER TABLE [dbo].[tblUserMaster] CHECK CONSTRAINT [FK_tblUserMaster_tblUserMaster1]
GO
