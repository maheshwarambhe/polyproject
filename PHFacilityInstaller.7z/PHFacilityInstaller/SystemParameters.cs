﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PHFacilityInstaller
{
    public static class SystemParameters
    {
        public static bool IsSuccess = false;
    }
}
