﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default10 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        host2databaseDataContext ch = new host2databaseDataContext();
        var result = (from x in ch.usertbls
                      where x.password.Equals(TextBox1.Text)
                      select x).FirstOrDefault();
        if (result != null)
        {
            var query = from ord in ch.usertbls
                        where ord.password == TextBox1.Text
                        select ord;


            foreach (usertbl ord in query)
            {

                ord.password = TextBox2.Text;

            }
            ch.SubmitChanges();
            Response.Redirect("~/admin/Changsucess.aspx");
        }

        else
        {
            Label1.Visible = true;
        }
    }
}