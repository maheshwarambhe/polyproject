﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default10 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        host2databaseDataContext rm = new host2databaseDataContext();
        var qu = from x in rm.host_stud_infos
                 where x.admitionNo.Equals(TextBox1.Text)
                 select x;
        foreach (var del in qu)
        {
            rm.host_stud_infos.DeleteOnSubmit(del );
        }
        rm.SubmitChanges();
    }
}