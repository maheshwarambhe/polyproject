﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;



public partial class Default10 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        string lod = FileUpload1.PostedFile.FileName;
        if (lod == "")
        {
            Label1.Visible = true; 
        }
        else
        {
            Label1.Visible = false;



            int i = 1;
            //Get Filename from fileupload control
            string filename = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
            //Save images into Images folder
            FileUpload1.SaveAs(Server.MapPath("files/" + filename));
            //Getting dbconnection from web.config connectionstring
            SqlConnection con = new SqlConnection("Data Source=ACER-PC;Initial Catalog=hostbase;Persist Security Info=True;User ID=sa;Password=sa");
            //Open the database connection
            con.Open();
            //Query to insert images path and name into database
            string tle = TextBox1.Text;
            SqlCommand cmd = new SqlCommand("update notice set fileName = @ImageName, FilePath = @ImagePath ,Title= @titl where number = @f ", con);
            //Passing parameters to query
            cmd.Parameters.AddWithValue("@ImageName", filename);
            cmd.Parameters.AddWithValue("@ImagePath", "admin/files/" + filename);
            cmd.Parameters.AddWithValue("@f", i);
            cmd.Parameters.AddWithValue("@titl", tle);
            cmd.ExecuteNonQuery();
            //Close dbconnection
            con.Close();
            Response.Redirect("~/admin/mang_notice.aspx");
        }
       
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string lod=  FileUpload1 .PostedFile .FileName;
      
        if (lod == "")
        {
            Label1.Visible = true; 
        }
        else
        {
            Label1.Visible = false;



            int i = 2;
            //Get Filename from fileupload control
            string filename = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
            //Save images into Images folder
            FileUpload1.SaveAs(Server.MapPath("files/" + filename));
            //Getting dbconnection from web.config connectionstring
            SqlConnection con = new SqlConnection("Data Source=ACER-PC;Initial Catalog=hostbase;Persist Security Info=True;User ID=sa;Password=sa");
            //Open the database connection
            con.Open();
            //Query to insert images path and name into database
            string tle = TextBox2.Text;
            SqlCommand cmd = new SqlCommand("update notice set fileName = @ImageName, FilePath = @ImagePath ,Title= @titl where number = @f ", con);
            //Passing parameters to query
            cmd.Parameters.AddWithValue("@ImageName", filename);
            cmd.Parameters.AddWithValue("@ImagePath", "admin/files/" + filename);
            cmd.Parameters.AddWithValue("@f", i);
            cmd.Parameters.AddWithValue("@titl", tle);
            cmd.ExecuteNonQuery();
            //Close dbconnection
            con.Close();
            Response.Redirect("~/admin/mang_notice.aspx");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string lod = FileUpload1.PostedFile.FileName;
        if (lod == "")
        {
            Label1.Visible = true;
        }
        else
        {
            Label1.Visible = false;



            int i = 3;
            //Get Filename from fileupload control
            string filename = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
            //Save images into Images folder
            FileUpload1.SaveAs(Server.MapPath("files/" + filename));
            //Getting dbconnection from web.config connectionstring
            SqlConnection con = new SqlConnection("Data Source=ACER-PC;Initial Catalog=hostbase;Persist Security Info=True;User ID=sa;Password=sa");
            //Open the database connection
            con.Open();
            //Query to insert images path and name into database
            string tle = TextBox3.Text;
            SqlCommand cmd = new SqlCommand("update notice set fileName = @ImageName, FilePath = @ImagePath ,Title= @titl where number = @f ", con);
            //Passing parameters to query
            cmd.Parameters.AddWithValue("@ImageName", filename);
            cmd.Parameters.AddWithValue("@ImagePath", "admin/files/" + filename);
            cmd.Parameters.AddWithValue("@f", i);
            cmd.Parameters.AddWithValue("@titl", tle);
            cmd.ExecuteNonQuery();
            //Close dbconnection
            con.Close();
            Response.Redirect("~/admin/mang_notice.aspx");
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        string lod = FileUpload1.PostedFile.FileName;
        if (lod == "")
        {
            Label1.Visible = true;
        }
        else
        {
            Label1.Visible = false;



            int i = 4;
            //Get Filename from fileupload control
            string filename = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
            //Save images into Images folder
            FileUpload1.SaveAs(Server.MapPath("files/" + filename));
            //Getting dbconnection from web.config connectionstring
            SqlConnection con = new SqlConnection("Data Source=ACER-PC;Initial Catalog=hostbase;Persist Security Info=True;User ID=sa;Password=sa");
            //Open the database connection
            con.Open();
            //Query to insert images path and name into database
            string tle = TextBox4.Text;
            SqlCommand cmd = new SqlCommand("update notice set fileName = @ImageName, FilePath = @ImagePath ,Title= @titl where number = @f ", con);
            //Passing parameters to query
            cmd.Parameters.AddWithValue("@ImageName", filename);
            cmd.Parameters.AddWithValue("@ImagePath", "admin/files/" + filename);
            cmd.Parameters.AddWithValue("@f", i);
            cmd.Parameters.AddWithValue("@titl", tle);
            cmd.ExecuteNonQuery();
            //Close dbconnection
            con.Close();
            Response.Redirect("~/admin/mang_notice.aspx");
        }
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        string lod = FileUpload1.PostedFile.FileName;
        if (lod == "")
        {
            Label1.Visible = true;
        }
        else
        {
            Label1.Visible = false;



            int i = 5;
            //Get Filename from fileupload control
            string filename = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
            //Save images into Images folder
            FileUpload1.SaveAs(Server.MapPath("files/" + filename));
            //Getting dbconnection from web.config connectionstring
            SqlConnection con = new SqlConnection("Data Source=ACER-PC;Initial Catalog=hostbase;Persist Security Info=True;User ID=sa;Password=sa");
            //Open the database connection
            con.Open();
            //Query to insert images path and name into database
            string tle = TextBox5.Text;
            SqlCommand cmd = new SqlCommand("update notice set fileName = @ImageName, FilePath = @ImagePath ,Title= @titl where number = @f ", con);
            //Passing parameters to query
            cmd.Parameters.AddWithValue("@ImageName", filename);
            cmd.Parameters.AddWithValue("@ImagePath", "admin/files/" + filename);
            cmd.Parameters.AddWithValue("@f", i);
            cmd.Parameters.AddWithValue("@titl", tle);
            cmd.ExecuteNonQuery();
            //Close dbconnection
            con.Close();
            Response.Redirect("~/admin/mang_notice.aspx");
        }
    }
}