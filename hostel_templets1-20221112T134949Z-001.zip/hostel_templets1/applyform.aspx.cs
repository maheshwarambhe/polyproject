﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        host2databaseDataContext  us = new host2databaseDataContext ();
        var result = (from x in us.stud_infos
                      where x.admitionNo.Equals(TextBox10.Text) &
                      x.Apply .Equals (null)
                      select x).FirstOrDefault();
        if (result != null)
        {
            string strConnect = "Data Source=ACER-PC;Initial Catalog=hostbase;Persist Security Info=True;User ID=sa;Password=sa";
            SqlConnection Conn = new SqlConnection(strConnect);
            string Command = "Select * from stud_info where admitionNo ='" + TextBox10.Text + "'";
            SqlCommand cmd = new SqlCommand(Command, Conn);
            Conn.Open();
            SqlDataReader Fr = cmd.ExecuteReader();
            while (Fr.Read())
            {
                String fname = Fr.GetString(1);
                String cat = Fr.GetString(2);

                String yr = Fr.GetString(4);
                decimal mk = Fr.GetDecimal(3);
                TextBox11.Text = fname;
                TextBox12.Text = cat;
                TextBox21.Text = mk.ToString();
                TextBox14.Text = yr;

            }
            TextBox10.ReadOnly = true;
            ImageButton2.Enabled = true;
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "already apply or not College Student";
        }



    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Label3.Visible = false ;
        Label4.Visible = false ;
        if (TextBox14.Text == "Second    " && TextBox16.Text == "")
        {
            Label3.Visible = true;
            Label3.Text = "first year % must required";
        }
        else
        {
            if (TextBox14.Text == "Third     " && TextBox17.Text == "")
            {
                Label4.Visible = true;
                Label4.Text = "Second year % must required";
            }
            else 
            {
            //code
                decimal dec = 00;
                if (TextBox15.Text == "")
                    TextBox15.Text = dec.ToString();
                if (TextBox16.Text == "")
                    TextBox16.Text = dec.ToString();
                if (TextBox17.Text == "")
                    TextBox17.Text = dec.ToString();

            host2databaseDataContext  db = new host2databaseDataContext ();
            var query = from ord in db.stud_infos
                        where ord.admitionNo  == TextBox10 .Text 
                        select ord;

            // Execute the query, and change the column values 
            // you want to change. 
            foreach (stud_info ord in query)
            {
               ord.HSCmarks =Convert.ToDecimal (   TextBox15 .Text );
                ord.First_Year = Convert .ToDecimal (TextBox16 .Text );
                ord.Second_Year = Convert .ToDecimal (TextBox17 .Text );
                ord .Contact = TextBox18 .Text ;
                ord.Email = TextBox20 .Text ;
                ord.PermanantAddrs = Convert .ToString (TextBox19 .Text );
                ord.Apply = 'y';
                              
                // Insert any additional changes to column values.
            }

                db.SubmitChanges();
                Label2.Visible = true;
                Label2.Text = "successfully submit apply form.";
            
            // Submit the changes to the database. 
           
       
            
            }
        }
      

    }
}

   