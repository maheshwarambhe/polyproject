﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class hostel : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        host2databaseDataContext dc = new host2databaseDataContext();
        notice tb = new notice();
      
        var query1 = from ord in dc.notices 
                    where ord.number == 1
                    select ord;
               
        foreach (var nn in query1 )
        {
            HyperLink6.Text = nn.Title;
            string path = nn.FilePath;
            HyperLink6.NavigateUrl = path;
            // Insert any additional changes to column values.
        }

        var query2 = from ord in dc.notices
                     where ord.number == 2
                     select ord;

        foreach (var nn in query2)
        {
            HyperLink7.Text = nn.Title;
            string path = nn.FilePath;
            HyperLink7.NavigateUrl = path;
            // Insert any additional changes to column values.
        }

        var query3 = from ord in dc.notices
                     where ord.number == 3
                     select ord;

        foreach (var nn in query3)
        {
            HyperLink8.Text = nn.Title;
            string path = nn.FilePath;
            HyperLink8.NavigateUrl = path;
            // Insert any additional changes to column values.
        }
        var query4 = from ord in dc.notices
                     where ord.number == 4
                     select ord;

        foreach (var nn in query4)
        {
            HyperLink9.Text = nn.Title;
            string path = nn.FilePath;
            HyperLink9.NavigateUrl = path;
            // Insert any additional changes to column values.
        }
        var query5 = from ord in dc.notices
                     where ord.number == 5
                     select ord;

        foreach (var nn in query5)
        {
            HyperLink10.Text = nn.Title;
            string path = nn.FilePath;
            HyperLink10.NavigateUrl = path;
            // Insert any additional changes to column values.
        }
        
        
        
    }
}
