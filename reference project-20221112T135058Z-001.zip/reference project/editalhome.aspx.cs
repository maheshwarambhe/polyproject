﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class Default2 : System.Web.UI.Page
{
    string emflat;
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Text = Request.QueryString["id"];
        emflat = Label3.Text;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        pDataClassesDataContext  dc = new pDataClassesDataContext ();
     alumini_info  ft = new alumini_info ();
        string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
        FileUpload1.PostedFile.SaveAs(Server.MapPath("~/images/") + fileName);
        var query = from ord in dc.alumini_infos
                    where ord.Email == emflat 
                    select ord;

        // Execute the query, and change the column values 
        // you want to change. 
        foreach (alumini_info ord in query)
        {
            ord.contact_no = TextBox1  .Text;
            ord.Address = TextBox2.Text;
            ord.status  = TextBox3.Text;
            ord.image_name = fileName;
            ord.image_path = "~/images/" + fileName;
            // Insert any additional changes to column values.
        }

        // Submit the changes to the database. 
        try
        {
            dc.SubmitChanges();
            Response.Redirect("~/Alhome.aspx?id=" + emflat );
        }
        catch
        {
            Label2.Visible = true;
            Label2.Text = "fails to update";
        }
     
    }
}