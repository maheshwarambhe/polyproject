﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default6 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            solventtDataContext dc = new solventtDataContext();
            oil_order tb = new oil_order();
            tb.c_name = Convert.ToString(TextBox5.Text);
            tb.Addrs = Convert.ToString(TextBox6.Text);
            tb.cont = TextBox7.Text;
            tb.eid = TextBox8.Text;
            tb.litre = TextBox9.Text;
            DateTime dte = DateTime.Now;
            string longDate = dte.ToLongDateString();
            tb.date = longDate;
            dc.oil_orders.InsertOnSubmit(tb);
            dc.SubmitChanges();
            Label1.Visible = true;
            Label1.Text = "Your order request Submit Successfully We will Call back to You.";
        }
        catch
        {
            Label1.Visible = true;
            Label1.Text = "Your order request  not Submit.";
        }
        
    }
}