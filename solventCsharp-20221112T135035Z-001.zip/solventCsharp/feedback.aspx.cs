﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Default8 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            solventtDataContext dc = new solventtDataContext();
            feedbk tb = new feedbk();
            tb.Custemer_name = TextBox1.Text;
            tb.email = TextBox2.Text;
            tb.message = Convert.ToString(TextBox3.Text);
            DateTime dte = DateTime.Now;
            string longDate = dte.ToLongDateString();
            tb.date = longDate;
            dc.feedbks.InsertOnSubmit(tb);
            dc.SubmitChanges();
            Label1.Visible = true;
            Label1.Text = "Your FeedBack  Submit Successfully. We will Reply Shortly.";
        }
        catch
        {
            Label1.Visible = true;
            Label1.Text = "Your feedback  not Submit.";
        }
       
    }
}