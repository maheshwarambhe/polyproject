﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default7 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Label1.Visible = false ;
        solventtDataContext us = new solventtDataContext ();
        var result = (from x in us.admins
                      where x.username.Equals(TextBox5.Text) &
                      x.password.Equals(TextBox6.Text)
                      select x).FirstOrDefault();
        if (result != null)
            Response.Redirect("~/admin/ahome.aspx");
        else
        { 
        Label1.Visible = true;
        Label1 .Text = "Email or Password Incorrect" ;
        }
    
    }
}